// 默认提取10页
let isExtracting = false;
let maxPages = 10; // 默认值为10

// 存储CSV数据的映射
const zkyfqMap = {};
const jcrfqMap = {};
const CUSTOM_PARTITION_STORAGE_KEY = 'customPartitionData';
const AUTHOR_ROLE_STORAGE_KEY = 'gsaAuthorRoleCache';
const AUTHOR_ROLE_AUTO_KEY = 'gsaAuthorRoleAuto';

let customPartitions = [];
let customPartitionIndex = new Map();
let enabledCustomPartitionIds = new Set();
let xlsxLibraryPromise = null;

const DEFAULT_DISPLAY_PARTITIONS = {
  showIF: true,
  showJCR: true,
  showCAS: true,
  showCustom: false
};

let displayPartitions = { ...DEFAULT_DISPLAY_PARTITIONS };

// 引用解析相关常量
const PUBMED_ESEARCH_URL = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi';
const PUBMED_ESUMMARY_URL = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi';
const PUBMED_EFETCH_URL = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi';
const PUBMED_RIS_URL = 'https://api.ncbi.nlm.nih.gov/lit/ctxp/v1/pubmed/';
const CROSSREF_API_URL = 'https://api.crossref.org/works';
const AUTHOR_ROLE_STYLES = {
  first: { label: '第一作者', badge: '#fff4cc', text: '#8a6d3b', row: '#fffaf0' },
  corresponding: { label: '通讯作者', badge: '#e0f7fa', text: '#006064', row: '#f1fbfd' },
  'co-corresponding': { label: '共同通讯', badge: '#e8eaf6', text: '#3949ab', row: '#f5f6fb' },
  'co-author': { label: '共同作者', badge: '#f2f2f2', text: '#666', row: '#fafafa' }
};
const authorRoleCache = new Map();
let authorRoleCacheLoaded = false;
let isAuthorRoleRunning = false;
let gsaMIndexController = null;

/**
 * 统一规范化标题，用于后续相似度比较
 * @param {string} title
 * @returns {string}
 */
function normalizeTitle(title) {
  return title
    .toLowerCase()
    .replace(/\u2026/g, ' ')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * 基于 token 的简单相似度打分
 * @param {string} candidateTitle
 * @param {string} targetTitle
 * @returns {number}
 */
function titleSimilarity(candidateTitle, targetTitle) {
  const candidateTokens = new Set(normalizeTitle(candidateTitle).split(' ').filter(Boolean));
  const targetTokens = new Set(normalizeTitle(targetTitle).split(' ').filter(Boolean));

  if (targetTokens.size === 0) {
    return 0;
  }

  let matches = 0;
  for (const token of targetTokens) {
    if (candidateTokens.has(token)) {
      matches += 1;
    }
  }

  return matches / targetTokens.size;
}

async function findDoiByTitle(partialTitle, options = {}) {
  if (typeof partialTitle !== 'string' || partialTitle.trim().length === 0) {
    throw new Error('标题不能为空');
  }

  const pubmedResult = await findDoiViaPubMed(partialTitle, options);
  if (pubmedResult) {
    return pubmedResult;
  }

  return findDoiViaCrossref(partialTitle, options);
}

async function findDoiViaPubMed(partialTitle, options = {}) {
  const {
    minScore = 0.3,
    pubmedRows = 5,
    tool = 'google-scholar-assistant',
    email = '',
  } = options;

  const cleanedQuery = partialTitle.replace(/\u2026/g, ' ').trim();
  if (!cleanedQuery) {
    return null;
  }

  const esearchParams = new URLSearchParams({
    db: 'pubmed',
    retmode: 'json',
    retmax: String(pubmedRows),
    term: cleanedQuery,
    sort: 'relevance',
  });

  if (tool) {
    esearchParams.set('tool', tool);
  }
  if (email) {
    esearchParams.set('email', email);
  }

  const esearchResponse = await fetch(`${PUBMED_ESEARCH_URL}?${esearchParams.toString()}`);
  if (!esearchResponse.ok) {
    throw new Error(`PubMed esearch failed: ${esearchResponse.status}`);
  }

  const esearchPayload = await esearchResponse.json();
  const ids = esearchPayload?.esearchresult?.idlist || [];
  if (ids.length === 0) {
    return null;
  }

  const esummaryParams = new URLSearchParams({
    db: 'pubmed',
    retmode: 'json',
    id: ids.join(','),
  });

  if (tool) {
    esummaryParams.set('tool', tool);
  }
  if (email) {
    esummaryParams.set('email', email);
  }

  const esummaryResponse = await fetch(`${PUBMED_ESUMMARY_URL}?${esummaryParams.toString()}`);
  if (!esummaryResponse.ok) {
    throw new Error(`PubMed esummary failed: ${esummaryResponse.status}`);
  }

  const esummaryPayload = await esummaryResponse.json();
  const resultRoot = esummaryPayload?.result;
  if (!resultRoot) {
    return null;
  }

  let best = null;

  for (const id of ids) {
    const record = resultRoot[id];
    if (!record) {
      continue;
    }

    const candidateTitle = record.title || '';
    const articleIds = Array.isArray(record.articleids) ? record.articleids : [];
    const doiEntry = articleIds.find((item) => item.idtype === 'doi' && item.value);

    if (!candidateTitle || !doiEntry) {
      continue;
    }

    const score = titleSimilarity(candidateTitle, partialTitle);

    if (score >= minScore && (!best || score > best.score)) {
      best = {
        doi: doiEntry.value,
        title: candidateTitle,
        score,
        source: 'pubmed',
        pmid: id,
      };
    }
  }

  return best;
}

async function findDoiViaCrossref(partialTitle, options = {}) {
  const {
    rows = 20,
    minScore = 0.3,
  } = options;

  const cleanedQuery = partialTitle.replace(/\u2026/g, ' ').trim();
  if (!cleanedQuery) {
    return null;
  }

  const url = new URL(CROSSREF_API_URL);
  url.searchParams.set('query.bibliographic', cleanedQuery);
  url.searchParams.set('rows', String(rows));

  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Crossref request failed: ${response.status}`);
  }

  const payload = await response.json();
  const items = payload?.message?.items || [];

  let best = null;

  for (const item of items) {
    if (!item.DOI || !Array.isArray(item.title) || item.title.length === 0) {
      continue;
    }

    const candidateTitle = item.title[0];
    const score = titleSimilarity(candidateTitle, partialTitle);

    if (score >= minScore && (!best || score > best.score)) {
      best = {
        doi: item.DOI,
        title: candidateTitle,
        score,
        source: 'crossref',
        pmid: null,
      };
    }
  }

  return best;
}

function normalizeRisEntry(text) {
  return text ? text.replace(/\r\n/g, '\n').trim() : '';
}

async function fetchPubMedRis(pmid, options = {}) {
  if (!pmid) {
    throw new Error('PMID 缺失');
  }

  const {
    tool = 'google-scholar-assistant',
    email = '',
  } = options;

  const params = new URLSearchParams({
    format: 'ris',
    id: pmid,
  });

  if (tool) {
    params.set('tool', tool);
  }
  if (email) {
    params.set('email', email);
  }

  const response = await fetch(`${PUBMED_RIS_URL}?${params.toString()}`);
  if (!response.ok) {
    throw new Error(`PubMed RIS 导出失败: ${response.status}`);
  }

  return response.text();
}

async function fetchCrossrefRis(doi) {
  if (!doi) {
    throw new Error('DOI 缺失');
  }

  const encodedDoi = encodeURIComponent(doi);
  const url = `${CROSSREF_API_URL}/${encodedDoi}/transform/application/x-research-info-systems`;

  const response = await fetch(url, {
    headers: {
      Accept: 'application/x-research-info-systems',
    },
  });

  if (!response.ok) {
    throw new Error(`Crossref RIS 导出失败: ${response.status}`);
  }

  return response.text();
}

async function fetchRisForResult(result, options = {}) {
  if (result.source === 'pubmed' && result.pmid) {
    return fetchPubMedRis(result.pmid, options);
  }
  return fetchCrossrefRis(result.doi);
}

async function fetchPubMedMetadata(pmid) {
  if (!pmid) {
    throw new Error('PMID 缺失');
  }

  const params = new URLSearchParams({
    db: 'pubmed',
    retmode: 'json',
    id: pmid,
  });

  const response = await fetch(`${PUBMED_ESUMMARY_URL}?${params.toString()}`);
  if (!response.ok) {
    throw new Error(`PubMed 元数据获取失败: ${response.status}`);
  }

  const payload = await response.json();
  const record = payload?.result?.[pmid];
  if (!record) {
    throw new Error('未找到 PubMed 元数据');
  }

  const articleIds = Array.isArray(record.articleids) ? record.articleids : [];
  const doiEntry = articleIds.find((item) => item.idtype === 'doi' && item.value);
  const authors = Array.isArray(record.authors)
    ? record.authors.map((author) => author.name).filter(Boolean).join('; ')
    : '';

  const abstract = await fetchPubMedAbstract(pmid);

  return {
    Title: record.title || '',
    Authors: authors,
    Journal: (record.fulljournalname || record.source || '').toUpperCase(),
    Year: record.pubdate ? record.pubdate.substring(0, 4) : '',
    Volume: record.volume || '',
    Issue: record.issue || '',
    Pages: record.pages || '',
    DOI: doiEntry?.value || '',
    PMID: pmid,
    Abstract: abstract,
  };
}

async function fetchPubMedAbstract(pmid) {
  try {
    const params = new URLSearchParams({
      db: 'pubmed',
      id: pmid,
      retmode: 'xml',
    });

    const response = await fetch(`${PUBMED_EFETCH_URL}?${params.toString()}`);
    if (!response.ok) {
      throw new Error(`PubMed 摘要获取失败: ${response.status}`);
    }

    const xmlText = await response.text();
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(xmlText, 'text/xml');
    const abstractSections = Array.from(xmlDoc.querySelectorAll('AbstractText'));

    if (abstractSections.length === 0) {
      return '';
    }

    const parts = abstractSections.map((section) => {
      const label = section.getAttribute('Label');
      const content = section.textContent.trim();
      return label ? `${label}\n${content}` : content;
    });

    if (parts.length > 1 && !parts[0].startsWith('Abstract')) {
      parts.unshift('Abstract');
    }

    return parts.join('\n\n');
  } catch (error) {
    console.warn('获取 PubMed 摘要失败:', error);
    return '';
  }
}

async function fetchCrossrefMetadata(doi) {
  if (!doi) {
    throw new Error('DOI 缺失');
  }

  const encodedDoi = encodeURIComponent(doi);
  const response = await fetch(`${CROSSREF_API_URL}/${encodedDoi}`);
  if (!response.ok) {
    throw new Error(`Crossref 元数据获取失败: ${response.status}`);
  }

  const payload = await response.json();
  const message = payload?.message;
  if (!message) {
    throw new Error('未找到 Crossref 元数据');
  }

  const authors = Array.isArray(message.author)
    ? message.author.map((author) => {
        const family = author.family || '';
        const given = author.given || '';
        return `${family}${family && given ? ', ' : ''}${given}`.trim();
      }).filter(Boolean).join('; ')
    : '';

  return {
    Title: Array.isArray(message.title) ? (message.title[0] || '') : '',
    Authors: authors,
    Journal: (Array.isArray(message['container-title']) && message['container-title'][0]
      ? message['container-title'][0].replace(/&amp;/g, '&')
      : '').toUpperCase(),
    Year: extractYearFromCrossref(message),
    Volume: message.volume || '',
    Issue: message.issue || '',
    Pages: message.page || '',
    DOI: message.DOI || doi,
    PMID: '',
    Abstract: stripHtml(message.abstract || ''),
  };
}

function extractYearFromCrossref(message) {
  const dateParts = (
    message['published-print']?.['date-parts']?.[0] ||
    message['published-online']?.['date-parts']?.[0] ||
    message['issued']?.['date-parts']?.[0] ||
    []
  );

  return dateParts[0] ? String(dateParts[0]) : '';
}

function stripHtml(value) {
  if (!value) {
    return '';
  }
  const tmp = document.createElement('div');
  tmp.innerHTML = value;
  return tmp.textContent || tmp.innerText || '';
}

function buildRisRecord(data) {
  if (!data) {
    return '';
  }

  const authors = typeof data.Authors === 'string'
    ? data.Authors.split(/;\s*/).filter(Boolean)
    : [];

  const risFields = [
    ['TY', 'JOUR'],
    ...authors.map((author) => ['AU', author.trim()]),
    ['TI', data.Title],
    ['JO', data.Journal],
    ['PY', data.Year],
    ['VL', data.Volume],
    ['IS', data.Issue],
    ['SP', data.Pages],
    ['DO', data.DOI],
    ['PM', data.PMID],
    ['AB', data.Abstract],
    ['ER', ''],
  ];

  const risContent = risFields
    .filter(([_, value]) => value)
    .map(([tag, value]) => `${tag}  - ${value}`)
    .join('\n');

  return risContent.includes('\nER  -') ? risContent : `${risContent}\nER  -`;
}

async function resolveRisForTitle(title, options = {}) {
  try {
    const match = await findDoiByTitle(title, options);
    if (!match) {
      return { status: 'not_found', title };
    }

    let risText = '';
    let metadata = null;

    try {
      risText = await fetchRisForResult(match, options);
    } catch (risError) {
      console.warn('直接获取 RIS 失败，尝试使用元数据构建:', match.title || title, risError);
    }

    if (!risText) {
      try {
        if (match.source === 'pubmed' && match.pmid) {
          metadata = await fetchPubMedMetadata(match.pmid);
        } else {
          metadata = await fetchCrossrefMetadata(match.doi);
        }

        if (metadata) {
          if (!metadata.DOI && match.doi) {
            metadata.DOI = match.doi;
          }
          if (!metadata.Title && match.title) {
            metadata.Title = match.title;
          }
          risText = buildRisRecord(metadata);
        }
      } catch (metaError) {
        console.error('获取元数据失败:', metaError);
        return { status: 'error', title, error: metaError };
      }
    }

    if (!risText) {
      return { status: 'error', title, error: new Error('RIS 内容为空') };
    }

    return {
      status: 'success',
      title: metadata?.Title || match.title || title,
      ris: normalizeRisEntry(risText),
      match,
      metadata,
    };
  } catch (error) {
    return {
      status: 'error',
      title,
      error,
    };
  }
}

// ---------------- 作者角色识别（个人主页高亮） ----------------
function gsaNormalizeName(name) {
  return String(name || '')
    .toLowerCase()
    .replace(/[,\.]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function gsaNormalizeRoleCacheKey(title, profileName) {
  return `${normalizeTitle(title)}|${gsaNormalizeName(profileName)}`;
}

function gsaPersistAuthorRoleCache() {
  const obj = {};
  authorRoleCache.forEach((v, k) => {
    if (v?.status === 'ok') {
      obj[k] = v;
    }
  });
  chrome.storage.local.set({ [AUTHOR_ROLE_STORAGE_KEY]: obj }, () => {});
}

function gsaEnsureAuthorRoleCacheLoaded() {
  if (authorRoleCacheLoaded) return Promise.resolve();
  return new Promise((resolve) => {
    chrome.storage.local.get([AUTHOR_ROLE_STORAGE_KEY], (res) => {
      const raw = res[AUTHOR_ROLE_STORAGE_KEY];
      if (raw && typeof raw === 'object') {
        Object.entries(raw).forEach(([k, v]) => {
          authorRoleCache.set(k, v);
        });
      }
      authorRoleCacheLoaded = true;
      resolve();
    });
  });
}

function gsaIsSameAuthor(candidate, target) {
  const c = gsaNormalizeName(candidate);
  const t = gsaNormalizeName(target);
  if (!c || !t) return false;
  if (c === t) return true;
  const cParts = c.split(' ');
  const tParts = t.split(' ');
  const cLast = cParts[cParts.length - 1];
  const tLast = tParts[tParts.length - 1];
  const cFirst = cParts[0];
  const tFirst = tParts[0];
  if (cLast && tLast && cLast === tLast && cFirst && tFirst && cFirst[0] === tFirst[0]) {
    return true;
  }
  // swap order
  if (cParts.length >= 2 && tParts.length >= 2 && cFirst === tLast && cLast === tFirst) {
    return true;
  }
  return false;
}

function gsaDetermineRole(authors, targetName, options = {}) {
  const { defaultLastAsCorr = false } = options;
  if (!Array.isArray(authors) || authors.length === 0) return null;
  const idx = authors.findIndex((a) => gsaIsSameAuthor(a.name || a.fullName || a.normalizedName, targetName));
  if (idx === -1) return null;
  const isFirst = idx === 0;
  const isLast = idx === authors.length - 1;
  const a = authors[idx] || {};
  const isCorr = !!a.corresponding;
  // 身份：第一作者、通讯作者、共同通讯、共同作者（中间作者）
  if (isCorr && isLast) return { type: 'corresponding', label: AUTHOR_ROLE_STYLES.corresponding.label };
  if (isCorr) return { type: 'co-corresponding', label: AUTHOR_ROLE_STYLES['co-corresponding'].label };
  if (isFirst) return { type: 'first', label: AUTHOR_ROLE_STYLES.first.label };
  if (defaultLastAsCorr && isLast && !authors.some((au) => au.corresponding)) {
    return { type: 'corresponding', label: AUTHOR_ROLE_STYLES.corresponding.label };
  }
  if (!isFirst && !isLast) return { type: 'co-author', label: AUTHOR_ROLE_STYLES['co-author'].label };
  return null;
}

function gsaParsePubmedAuthors(xmlText) {
  const parser = new DOMParser();
  const xmlDoc = parser.parseFromString(xmlText, 'text/xml');
  const nodes = Array.from(xmlDoc.querySelectorAll('AuthorList > Author'));
  return nodes.map((node) => {
    const last = node.querySelector('LastName')?.textContent?.trim() || '';
    const fore = node.querySelector('ForeName')?.textContent?.trim() ||
      node.querySelector('Initials')?.textContent?.trim() || '';
    const collective = node.querySelector('CollectiveName')?.textContent?.trim() || '';
    const fullName = collective || [last, fore].filter(Boolean).join(', ');
    if (!fullName) return null;
    const affs = Array.from(node.querySelectorAll('AffiliationInfo Affiliation')).map((a) => a.textContent || '');
    const hasEmail = affs.some((txt) => /@/i.test(txt));
    const hasCorrHint = affs.some((txt) => /corresponding/i.test(txt));
    return {
      name: fullName,
      normalizedName: gsaNormalizeName(fullName),
      equalContrib: !!node.querySelector('EqualContrib'),
      corresponding: hasEmail || hasCorrHint,
    };
  }).filter(Boolean);
}

async function gsaFetchWithRetry(url, options = {}, attempts = 3, delayMs = 600) {
  for (let i = 0; i < attempts; i++) {
    try {
      const res = await fetch(url, options);
      if (!res.ok) {
        if (res.status === 429 && i < attempts - 1) {
          await sleep(delayMs * (i + 1));
          continue;
        }
        console.warn('[GSA][PubMed] 请求失败', res.status, url);
        return null;
      }
      return res;
    } catch (err) {
      console.warn('[GSA][PubMed] 请求异常', err);
      if (i < attempts - 1) {
        await sleep(delayMs * (i + 1));
        continue;
      }
      return null;
    }
  }
  return null;
}

async function gsaFetchPubmedByTitle(title) {
  const cleanedTitle = String(title || '').replace(/\u2026/g, ' ').trim();
  if (!cleanedTitle) return null;
  const searchTerms = [
    `"${cleanedTitle}"[Title]`,
    `${cleanedTitle}[Title]`,
    cleanedTitle
  ];
  let pmid = null;
  for (const term of searchTerms) {
    const params = new URLSearchParams({
      db: 'pubmed',
      term,
      retmode: 'json',
      retmax: '5',
      sort: 'relevance'
    });
    const res = await gsaFetchWithRetry(`${PUBMED_ESEARCH_URL}?${params.toString()}`);
    if (!res) continue;
    const data = await res.json().catch(() => null);
    const ids = data?.esearchresult?.idlist || [];
    if (ids.length) {
      pmid = ids[0];
      break;
    }
  }
  // 备用：尝试截断标题前12个词再检索，提升命中率
  if (!pmid) {
    const words = cleanedTitle.split(/\s+/).filter(Boolean);
    if (words.length > 5) {
      const shortTitle = words.slice(0, Math.min(12, words.length)).join(' ');
      const shortParams = new URLSearchParams({
        db: 'pubmed',
        term: `"${shortTitle}"[Title]`,
        retmode: 'json',
        retmax: '5',
        sort: 'relevance'
      });
      const shortRes = await gsaFetchWithRetry(`${PUBMED_ESEARCH_URL}?${shortParams.toString()}`);
      if (shortRes) {
        const data = await shortRes.json().catch(() => null);
        const ids = data?.esearchresult?.idlist || [];
        if (ids.length) {
          pmid = ids[0];
        }
      }
    }
  }
  if (!pmid) return null;
  const detailParams = new URLSearchParams({ db: 'pubmed', id: pmid, retmode: 'xml' });
  const detailRes = await gsaFetchWithRetry(`${PUBMED_EFETCH_URL}?${detailParams.toString()}`);
  if (!detailRes) return null;
  const xml = await detailRes.text();
  return { pmid, authors: gsaParsePubmedAuthors(xml) };
}

async function gsaFetchCrossrefByTitle(title) {
  const url = new URL(CROSSREF_API_URL);
  url.searchParams.set('query.title', title);
  url.searchParams.set('rows', '5');
  const res = await fetch(url.toString());
  if (!res.ok) return null;
  const data = await res.json();
  const items = data?.message?.items || [];
  const best = items[0];
  if (!best) return null;
  const authors = Array.isArray(best.author) ? best.author : [];
  const mapped = authors.map((a) => {
    const family = a.family || '';
    const given = a.given || '';
    const fullName = [family, given].filter(Boolean).join(', ') || family || given;
    const affText = Array.isArray(a.affiliation) ? a.affiliation.map((it) => it?.name || '').join(' ') : '';
    return {
      name: fullName,
      normalizedName: gsaNormalizeName(fullName),
      equalContrib: !!a['equal-contrib'],
      corresponding: /@/.test(affText)
    };
  }).filter((a) => a && a.name);
  return { doi: best.DOI, authors: mapped };
}

function gsaApplyAuthorRoleHighlight(row, role) {
  row.removeAttribute('data-gsa-author-role');
  const old = row.querySelector('.gsa-author-role-badge');
  if (old) old.remove();
  if (!role || !role.type || !AUTHOR_ROLE_STYLES[role.type]) return;
  const style = AUTHOR_ROLE_STYLES[role.type];
  row.setAttribute('data-gsa-author-role', role.type);
  const cell = row.querySelector('.gsc_a_t');
  if (!cell) return;
  const badge = document.createElement('span');
  badge.className = 'gsa-author-role-badge';
  badge.textContent = style.label;
  badge.style.cssText = `
    display:inline-flex;
    align-items:center;
    padding:2px 6px;
    border-radius:10px;
    font-size:11px;
    font-weight:600;
    margin-right:6px;
    background:${style.badge};
    color:${style.text};
  `;
  cell.insertBefore(badge, cell.firstChild);
  row.style.backgroundColor = style.row;
  row.style.boxShadow = `inset 3px 0 ${style.text}`;
}

function gsaEnsureAuthorRoleStyle() {
  if (document.getElementById('gsa-author-role-style')) return;
  const style = document.createElement('style');
  style.id = 'gsa-author-role-style';
  style.textContent = `
    .gsa-author-role-legend{display:flex;gap:8px;flex-wrap:wrap;margin-top:6px;}
    .gsa-author-role-legend-item{display:inline-flex;align-items:center;gap:6px;font-size:12px;padding:4px 8px;border-radius:8px;background:#f5f5f5;border:1px solid #e0e0e0;}
    .gsa-author-role-legend-swatch{width:12px;height:12px;border-radius:4px;display:inline-block;}
  `;
  document.head.appendChild(style);
}

function gsaRenderLegend(container) {
  if (!container) return;
  gsaEnsureAuthorRoleStyle();
  let legend = document.getElementById('gsa-author-role-legend');
  if (!legend) {
    legend = document.createElement('div');
    legend.id = 'gsa-author-role-legend';
    legend.className = 'gsa-author-role-legend';
    container.appendChild(legend);
  }
  legend.innerHTML = Object.entries(AUTHOR_ROLE_STYLES).map(([k, s]) => `
    <span class="gsa-author-role-legend-item">
      <span class="gsa-author-role-legend-swatch" style="background:${s.badge};border:1px solid ${s.text};"></span>${s.label}
    </span>
  `).join('');
}

async function gsaResolveAuthorRole(title, profileName) {
  await gsaEnsureAuthorRoleCacheLoaded();
  const cacheKey = gsaNormalizeRoleCacheKey(title, profileName);
  if (authorRoleCache.has(cacheKey)) return authorRoleCache.get(cacheKey);
  // 只请求 PubMed，避免多源带来的额外延迟
  let data = null;
  try {
    data = await gsaFetchPubmedByTitle(title);
  } catch (e) {
    console.warn('[GSA][PubMed] 获取作者信息异常', e);
    data = null;
  }
  if (!data || !data.authors) {
    console.warn('[GSA][PubMed] 未获取到作者信息', title);
    return { status: 'no_authors' };
  }
  const hasCorr = data.authors.some((a) => a.corresponding);
  const role = gsaDetermineRole(data.authors, profileName, { defaultLastAsCorr: !hasCorr });
  const result = { status: 'ok', role, authors: data.authors };
  authorRoleCache.set(cacheKey, result);
  gsaPersistAuthorRoleCache();
  return result;
}

async function gsaHighlightAuthorRoles() {
  if (isAuthorRoleRunning) return;
  const profileName = document.querySelector('#gsc_prf_in')?.textContent?.trim();
  if (!profileName) {
    showToast('未能识别个人主页作者姓名', true);
    return;
  }
  const AUTHOR_ROLE_CONCURRENCY = 4;
  const toggle = document.getElementById('gsa-author-role-toggle');
  const statusEl = document.getElementById('gsa-author-role-status');
  const setStatus = (text) => {
    if (statusEl) statusEl.textContent = text;
  };
  isAuthorRoleRunning = true;
  if (toggle) toggle.disabled = true;
  setStatus('标注中...');

  try {
    const rows = Array.from(document.querySelectorAll('.gsc_a_tr'));
    let success = 0;
    const tasks = [];
    const retryTargets = [];

    for (const row of rows) {
      const title = row.querySelector('.gsc_a_at')?.textContent?.trim();
      if (!title) continue;
      // 先用页面作者串做快速判定
      const authorText = row.querySelector('.gs_gray')?.textContent || '';
      const hasEllipsis = authorText.includes('...') || authorText.includes('…');
      const localAuthors = authorText.split(/[,;]|、/).map((s) => s.trim()).filter(Boolean).map((n) => ({ name: n }));
      const localRole = gsaDetermineRole(localAuthors, profileName, { defaultLastAsCorr: !hasEllipsis });
      tasks.push(async () => {
        let counted = false;
        if (localRole) {
          gsaApplyAuthorRoleHighlight(row, localRole);
          success += 1;
          counted = true;
        }
        const result = await gsaResolveAuthorRole(title, profileName);
        if (result?.role) {
          gsaApplyAuthorRoleHighlight(row, result.role);
          if (!counted) success += 1;
        } else {
          retryTargets.push({ row, title });
        }
      });
    }

    // 并发执行远程判定任务，加速整体标注
    let index = 0;
    const worker = async () => {
      while (index < tasks.length) {
        const current = index++;
        await tasks[current]();
        setStatus(`标注中... (${Math.min(current + 1, tasks.length)}/${tasks.length})`);
      }
    };

    const workerCount = Math.min(AUTHOR_ROLE_CONCURRENCY, tasks.length || 1);
    await Promise.all(Array.from({ length: workerCount }, () => worker()));

    // 二次重试机制：对第一次未命中的条目串行重试，降低波动
    if (retryTargets.length > 0) {
      for (let i = 0; i < retryTargets.length; i++) {
        const { row, title } = retryTargets[i];
        setStatus(`二次重试 ${i + 1}/${retryTargets.length}...`);
        // 轻微延迟，避免接口限流
        await sleep(800);
        const result = await gsaResolveAuthorRole(title, profileName);
        if (result?.role) {
          gsaApplyAuthorRoleHighlight(row, result.role);
          success += 1;
        }
      }
    }

    setStatus('自动标注');
    gsaRenderLegend(document.querySelector('#gsc_prf'));
    showToast(`作者标注完成，成功 ${success}/${rows.length}`, success === 0);
  } finally {
    setStatus(toggle?.checked ? '自动标注' : '已关闭');
    if (toggle) toggle.disabled = false;
    isAuthorRoleRunning = false;
  }
}

function gsaAddAuthorRoleButton() {
  if (!location.pathname.includes('/citations')) return;
  const nameBlock = document.querySelector('#gsc_prf_in')?.parentElement;
  if (!nameBlock) return;
  if (document.getElementById('gsa-author-role-toggle')) return;
  gsaEnsureAuthorRoleStyle();
  const wrap = document.createElement('div');
  wrap.style.cssText = 'margin-top:6px;display:flex;align-items:center;gap:8px;';
  const label = document.createElement('span');
  label.textContent = '自动标注作者';
  label.style.cssText = 'font-size:12px;color:#333;';
  const toggle = document.createElement('input');
  toggle.type = 'checkbox';
  toggle.id = 'gsa-author-role-toggle';
  toggle.style.cssText = 'width:32px;height:16px;cursor:pointer;';
  const status = document.createElement('span');
  status.id = 'gsa-author-role-status';
  status.style.cssText = 'font-size:12px;color:#555;';
  status.textContent = '自动标注';
  wrap.appendChild(label);
  wrap.appendChild(toggle);
  wrap.appendChild(status);
  nameBlock.appendChild(wrap);
  gsaRenderLegend(document.querySelector('#gsc_prf'));

  chrome.storage.local.get([AUTHOR_ROLE_AUTO_KEY], (res) => {
    const enabled = res[AUTHOR_ROLE_AUTO_KEY] !== false; // 默认开启
    toggle.checked = enabled;
    if (enabled) {
      gsaHighlightAuthorRoles();
    } else {
      status.textContent = '已关闭';
    }
  });

  toggle.addEventListener('change', () => {
    chrome.storage.local.set({ [AUTHOR_ROLE_AUTO_KEY]: toggle.checked }, () => {});
    if (toggle.checked) {
      gsaHighlightAuthorRoles();
    } else {
      status.textContent = '已关闭';
    }
  });
}

// ---------------- 个人主页 m-index（引用统计增强） ----------------
function gsaEnsureMIndexStyle() {
  let style = document.getElementById('gsa-m-index-style');
  if (!style) {
    style = document.createElement('style');
  }
  style.id = 'gsa-m-index-style';
  style.textContent = `
    #gsa-m-index-row .gsa-m-index-label{cursor:pointer;text-decoration:none;text-underline-offset:2px;color:inherit;}
    #gsa-m-index-row .gsa-m-index-label:hover{text-decoration:underline;}
    #gsa-m-index-row .gsa-m-index-main,
    #gsa-m-index-row .gsa-m-index-years{font-size:inherit;font-weight:400;line-height:inherit;color:inherit;white-space:nowrap;}
    #gsa-m-index-row[data-gsa-m-index-state="error"] .gsa-m-index-main{color:#777;}
  `;
  if (!style.parentElement) {
    document.head.appendChild(style);
  }
}

function gsaParseMetricNumber(text) {
  const match = String(text || '').replace(/,/g, '').match(/\d+(?:\.\d+)?/);
  return match ? Number(match[0]) : null;
}

function gsaGetCitationStatsTable() {
  return document.querySelector('#gsc_rsb_st') ||
    document.querySelector('#gsc_rsb_cit table') ||
    Array.from(document.querySelectorAll('table')).find((table) => {
      const text = table.textContent || '';
      return /h\s*-?\s*index/i.test(text) || /h\s*指数/.test(text) || /h指数/.test(text);
    });
}

function gsaFindCitationMetricRow(matcher) {
  const table = gsaGetCitationStatsTable();
  if (!table) return null;
  return Array.from(table.querySelectorAll('tr')).find((row) => {
    const firstCell = row.querySelector('td, th');
    const label = String(firstCell?.textContent || '').trim().toLowerCase();
    const compactLabel = label.replace(/\s+/g, '').replace(/[：:]/g, '');
    return matcher(label, compactLabel);
  }) || null;
}

function gsaFindHIndexRow() {
  return gsaFindCitationMetricRow((label, compactLabel) => {
    return /h\s*-?\s*index/.test(label) || compactLabel === 'h指数' || compactLabel === 'h-index';
  });
}

function gsaFindI10IndexRow() {
  return gsaFindCitationMetricRow((label, compactLabel) => {
    return /i10\s*-?\s*index/.test(label) ||
      compactLabel === 'i10指数' ||
      compactLabel === 'i10-index' ||
      compactLabel === 'i10index';
  });
}

function gsaGetAllTimeHIndex() {
  const row = gsaFindHIndexRow();
  if (!row) return null;
  const cells = Array.from(row.querySelectorAll('td, th')).slice(1);
  return gsaParseMetricNumber(cells[0]?.textContent);
}

function gsaExtractPublicationYears(root = document) {
  const currentYear = new Date().getFullYear();
  const years = [];
  const rows = root.matches?.('.gsc_a_tr')
    ? [root]
    : Array.from(root.querySelectorAll('.gsc_a_tr'));
  rows.forEach((row) => {
    const yearText = row.querySelector('.gsc_a_y span, .gsc_a_y')?.textContent || '';
    const match = String(yearText).match(/\b(?:19|20)\d{2}\b/);
    if (!match) return;
    const year = Number(match[0]);
    if (year >= 1900 && year <= currentYear + 1) {
      years.push(year);
    }
  });
  return Array.from(new Set(years)).sort((a, b) => a - b);
}

function gsaBuildProfileWorksUrl(cstart = 0, pagesize = 100) {
  const currentParams = new URLSearchParams(location.search);
  const user = currentParams.get('user');
  if (!user) return '';
  const url = new URL('/citations', location.origin);
  const hl = currentParams.get('hl') || document.documentElement.lang;
  if (hl) url.searchParams.set('hl', hl);
  url.searchParams.set('user', user);
  url.searchParams.set('cstart', String(cstart));
  url.searchParams.set('pagesize', String(pagesize));
  const sortby = currentParams.get('sortby');
  if (sortby) url.searchParams.set('sortby', sortby);
  return url.toString();
}

async function gsaFetchAllPublicationYears(signal) {
  const pagesize = 100;
  const maxProfilePages = 30;
  const years = [];
  const seenWorks = new Set();

  for (let page = 0; page < maxProfilePages; page++) {
    const url = gsaBuildProfileWorksUrl(page * pagesize, pagesize);
    if (!url) break;
    const res = await fetch(url, { credentials: 'include', signal });
    if (!res.ok) {
      throw new Error(`论文列表请求失败: ${res.status}`);
    }
    const html = await res.text();
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const rows = Array.from(doc.querySelectorAll('.gsc_a_tr'));
    if (rows.length === 0) break;

    let newWorkCount = 0;
    rows.forEach((row) => {
      const titleLink = row.querySelector('.gsc_a_at');
      const title = titleLink?.textContent?.trim() || '';
      const href = titleLink?.getAttribute('href') || '';
      let workKey = title;
      if (href) {
        try {
          const hrefUrl = new URL(href, location.href);
          workKey = hrefUrl.searchParams.get('citation_for_view') || href;
        } catch {
          workKey = href;
        }
      }
      if (workKey && !seenWorks.has(workKey)) {
        seenWorks.add(workKey);
        newWorkCount += 1;
      }
      years.push(...gsaExtractPublicationYears(row));
    });

    if (rows.length < pagesize || (page > 0 && newWorkCount === 0)) break;
  }

  return {
    years: Array.from(new Set(years)).sort((a, b) => a - b),
    publicationCount: seenWorks.size
  };
}

function gsaEnsureMIndexRow() {
  const table = gsaGetCitationStatsTable();
  const hIndexRow = gsaFindHIndexRow();
  const anchorRow = gsaFindI10IndexRow() || hIndexRow;
  if (!table || !hIndexRow) return null;
  gsaEnsureMIndexStyle();

  let row = document.getElementById('gsa-m-index-row');
  if (row) {
    if (anchorRow && row.previousElementSibling !== anchorRow) {
      anchorRow.insertAdjacentElement('afterend', row);
    }
    return row;
  }

  row = document.createElement('tr');
  row.id = 'gsa-m-index-row';
  const referenceCells = Array.from(anchorRow.children);
  const columnCount = Math.max(referenceCells.length, 3);
  for (let i = 0; i < columnCount; i++) {
    const cell = document.createElement('td');
    cell.className = referenceCells[i]?.className || (i === 0 ? 'gsc_rsb_sc1' : 'gsc_rsb_std');
    if (i === 0) {
      const label = document.createElement('span');
      label.className = 'gsa-m-index-label';
      label.textContent = 'm 指数';
      label.title = 'm-index = h-index / 学术年龄；学术年龄按最早发表年至当前年包含首尾年份计算。';
      cell.appendChild(label);
    } else if (i === 1) {
      cell.classList.add('gsa-m-index-value-cell');
      cell.innerHTML = '<span class="gsa-m-index-main">计算中...</span>';
    } else {
      cell.classList.add('gsa-m-index-range-cell');
      cell.textContent = '--';
    }
    row.appendChild(cell);
  }
  anchorRow.insertAdjacentElement('afterend', row);
  return row;
}

function gsaRenderMIndexRow(state) {
  const row = gsaEnsureMIndexRow();
  if (!row) return;
  const labelEl = row.querySelector('.gsa-m-index-label');
  const valueCell = row.querySelector('.gsa-m-index-value-cell') || row.children[1];
  const rangeCell = row.querySelector('.gsa-m-index-range-cell') || row.children[2];
  row.dataset.gsaMIndexState = state.status || '';

  if (state.status === 'success') {
    const explanation = `m-index = h-index / 学术年龄 = ${state.hIndex} / ${state.academicYears}；发表年份范围 ${state.firstYear}-${state.latestYear}；来源: ${state.source === 'full' ? '全部论文列表' : '当前可见论文列表'}`;
    if (labelEl) labelEl.title = explanation;
    valueCell.innerHTML = `<span class="gsa-m-index-main">${state.mIndex.toFixed(2)}</span>`;
    valueCell.title = explanation;
    if (rangeCell) {
      rangeCell.innerHTML = `<span class="gsa-m-index-years">${state.firstYear}-${state.latestYear}</span>`;
      rangeCell.title = explanation;
    }
    return;
  }

  if (state.status === 'loading') {
    if (labelEl) labelEl.title = 'm-index = h-index / 学术年龄；正在读取论文发表年份。';
    valueCell.innerHTML = '<span class="gsa-m-index-main">计算中...</span>';
    valueCell.title = '';
    if (rangeCell) rangeCell.textContent = '--';
    return;
  }

  if (labelEl) labelEl.title = state.message || '未能计算 m-index';
  valueCell.innerHTML = '<span class="gsa-m-index-main">--</span>';
  valueCell.title = state.message || '未能计算 m-index';
  if (rangeCell) {
    rangeCell.textContent = '--';
    rangeCell.title = state.message || '未能计算 m-index';
  }
}

async function gsaAddMIndexMetric() {
  if (!location.pathname.includes('/citations')) return;
  if (!gsaEnsureMIndexRow()) return;

  const hIndex = gsaGetAllTimeHIndex();
  if (!hIndex && hIndex !== 0) {
    gsaRenderMIndexRow({ status: 'error', message: '未能读取 h-index' });
    return;
  }

  gsaRenderMIndexRow({ status: 'loading' });

  const visibleYears = gsaExtractPublicationYears(document);
  let years = visibleYears;
  let source = 'visible';
  const hasProfileWorks = !!gsaBuildProfileWorksUrl(0, 100);

  if (hasProfileWorks) {
    if (gsaMIndexController) {
      gsaMIndexController.abort();
    }
    const controller = new AbortController();
    gsaMIndexController = controller;
    try {
      const fetched = await gsaFetchAllPublicationYears(controller.signal);
      if (fetched.years.length > 0) {
        years = fetched.years;
        source = 'full';
      }
    } catch (error) {
      if (error?.name === 'AbortError') return;
      console.warn('[GSA][m-index] 获取完整论文发表年份失败，退回当前可见列表年份', error);
    } finally {
      if (gsaMIndexController === controller) {
        gsaMIndexController = null;
      }
    }
  }

  if (!years || years.length === 0) {
    gsaRenderMIndexRow({ status: 'error', message: '未能读取论文发表年份' });
    return;
  }

  const firstYear = Math.min(...years);
  const latestYear = Math.max(new Date().getFullYear(), ...years);
  const academicYears = Math.max(1, latestYear - firstYear + 1);
  const mIndex = hIndex / academicYears;
  gsaRenderMIndexRow({
    status: 'success',
    hIndex,
    firstYear,
    latestYear,
    academicYears,
    mIndex,
    source
  });
}

function gsaScheduleMIndexMetric(attempt = 0) {
  if (!location.pathname.includes('/citations')) return;
  const table = gsaGetCitationStatsTable();
  const hIndexRow = gsaFindHIndexRow();
  if (table && hIndexRow) {
    gsaAddMIndexMetric();
    return;
  }
  if (attempt < 5) {
    setTimeout(() => gsaScheduleMIndexMetric(attempt + 1), 500);
  }
}
async function downloadRisForTitles(titles, options = {}) {
  const results = [];
  const risEntries = [];
  let firstSuccess = null;

  for (const title of titles) {
    // 顺序处理，避免触发接口限流
    const outcome = await resolveRisForTitle(title, options);
    results.push(outcome);

    if (outcome.status === 'success') {
      if (outcome.ris) {
        risEntries.push(outcome.ris);
      }
      if (!firstSuccess) {
        firstSuccess = outcome;
      }
    } else if (outcome.status === 'not_found') {
      console.warn('未找到匹配的 DOI:', title);
    } else if (outcome.error) {
      console.error(`获取引用信息失败 (${title}):`, outcome.error);
    }
  }

  if (risEntries.length === 0) {
    const firstError = results.find((item) => item && item.error);
    if (firstError?.error instanceof Error) {
      throw new Error(`未能获取任何论文的引用信息: ${firstError.error.message}`);
    }
    throw new Error('未能获取任何论文的引用信息');
  }

  const risContent = risEntries.join('\n\n');

  const now = new Date();
  const datePart = [
    now.getFullYear(),
    String(now.getMonth() + 1).padStart(2, '0'),
    String(now.getDate()).padStart(2, '0'),
  ].join('');
  const timePart = [
    String(now.getHours()).padStart(2, '0'),
    String(now.getMinutes()).padStart(2, '0'),
    String(now.getSeconds()).padStart(2, '0'),
  ].join('');

  const baseName = `citations_${datePart}_${timePart}`;

  downloadFile(risContent, `${baseName}.ris`, 'application/x-research-info-systems');

  return results;
}

// 加载CSV文件并解析
async function loadCSVData() {
  try {
    // 加载新锐分区数据
    const zkyfqResponse = await fetch(chrome.runtime.getURL('/data/XR2026-UTF8.csv'));
    const zkyfqText = await zkyfqResponse.text();
    parseZkyfqCSV(zkyfqText);

    // 加载jcrfq.csv
    const jcrfqResponse = await fetch(chrome.runtime.getURL('/data/jcrfq.csv'));
    const jcrfqText = await jcrfqResponse.text();
    parseJcrfqCSV(jcrfqText);

    console.log('CSV数据加载完成');
    console.log(`期刊数据统计: 新锐分区=${Object.keys(zkyfqMap).length}, JCR分区=${Object.keys(jcrfqMap).length}`);
  } catch (error) {
    console.error('加载CSV文件时出错:', error);
  }
}

// 解析新锐分区 CSV
function parseZkyfqCSV(csvText) {
  const lines = csvText.split(/\r?\n/);
  const headers = parseCSVLine(lines[0]);

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (line === '') continue;
    const values = parseCSVLine(line);
    const record = {};
    headers.forEach((header, index) => {
      record[header] = values[index] || '';
    });
    const processedJournal = processJournalName(record['Journal']);
    if (!processedJournal) continue;

    const majorQuartile = (record['大类新锐分区'] || '').replace(/[^1-4]/g, '');
    const topFlag = String(record['Top'] || '').trim();
    zkyfqMap[processedJournal] = {
      大类分区: majorQuartile || '未知',
      Top: /^top$/i.test(topFlag) ? '是' : '否'
    };
  }
}

// 解析jcrfq.csv
function parseJcrfqCSV(csvText) {
  const lines = csvText.split('\n');
  const headers = parseCSVLine(lines[0]).map(header => header.replace(/^\uFEFF/, ''));

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (line === '') continue;
    const values = parseCSVLine(line);
    const record = {};
    headers.forEach((header, index) => {
      record[header] = values[index] || '';
    });
    const processedJournal = processJournalName(record['Journal']);
    jcrfqMap[processedJournal] = {
      IF_2023: record['IF(2025)'] || record['IF(2024)'] || '未知',
      IF_Quartile: record['IF Quartile'] || '未知'
    };
  }
}

// 辅助函数：解析CSV行，正确处理引号
function parseCSVLine(line) {
  const result = [];
  let start = 0;
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    if (line[i] === '"') {
      inQuotes = !inQuotes;
    } else if (line[i] === ',' && !inQuotes) {
      result.push(line.substring(start, i).trim().replace(/^"|"$/g, ''));
      start = i + 1;
    }
  }
  result.push(line.substring(start).trim().replace(/^"|"$/g, ''));

  return result;
}

function resetCustomPartitionData() {
  customPartitions = [];
  customPartitionIndex = new Map();
  enabledCustomPartitionIds = new Set();
}

function sanitizeCustomPartitionId(id) {
  return String(id || '')
    .trim()
    .replace(/[^a-zA-Z0-9_-]/g, '-');
}

function createCustomPartitionId(name) {
  const normalizedName = String(name || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '') || 'partition';
  const timestamp = Date.now().toString(36);
  return sanitizeCustomPartitionId(`cp-${normalizedName}-${timestamp}`);
}

function rebuildCustomPartitionIndex() {
  customPartitionIndex = new Map();
  customPartitions.forEach((partition) => {
    customPartitionIndex.set(partition.id, partition);
  });
}

function normalizeCustomPartitionEntry(entry) {
  if (!entry || typeof entry !== 'object') {
    return null;
  }

  const name = String(entry.name || '').trim();
  if (!name) {
    return null;
  }

  const rawMap = entry.map && typeof entry.map === 'object' ? entry.map : {};
  const normalizedMap = {};
  Object.entries(rawMap).forEach(([key, value]) => {
    if (!key) return;
    const partitionValue = value === undefined || value === null ? '' : String(value).trim();
    if (!partitionValue) return;
    normalizedMap[key] = partitionValue;
  });

  const valueSource = Array.isArray(entry.values) ? entry.values : Object.values(normalizedMap);
  const normalizedValues = Array.from(new Set(valueSource
    .map(item => String(item || '').trim())
    .filter(Boolean)))
    .sort((a, b) => a.localeCompare(b, 'zh-Hans-CN', { numeric: true }));

  const ensuredId = sanitizeCustomPartitionId(entry.id) || createCustomPartitionId(name);

  return {
    id: ensuredId,
    name,
    map: normalizedMap,
    values: normalizedValues
  };
}

function applyCustomPartitionData(rawData) {
  resetCustomPartitionData();
  if (!rawData || typeof rawData !== 'object') {
    return;
  }

  let partitions = [];

  if (Array.isArray(rawData.partitions)) {
    partitions = rawData.partitions
      .map(normalizeCustomPartitionEntry)
      .filter(Boolean);
  } else if (rawData.map && rawData.name) {
    const legacyPartition = normalizeCustomPartitionEntry({
      id: rawData.id,
      name: rawData.name,
      map: rawData.map,
      values: rawData.values
    });
    if (legacyPartition) {
      partitions = [legacyPartition];
    }
  }

  if (partitions.length === 0) {
    return;
  }

  customPartitions = partitions.sort((a, b) => a.name.localeCompare(b.name, 'zh-Hans-CN'));
  rebuildCustomPartitionIndex();

  const enabledIds = Array.isArray(rawData.enabledPartitionIds)
    ? rawData.enabledPartitionIds
    : Array.isArray(rawData.enabled)
      ? rawData.enabled
      : [];

  enabledIds.forEach((id) => {
    const sanitizedId = sanitizeCustomPartitionId(id);
    if (sanitizedId && customPartitionIndex.has(sanitizedId)) {
      enabledCustomPartitionIds.add(sanitizedId);
    }
  });

  if (enabledCustomPartitionIds.size === 0) {
    customPartitions.forEach(partition => enabledCustomPartitionIds.add(partition.id));
  }
}

function hasCustomPartitionData() {
  return customPartitions.length > 0;
}

function getAllCustomPartitions() {
  return customPartitions.slice();
}

function getEnabledCustomPartitions() {
  return customPartitions.filter(partition => enabledCustomPartitionIds.has(partition.id));
}

function getCustomPartitionEntriesForJournal(processedJournal, options = {}) {
  const { enabledOnly = false } = options;
  const partitions = enabledOnly ? getEnabledCustomPartitions() : customPartitions;
  if (!processedJournal || partitions.length === 0) {
    return [];
  }
  return partitions.map(partition => ({
    id: partition.id,
    name: partition.name,
    value: partition.map[processedJournal] || ''
  }));
}

function persistCustomPartitionState() {
  if (customPartitions.length === 0) {
    return new Promise((resolve, reject) => {
      chrome.storage.local.remove([CUSTOM_PARTITION_STORAGE_KEY], () => {
        const error = chrome.runtime?.lastError;
        if (error) {
          reject(new Error(error.message));
        } else {
          resolve();
        }
      });
    });
  }

  const payload = {
    version: 2,
    partitions: customPartitions.map(partition => ({
      id: partition.id,
      name: partition.name,
      map: partition.map,
      values: partition.values
    })),
    enabledPartitionIds: Array.from(enabledCustomPartitionIds)
  };

  return new Promise((resolve, reject) => {
    chrome.storage.local.set({ [CUSTOM_PARTITION_STORAGE_KEY]: payload }, () => {
      const error = chrome.runtime?.lastError;
      if (error) {
        reject(new Error(error.message));
      } else {
        resolve();
      }
    });
  });
}

function addOrUpdateCustomPartition(partitionName, parsedData) {
  const sanitizedName = String(partitionName || '').trim();
  if (!sanitizedName) {
    throw new Error('分区名称不能为空');
  }

  const existing = customPartitions.find(partition => partition.name === sanitizedName);
  const normalizedEntry = normalizeCustomPartitionEntry({
    id: existing?.id,
    name: sanitizedName,
    map: parsedData.map,
    values: parsedData.values
  });

  if (!normalizedEntry) {
    throw new Error('无法保存自定义分区数据');
  }

  if (existing) {
    const index = customPartitions.findIndex(partition => partition.id === existing.id);
    customPartitions[index] = normalizedEntry;
  } else {
    customPartitions.push(normalizedEntry);
  }

  rebuildCustomPartitionIndex();
  enabledCustomPartitionIds.add(normalizedEntry.id);

  // 保持按名称排序，便于展示
  customPartitions.sort((a, b) => a.name.localeCompare(b.name, 'zh-Hans-CN'));
  rebuildCustomPartitionIndex();

  return persistCustomPartitionState();
}

function setCustomPartitionEnabled(partitionId, enabled) {
  const sanitizedId = sanitizeCustomPartitionId(partitionId);
  if (!sanitizedId || !customPartitionIndex.has(sanitizedId)) {
    return Promise.resolve();
  }

  const alreadyEnabled = enabledCustomPartitionIds.has(sanitizedId);
  if (enabled && alreadyEnabled) {
    return Promise.resolve();
  }

  if (!enabled && !alreadyEnabled) {
    return Promise.resolve();
  }

  if (enabled) {
    enabledCustomPartitionIds.add(sanitizedId);
  } else {
    enabledCustomPartitionIds.delete(sanitizedId);
  }

  return persistCustomPartitionState();
}

function removeCustomPartition(partitionId) {
  const sanitizedId = sanitizeCustomPartitionId(partitionId);
  if (!sanitizedId) {
    return Promise.resolve();
  }

  const index = customPartitions.findIndex(partition => partition.id === sanitizedId);
  if (index === -1) {
    return Promise.resolve();
  }

  customPartitions.splice(index, 1);
  enabledCustomPartitionIds.delete(sanitizedId);
  rebuildCustomPartitionIndex();

  if (enabledCustomPartitionIds.size === 0) {
    customPartitions.forEach(partition => enabledCustomPartitionIds.add(partition.id));
  }

  return persistCustomPartitionState();
}

function ensureXlsxLibraryLoaded() {
  if (typeof XLSX !== 'undefined') {
    return Promise.resolve();
  }

  if (!xlsxLibraryPromise) {
    xlsxLibraryPromise = new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = chrome.runtime.getURL('libs/xlsx.full.min.js');
      script.onload = () => resolve();
      script.onerror = () => reject(new Error('无法加载XLSX解析库，请重试')); // 指导用户重试
      document.head.appendChild(script);
    });
  }

  return xlsxLibraryPromise;
}

function readFileAsArrayBuffer(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => resolve(event.target.result);
    reader.onerror = () => reject(new Error('读取文件失败，请重试'));
    reader.readAsArrayBuffer(file);
  });
}

async function parseCustomPartitionXlsx(file) {
  if (!file) {
    throw new Error('未选择文件');
  }

  if (!/\.xlsx$/i.test(file.name)) {
    throw new Error('请上传.xlsx格式的文件');
  }

  await ensureXlsxLibraryLoaded();
  const arrayBuffer = await readFileAsArrayBuffer(file);
  const workbook = XLSX.read(arrayBuffer, { type: 'array' });
  const [firstSheetName] = workbook.SheetNames;

  if (!firstSheetName) {
    throw new Error('上传的文件中缺少工作表');
  }

  const worksheet = workbook.Sheets[firstSheetName];
  const rows = XLSX.utils.sheet_to_json(worksheet, { header: 1, blankrows: false });

  if (!Array.isArray(rows) || rows.length < 2) {
    throw new Error('文件中缺少数据，请确认包含表头和至少一行内容');
  }

  const headerRow = rows[0].map(cell => String(cell || '').trim());
  const partitionIndex = headerRow.findIndex(title => title === '分区');
  const journalIndex = headerRow.findIndex(title => title === '期刊');

  if (partitionIndex === -1 || journalIndex === -1) {
    throw new Error('表头需包含“分区”和“期刊”两列');
  }

  const map = {};
  const partitionValues = new Set();
  let validCount = 0;

  for (let i = 1; i < rows.length; i++) {
    const row = rows[i];
    if (!row) continue;
    const partitionCell = row[partitionIndex];
    const journalCell = row[journalIndex];
    const partition = partitionCell === undefined || partitionCell === null ? '' : String(partitionCell).trim();
    const journalName = journalCell === undefined || journalCell === null ? '' : String(journalCell).trim();
    if (!partition || !journalName) continue;
    const processedJournal = processJournalName(journalName);
    if (!processedJournal) continue;
    map[processedJournal] = partition;
    partitionValues.add(partition);
    validCount += 1;
  }

  if (validCount === 0) {
    throw new Error('未找到有效的分区数据，请检查是否包含正确的期刊名称和分区值');
  }

  return {
    map,
    values: Array.from(partitionValues).sort((a, b) => a.localeCompare(b, 'zh-Hans-CN', { numeric: true })),
    count: validCount
  };
}

function loadCustomPartitionFromStorage() {
  return new Promise((resolve) => {
    chrome.storage.local.get([CUSTOM_PARTITION_STORAGE_KEY], (result) => {
      applyCustomPartitionData(result[CUSTOM_PARTITION_STORAGE_KEY]);
      resolve();
    });
  });
}

// 提取标题、期刊信息和索引
function extractTitlesAndJournals() {
  const papers = [];
  const paperElements = document.querySelectorAll('.gs_r.gs_or.gs_scl');

  paperElements.forEach(element => {
    const titleElement = element.querySelector('.gs_rt a');
    const venueElement = element.querySelector('.gs_a');
    const snippetElement = element.querySelector('.gs_rs'); // 提取摘要或索引内容
    const link = titleElement ? titleElement.href : '';
    const indexHTML = venueElement ? venueElement.innerHTML.trim() : '';
    const snippetHTML = snippetElement ? snippetElement.innerHTML.trim() : ''; // 提取摘要

    if (titleElement && venueElement) {
      const title = titleElement.textContent.trim();
      let journal = extractJournalInfo(venueElement.textContent);
      const elid = titleElement.id;
      const processedJournal = processJournalName(journal); // 添加处理后的期刊名称

      // 获取额外信息
      const zkyInfo = zkyfqMap[processedJournal] || { 大类分区: '未知', Top: '否' };
      const jcrInfo = jcrfqMap[processedJournal] || { IF_2023: '未知', IF_Quartile: '未知' };
      papers.push({
        title,
        journal,
        processedJournal,
        elid,
        link,
        indexHTML,
        snippetHTML,
        大类分区: zkyInfo.大类分区,
        Top: zkyInfo.Top,
        IF_2023: jcrInfo.IF_2023,
        IF_Quartile: jcrInfo.IF_Quartile
      }); // 加入摘要和处理后的期称及额外信息
    }
  });

  return papers;
}


// 从 venue 文本中提取期刊信息
function extractJournalInfo(venueText) {
  let r1 = venueText.indexOf(String.fromCharCode(160) + "- ");
  if (r1 === -1) return '未知';
  let journal2 = venueText.substring(r1 + 3);
  let r2 = journal2.indexOf(" - ");
  if (r2 === -1) return '未知';
  let journal = venueText.substring(r1 + 3, r1 + 3 + r2);
  journal = journal.replace(/, \d{4}/, "");
  return journal;
}

// 处理期刊名称
function processJournalName(journal) {
  return journal.toUpperCase()
                .replace(/&AMP;/g, "&")
                .replace(/ AND /g, "")
                .replace(/^THE /g, "")
                .replace(/, THE$/g, "")
                .normalize('NFD')
                .replace(/[^A-Z0-9]/ig, "");
}

// 延时函数
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// 获取期刊信息
async function fetchJournalInfo(papers) {
  const processedPapers = [];

  // 显示"正在匹配期刊信息，请稍等..."提示
  showMatchingStatus('正在匹配期刊信息，请稍等...', true);

  // 将papers分成多个批次，每批次20个
  const batchSize = 50;
  const batches = [];
  for (let i = 0; i < papers.length; i += batchSize) {
    batches.push(papers.slice(i, i + batchSize));
  }

  for (const batch of batches) {
    const batchPromises = batch.map(async (paper) => {
      let journal = paper.journal;

      if (journal === '未知' || journal.includes('…')) {
        try {
          const full_url = window.location.origin + "/scholar";
          const cite_link = `${full_url}?q=info:${paper.elid}:scholar.google.com/&output=cite&scirp=8&hl=de`;

          const response = await fetch(cite_link);
          const result = await response.text();

          let pos_start = result.indexOf("<i>", 1);
          let pos_end = result.indexOf("</i>", 1);
          let scholar_journal = result.substring(pos_start + 3, pos_end);

          if (scholar_journal && scholar_journal !== "<d") {
            journal = scholar_journal.toUpperCase();
          } else {
            journal = '未知';
          }
        } catch (error) {
          console.error(`获取期刊信息时出错: ${error}`);
          journal = '获取失败';
        }
      }

      // 将期刊名称转换为大写
      journal = journal.toUpperCase();

      const processedJournal = processJournalName(journal);

      // 获取额外信息
      const zkyInfo = zkyfqMap[processedJournal] || { 大类分区: '未知', Top: '否' };
      const jcrInfo = jcrfqMap[processedJournal] || { IF_2023: '未知', IF_Quartile: '未知' };

      return {
        ...paper,
        journal: journal,
        processedJournal: processedJournal,
        大类分区: zkyInfo.大类分区,
        Top: zkyInfo.Top,
        IF_2023: jcrInfo.IF_2023,
        IF_Quartile: jcrInfo.IF_Quartile
      };
    });

    const batchResults = await Promise.all(batchPromises);
    processedPapers.push(...batchResults);

    // 每处理完一批次，暂停200毫秒
    await sleep(100);
  }

  // 隐藏"正在匹配期刊信息，请稍等..."提示，显示"匹配完成"提示
  showMatchingStatus('匹配完成', false);

  return processedPapers;
}


// 显示提取的论文和期刊信息
function displayTitlesWithJournals(papers) {
  let resultsDiv = document.getElementById('extracted-titles');
  if (!resultsDiv) {
    resultsDiv = document.createElement('div');
    resultsDiv.id = 'extracted-titles';
    resultsDiv.setAttribute('data-theme', localStorage.getItem('theme') || 'light');
    resultsDiv.style.cssText = `
      position: fixed;
      bottom: 10px;
      right: 10px;
      background: white;
      color: black;
      padding: 25px;
      border: none;
      height: 85vh;
      width: 90%;
      max-width: 1200px;
      overflow-y: auto;
      z-index: 1000;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
      border-radius: 12px;
      display: flex;
      flex-direction: column;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      transition: background-color 0.3s, color 0.3s;
    `;
    document.body.appendChild(resultsDiv);
  }

  const activePartitions = {
    ...DEFAULT_DISPLAY_PARTITIONS,
    ...(displayPartitions || {})
  };
  const { showIF, showJCR, showCAS, showCustom } = activePartitions;
  const enabledCustomPartitions = getEnabledCustomPartitions();
  const hasCustomPartition = showCustom && enabledCustomPartitions.length > 0;

  const hasMeaningfulValue = (value) => {
    if (value === undefined || value === null) return false;
    const normalized = String(value).trim();
    return normalized !== '' && normalized !== '未知';
  };

  function buildCasLabel(zone, topFlag) {
    if (!hasMeaningfulValue(zone)) return '';
    const zoneValue = String(zone).trim();
    const baseLabel = `新锐${zoneValue}区`;
    return topFlag === '是' ? `${baseLabel}TOP` : baseLabel;
  }

  function buildCustomLabel(partitionName, value) {
    if (!hasMeaningfulValue(value)) return '';
    return `${partitionName} ${value}`;
  }

  function escapeAttribute(value) {
    if (value === undefined || value === null) return '';
    return String(value).replace(/"/g, '&quot;');
  }

  function buildJournalTooltip(paper) {
    const segments = [];
    if (showIF && hasMeaningfulValue(paper.IF_2023)) {
      segments.push(`IF: ${paper.IF_2023}`);
    }
    if (showJCR && hasMeaningfulValue(paper.IF_Quartile)) {
      segments.push(`JCR: ${paper.IF_Quartile}`);
    }
    if (showCAS) {
      const casLabel = buildCasLabel(paper.大类分区, paper.Top);
      if (casLabel) segments.push(casLabel);
    }
    if (hasCustomPartition) {
      enabledCustomPartitions.forEach((partition) => {
        const value = partition.map[paper.processedJournal] || '';
        const label = buildCustomLabel(partition.name, value);
        if (label) segments.push(label);
      });
    }
    return segments.length > 0 ? `${paper.journal} | ${segments.join(' | ')}` : paper.journal;
  }

  function buildJournalInfoTags(journalKey) {
    const tags = [];
    if (showIF) {
      const ifValue = jcrfqMap[journalKey]?.IF_2023;
      if (hasMeaningfulValue(ifValue)) {
        tags.push(`<span class="info-tag if-tag">IF: ${ifValue}</span>`);
      }
    }
    if (showJCR) {
      const quartile = jcrfqMap[journalKey]?.IF_Quartile;
      if (hasMeaningfulValue(quartile)) {
        tags.push(`<span class="info-tag jcr-tag">JCR: ${quartile}</span>`);
      }
    }
    if (showCAS) {
      const casInfo = zkyfqMap[journalKey] || {};
      const casLabel = buildCasLabel(casInfo.大类分区, casInfo.Top);
      if (casLabel) {
        tags.push(`<span class="info-tag cas-tag">${casLabel}</span>`);
      }
    }
    if (hasCustomPartition) {
      enabledCustomPartitions.forEach((partition) => {
        const customValue = partition.map[journalKey] || '';
        const customLabel = buildCustomLabel(partition.name, customValue);
        if (customLabel) {
          tags.push(`<span class="info-tag custom-tag">${customLabel}</span>`);
        }
      });
    }
    return tags.join('');
  }

  function buildPaperInfoTags(paper) {
    const tags = [];
    if (showIF && hasMeaningfulValue(paper.IF_2023)) {
      tags.push(`<span class="info-tag if-tag">IF: ${paper.IF_2023}</span>`);
    }
    if (showJCR && hasMeaningfulValue(paper.IF_Quartile)) {
      tags.push(`<span class="info-tag jcr-tag">JCR: ${paper.IF_Quartile}</span>`);
    }
    if (showCAS) {
      const casLabel = buildCasLabel(paper.大类分区, paper.Top);
      if (casLabel) {
        tags.push(`<span class="info-tag cas-tag">${casLabel}</span>`);
      }
    }
    if (hasCustomPartition) {
      enabledCustomPartitions.forEach((partition) => {
        const customValue = partition.map[paper.processedJournal] || '';
        const customLabel = buildCustomLabel(partition.name, customValue);
        if (customLabel) {
          tags.push(`<span class="info-tag custom-tag">${customLabel}</span>`);
        }
      });
    }
    return tags.join('');
  }

  function buildCustomDataAttributes(paper) {
    if (!hasCustomPartition) {
      return '';
    }
    return enabledCustomPartitions.map((partition) => {
      const customValue = partition.map[paper.processedJournal] || '';
      return ` data-custom-partition-${partition.id}="${escapeAttribute(customValue)}"`;
    }).join('');
  }

  // 统计每个处理后期刊的论文数量
  const journalCountMap = {};
  const processedJournalNameMap = {}; // 存储处理后名称对应的显示名称及额外信息
  papers.forEach(paper => {
    if (journalCountMap[paper.processedJournal]) {
      journalCountMap[paper.processedJournal]++;
    } else {
      journalCountMap[paper.processedJournal] = 1;
      processedJournalNameMap[paper.processedJournal] = buildJournalTooltip(paper);
    }
  });

  // 获取所有唯一的处理后期刊名称
  let uniqueJournals = [...new Set(papers.map(paper => paper.processedJournal))];

  // 认排序：字母序A-Z和论文数量从多到少
  uniqueJournals.sort((a, b) => {
    if (a < b) return -1;
    if (a > b) return 1;
    return journalCountMap[b] - journalCountMap[a];
  });

  const ifFilterBlock = showIF ? `
          <div style="
            display: flex;
            align-items: center;
            margin-bottom: 12px;
            gap: 10px;
          ">
            <label for="if-min" style="
              font-size: 14px;
              font-weight: 500;
              color: #333;
              white-space: nowrap;
            ">最小IF值：</label>
            <input type="number" id="if-min" placeholder="最小值" style="
              flex: 1;
              padding: 6px 10px;
              border: 1px solid #e0e0e0;
              border-radius: 6px;
              font-size: 14px;
              color: #333;
              height: 32px;
              box-sizing: border-box;
            ">
          </div>` : '';

  const jcrFilterBlock = showJCR ? `
          <div style="margin-bottom: 12px;">
            <label style="
              display: block;
              margin-bottom: 5px;
              font-size: 14px;
              font-weight: 500;
              color: #333;
            ">JCR分区：</label>
            <div style="
              display: flex;
              flex-wrap: nowrap;
              gap: 5px;
              justify-content: space-between;
            ">
              <label style="display: flex; align-items: center; flex: 1;">
                <input type="checkbox" name="jcr-filter" value="Q1" style="margin-right: 3px;">
                <span style="font-size: 14px;">Q1</span>
              </label>
              <label style="display: flex; align-items: center; flex: 1;">
                <input type="checkbox" name="jcr-filter" value="Q2" style="margin-right: 3px;">
                <span style="font-size: 14px;">Q2</span>
              </label>
              <label style="display: flex; align-items: center; flex: 1;">
                <input type="checkbox" name="jcr-filter" value="Q3" style="margin-right: 3px;">
                <span style="font-size: 14px;">Q3</span>
              </label>
              <label style="display: flex; align-items: center; flex: 1;">
                <input type="checkbox" name="jcr-filter" value="Q4" style="margin-right: 3px;">
                <span style="font-size: 14px;">Q4</span>
              </label>
            </div>
          </div>` : '';

  const casFilterBlock = showCAS ? `
          <div style="margin-bottom: 12px;">
            <label style="
              display: block;
              margin-bottom: 5px;
              font-size: 14px;
              font-weight: 500;
              color: #333;
            ">新锐分区：</label>
            <div style="
              display: flex;
              flex-wrap: nowrap;
              gap: 5px;
              justify-content: space-between;
            ">
              <label style="display: flex; align-items: center; flex: 1;">
                <input type="checkbox" name="cas-filter" value="1" style="margin-right: 3px;">
                <span style="font-size: 14px;">1区</span>
              </label>
              <label style="display: flex; align-items: center; flex: 1;">
                <input type="checkbox" name="cas-filter" value="2" style="margin-right: 3px;">
                <span style="font-size: 14px;">2区</span>
              </label>
              <label style="display: flex; align-items: center; flex: 1;">
                <input type="checkbox" name="cas-filter" value="3" style="margin-right: 3px;">
                <span style="font-size: 14px;">3区</span>
              </label>
              <label style="display: flex; align-items: center; flex: 1;">
                <input type="checkbox" name="cas-filter" value="4" style="margin-right: 3px;">
                <span style="font-size: 14px;">4区</span>
              </label>
            </div>
          </div>` : '';

  const customFilterBlocks = hasCustomPartition ? enabledCustomPartitions.map((partition) => {
    const optionHtml = partition.values.length > 0
      ? partition.values.map(value => {
          const safeValue = escapeAttribute(value);
          return `
              <label style="display: flex; align-items: center; flex: 0 1 calc(33% - 5px); min-width: 60px;">
                <input type="checkbox" name="custom-filter-${partition.id}" value="${safeValue}" data-custom-filter="${partition.id}" style="margin-right: 3px;">
                <span style="font-size: 14px;">${value}</span>
              </label>`;
        }).join('')
      : '<span style="font-size: 13px; color: #777;">暂无可选项</span>';

    return `
          <div style="margin-bottom: 12px;">
            <label style="
              display: block;
              margin-bottom: 5px;
              font-size: 14px;
              font-weight: 500;
              color: #333;
            ">${partition.name}：</label>
            <div style="
              display: flex;
              flex-wrap: wrap;
              gap: 5px;
            ">
${optionHtml}
            </div>
          </div>`;
  }).join('') : '';

  const topFilterLabel = showCAS ? `
            <label style="display: flex; align-items: center;">
              <input type="checkbox" id="top-filter" style="margin-right: 5px;">
              <span class="top-filter-label" style="font-size: 14px; font-weight: 500; color: #333;">TOP期刊</span>
            </label>` : '';

  const clearFiltersButtonHtml = `
            <button id="clear-filters" class="action-button" style="
              background-color: #e0e0e0;
              color: black;
              border: none;
              padding: 4px 10px;
              border-radius: 6px;
              cursor: pointer;
              font-size: 14px;
              height: 28px;
              display: inline-flex;
              align-items: center;
              justify-content: center;
              transition: background-color 0.3s;
            ">清除筛选</button>`;

  const filterFooter = showCAS ? `
          <div style="
            display: flex;
            align-items: center;
            justify-content: space-between;
          ">
${topFilterLabel}
${clearFiltersButtonHtml}
          </div>` : `
          <div style="
            display: flex;
            align-items: center;
            justify-content: flex-end;
          ">
${clearFiltersButtonHtml}
          </div>`;

  // 修改筛选框的HTML结构
  const filterSortHtml = `
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
      <h3 style="margin: 0; color: black;">提取的论文信息 (共 ${papers.length} 篇)</h3>
      <div style="display: flex; align-items: center; gap: 10px;">
        <button id="theme-toggle-extraction" style="
          background: none;
          border: none;
          cursor: pointer;
          padding: 8px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: background-color 0.3s;
        " title="切换主题">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" style="width: 20px; height: 20px; fill: #333;" class="moon-icon-extraction">
            <path d="M12 3c.132 0 .263 0 .393 0a7.5 7.5 0 0 0 7.92 12.446a9 9 0 1 1 -8.313 -12.454z"/>
          </svg>
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" style="width: 20px; height: 20px; fill: #333; display: none;" class="sun-icon-extraction">
            <path d="M12 18a6 6 0 1 1 0-12 6 6 0 0 1 0 12zm0-2a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM11 1h2v3h-2V1zm0 19h2v3h-2v-3zM3.515 4.929l1.414-1.414L7.05 5.636 5.636 7.05 3.515 4.93zM16.95 18.364l1.414-1.414 2.121 2.121-1.414 1.414-2.121-2.121zm2.121-14.85l1.414 1.415-2.121 2.121-1.414-1.414 2.121-2.121zM5.636 16.95l1.414 1.414-2.121 2.121-1.414-1.414 2.121-2.121zM23 11v2h-3v-2h3zM4 11v2H1v-2h3z"/>
          </svg>
        </button>
        <button id="close-window" class="action-button" style="
          background-color: #d3baf8;
          color: black;
          border: none;
          width: 30px;
          height: 30px;
          border-radius: 4px;
          cursor: pointer;
          font-size: 18px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          transition: background-color 0.3s;
        ">×</button>
      </div>
    </div>
    <div class="filter-sort-container" style="
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 10px;
      gap: 15px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;
    ">
      <div style="width: 70%;">
        <label for="journal-filter" style="
          display: block;
          margin-bottom: 8px;
          font-size: 14px;
          font-weight: 500;
          color: #333;
          height: 14px; /* 固定高度与右侧标题一致 */
          line-height: 14px;
        ">筛选期刊：</label>
        <div id="journal-filter" style="
          width: 100%;
          height: 250px;
          overflow-y: auto;
          border: 1px solid #e0e0e0;
          border-radius: 8px;
          padding: 10px;
          background: #f8f9fa;
          box-sizing: border-box;
        ">
          <label style="display: flex; align-items: center; padding: 3px 0;">
            <input type="checkbox" value="all" checked style="
              margin-right: 5px;
              width: 16px;
              height: 16px;
            ">
            <span class="journal-option" style="font-size: 14px;">全部</span>
          </label>
          ${uniqueJournals.map(journal => {
            const journalInfo = papers.find(p => p.processedJournal === journal);
            return `
              <label title="${processedJournalNameMap[journal]}" style="display: flex; align-items: center; padding: 3px 0;">
                <input type="checkbox" value="${journal}" style="
                  margin-right: 5px;
                  width: 16px;
                  height: 16px;
                ">
                <span class="journal-option" style="font-size: 14px;">
                  ${journalInfo.journal}
                  ${buildJournalInfoTags(journal)}
                  <span class="journal-count" style="margin-left: 5px; color: #666; font-size: 14px;">(${journalCountMap[journal]})</span>
                </span>
              </label>
            `;
          }).join('')}
        </div>
      </div>
      <div style="width: 27%;">
        <div style="
          display: flex;
          flex-direction: column;
          margin-bottom: 8px;
          height: 14px; /* 标题高度与左侧保持一致 */
          line-height: 14px;
        ">
          <label style="
            font-size: 14px;
            font-weight: 500;
            color: #333;
          ">筛选选项：</label>
        </div>
        <div style="
          background: #f8f9fa;
          padding: 10px;
          border-radius: 8px;
          border: 1px solid #e0e0e0;
          box-sizing: border-box;
          height: 250px;
          overflow-y: auto;
        ">
          <div style="
            display: flex;
            align-items: center;
            margin-bottom: 12px;
            gap: 10px;
          ">
            <label for="sort-options" style="
              font-size: 14px;
              font-weight: 500;
              color: #333;
              white-space: nowrap;
            ">排序方式：</label>
            <select id="sort-options" style="
              flex: 1;
              padding: 6px 10px;
              border: 1px solid #e0e0e0;
              border-radius: 6px;
              background: white;
              font-size: 14px;
              color: #333;
              cursor: pointer;
              height: 32px;
              box-sizing: border-box;
            ">
              <option value="alphabet-asc">A-Z</option>
              <option value="alphabet-desc">Z-A</option>
              <option value="count-desc">数量降序</option>
              <option value="count-asc">数量升序</option>
              <option value="if-desc">IF降序</option>
              <option value="if-asc">IF升序</option>
            </select>
          </div>

${ifFilterBlock}

${jcrFilterBlock}

${casFilterBlock}

${customFilterBlocks}

${filterFooter}
        </div>
      </div>
    </div>
  `;

  // 移除旧的按钮容器，直接插入新的HTML
  resultsDiv.innerHTML = `
    ${filterSortHtml}
    <div style="
      margin: 3px 0;
      padding: 8px 0;
      display: flex;
      justify-content: flex-end;
      gap: 10px;
      align-items: center;
    ">
      <div style="
        display: flex;
        gap: 10px;
        width: 100%;
        justify-content: flex-end;
      ">
        <button id="get-abstracts" class="action-button" style="
          flex: 1;
          max-width: 130px;
          background-color: #d3baf8;
          color: black;
          border: none;
          padding: 5px 12px;
          border-radius: 6px;
          cursor: pointer;
          font-size: 14px;
          height: 30px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          transition: background-color 0.3s;
        ">获取论文摘要</button>
        <button id="cite-selected" class="action-button" style="
          flex: 1;
          max-width: 130px;
          background-color: #d3baf8;
          color: black;
          border: none;
          padding: 5px 12px;
          border-radius: 6px;
          cursor: pointer;
          font-size: 14px;
          height: 30px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          transition: background-color 0.3s;
        ">引用所选论文</button>
        <button id="open-selected" class="action-button" style="
          flex: 1;
          max-width: 130px;
          background-color: #d3baf8;
          color: black;
          border: none;
          padding: 5px 12px;
          border-radius: 6px;
          cursor: pointer;
          font-size: 14px;
          height: 30px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          transition: background-color 0.3s;
        ">打开所选论文</button>
      </div>
    </div>
    <div class="select-all-container" style="padding: 10px; background-color: #f8f9fa; border-radius: 4px; margin-bottom: 10px;">
      <label style="display: flex; align-items: center; cursor: pointer;">
        <input type="checkbox" id="select-all-papers" style="
          margin-right: 15px;
          width: 18px;
          height: 18px;
          cursor: pointer;
        ">
        <span style="font-weight: bold;">全选当前视图下的论文</span>
      </label>
    </div>
    <ul id="paper-list" style="list-style-type: none; padding: 0; margin: 0; width: 100%;">
      ${papers.map(paper => {
        const customDataAttributes = buildCustomDataAttributes(paper);
        return `
        <li class="paper-item" data-journal="${paper.processedJournal}"${customDataAttributes}>
          <div class="paper-content">
            <input type="checkbox" class="paper-checkbox" data-title="${encodeURIComponent(paper.title)}" style="
              margin-right: 15px;
              width: 18px;
              height: 18px;
              cursor: pointer;
            ">
            <div style="flex: 1; padding-right: 60px;">
              <div class="paper-header">
                <strong><a href="${paper.link}" target="_blank" style="text-decoration: none; color: inherit;" class="paper-title-link">${paper.title}</a></strong>
              </div>
              <small style="color: #777;">
                <strong>期刊<span class="journal-name">${paper.journal}</span>
                <span class="journal-info">${buildPaperInfoTags(paper)}</span></strong>
              </small>
              <br>
              <small style="color: #777;" class="index-content">${paper.indexHTML.replace(/<a[^>]*>(.*?)<\/a>/g, '$1')}</small>
              <br>
              <div class="snippet-content">${paper.snippetHTML}</div>
            </div>
            <button class="cite-button" data-title="${encodeURIComponent(paper.title)}">引用</button>
          </div>
        </li>
      `;
      }).join('')}
    </ul>
  `;

  // 添加全选功能的事件监听器
  const selectAllCheckbox = document.getElementById('select-all-papers');
  const paperCheckboxes = document.querySelectorAll('.paper-checkbox');

  // 为按钮添加悬停效果
  const addButtonHover = (buttonId) => {
    const button = document.getElementById(buttonId);
    if (button) {
      button.onmouseover = function() {
        this.style.backgroundColor = '#e1ceff';
      };
      button.onmouseout = function() {
        this.style.backgroundColor = '#d3baf8';
      };
    }
  };

  // 为所有按钮添加悬停效果
  addButtonHover('get-abstracts');
  addButtonHover('cite-selected');
  addButtonHover('open-selected');
  addButtonHover('close-window');

  // 为清除筛选按钮添加特殊悬停效果
  const clearFiltersBtn = document.getElementById('clear-filters');
  if (clearFiltersBtn) {
    clearFiltersBtn.onmouseover = function() {
      this.style.backgroundColor = '#cccccc';
    };
    clearFiltersBtn.onmouseout = function() {
      this.style.backgroundColor = '#e0e0e0';
    };
  }

  // 更新全选框状态的函数
  function updateSelectAllState() {
    const visiblePapers = Array.from(paperCheckboxes).filter(checkbox =>
      !checkbox.closest('.paper-item').style.display ||
      checkbox.closest('.paper-item').style.display !== 'none'
    );
    const checkedVisiblePapers = visiblePapers.filter(checkbox => checkbox.checked);

    if (visiblePapers.length === 0) {
      selectAllCheckbox.checked = false;
      selectAllCheckbox.indeterminate = false;
    } else if (checkedVisiblePapers.length === 0) {
      selectAllCheckbox.checked = false;
      selectAllCheckbox.indeterminate = false;
    } else if (checkedVisiblePapers.length === visiblePapers.length) {
      selectAllCheckbox.checked = true;
      selectAllCheckbox.indeterminate = false;
    } else {
      selectAllCheckbox.checked = false;
      selectAllCheckbox.indeterminate = true;
    }
  }

  // 全选框点击事件
  selectAllCheckbox.addEventListener('change', function() {
    const isChecked = this.checked;
    paperCheckboxes.forEach(checkbox => {
      const paperItem = checkbox.closest('.paper-item');
      if (!paperItem.style.display || paperItem.style.display !== 'none') {
        checkbox.checked = isChecked;
      }
    });
    updateSelectAllState();
  });

  // 单个复选框点击事件
  paperCheckboxes.forEach(checkbox => {
    checkbox.addEventListener('change', updateSelectAllState);
  });

  // 在筛选后更新全选状态
  const originalFilterJournals = window.filterJournals;
  window.filterJournals = function() {
    if (originalFilterJournals) {
      originalFilterJournals.apply(this, arguments);
    }
    setTimeout(updateSelectAllState, 0);
  };

  // 修改样式定义
  const additionalStyle = `
    .paper-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: px;
      position: relative;
    }
    .paper-title-link {
      transition: color 0.2s ease;
    }
    .paper-title-link:hover {
      color: #1a73e8 !important;
    }
    .info-tag {
      display: inline-block;
      padding: 2px 8px;
      border-radius: 12px;
      margin: 0 4px;
      font-size: 0.9em;
      white-space: nowrap;
    }
    .if-tag {
      background-color: #FFF3E0;
      color: #E65100;
    }
    .jcr-tag {
      background-color: #F3E5F5;
      color: #7B1FA2;
    }
    .cas-tag {
      background-color: #E8F5E9;
      color: #388E3C;
    }
    .custom-tag {
      background-color: #E3F2FD;
      color: #1565C0;
    }
    .custom-tag {
      background-color: #E3F2FD;
      color: #1565C0;
    }
    .cite-button {
      position: absolute;
      right: 15px;
      top: 50%;
      transform: translateY(-50%);
      background-color: #d3baf8;
      color: black;
      border: none;
      padding: 5px 12px;
      border-radius: 4px;
      cursor: pointer;
      transition: background-color 0.3s;
      white-space: nowrap;
      z-index: 1;
      height: 30px;
      min-width: 50px;
      font-size: 14px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }
    .cite-button:hover {
      background-color: #e1ceff;
    }
    .paper-content {
      padding: 15px;
      position: relative;
      display: flex;
      align-items: center;
    }
    .loading-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 10000;
    }
    .loading-content {
      background: white;
      padding: 20px;
      border-radius: 8px;
      text-align: center;
    }
    .loading-spinner {
      border: 4px solid #f3f3f3;
      border-top: 4px solid #d3baf8;
      border-radius: 50%;
      width: 40px;
      height: 40px;
      animation: spin 1s linear infinite;
      margin: 0 auto 10px;
    }
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
  `;

  const styleElement = document.createElement('style');
  styleElement.textContent = additionalStyle;
  document.head.appendChild(styleElement);

  // 添加用按钮事件监听
  document.querySelectorAll('.cite-button').forEach(button => {
    button.addEventListener('click', async function() {
      const title = decodeURIComponent(this.dataset.title);
      await handleCitation(title);
    });
  });

  // 修改样式
  const style = document.createElement('style');
  style.textContent = `
    @media (max-width: 768px) {
      #extracted-titles {
        width: 95%;
        max-width: none;
      }
      .filter-sort-container {
        flex-direction: column;
      }
      .filter-sort-container > div {
        width: 100% !important;
        margin-bottom: 10px;
      }
    }
    .snippet-content b,
    .snippet-content strong {
      font-weight: bold !important;
      background-color: transparent !important;
    }
    
    [data-theme="light"] .snippet-content b,
    [data-theme="light"] .snippet-content strong,
    :root .snippet-content b,
    :root .snippet-content strong {
      color: darkred !important;
    }
    
    [data-theme="dark"] .snippet-content b,
    [data-theme="dark"] .snippet-content strong {
      color: #ff69b4 !important;
    }
    .paper-item {
      margin-bottom: 10px;
      border: 1px solid #e0e0e0;
      border-radius: 8px;
      overflow: hidden;
    }
    .paper-content {
      padding: 10px;
    }
    .extra-info {
      font-size: 0.9em;
    }
    #journal-filter {
      width: 100%;
    }
    #sort-options, #clear-results {
      width: 100%;
    }
    #sort-options {
      font-size: 0.9em;
    }
    #journal-filter label {
      display: flex;
      align-items: center;
      margin-bottom: 2px;
      padding: 2px 5px;
      border-radius: 4px;
    }
    #journal-filter input[type="checkbox"] {
      margin-right: 8px;
      flex-shrink: 0;
    }
    .journal-option {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 4px;
      flex-grow: 1;
      padding-left: 4px;
    }
    .info-tag {
      display: inline-flex;
      align-items: center;
      padding: 2px 8px;
      border-radius: 12px;
      font-size: 0.9em;
      white-space: nowrap;
      margin: 0 2px;
    }
    .if-tag {
      background-color: #FFF3E0;
      color: #E65100;
    }
    .jcr-tag {
      background-color: #F3E5F5;
      color: #7B1FA2;
    }
    .cas-tag {
      background-color: #E8F5E9;
      color: #388E3C;
    }
    #journal-filter label:hover {
      background-color: #f5f5f5;
    }
  `;
  document.head.appendChild(style);

  // 修改排序功能
  const sortSelect = document.getElementById('sort-options');
  sortSelect.addEventListener('change', function() {
    const sortValue = this.value;
    let sortedJournals = [...uniqueJournals];

    if (sortValue === 'alphabet-asc') {
      sortedJournals.sort((a, b) => a.localeCompare(b));
    } else if (sortValue === 'alphabet-desc') {
      sortedJournals.sort((a, b) => b.localeCompare(a));
    } else if (sortValue === 'count-asc') {
      sortedJournals.sort((a, b) => journalCountMap[a] - journalCountMap[b]);
    } else if (sortValue === 'count-desc') {
      sortedJournals.sort((a, b) => journalCountMap[b] - journalCountMap[a]);
    } else if (sortValue === 'if-desc') {
      sortedJournals.sort((a, b) => {
        const ifA = parseFloat(jcrfqMap[a]?.IF_2023) || 0;
        const ifB = parseFloat(jcrfqMap[b]?.IF_2023) || 0;
        return ifB - ifA;
      });
    } else if (sortValue === 'if-asc') {
      sortedJournals.sort((a, b) => {
        const ifA = parseFloat(jcrfqMap[a]?.IF_2023) || 0;
        const ifB = parseFloat(jcrfqMap[b]?.IF_2023) || 0;
        return ifA - ifB;
      });
    }

    // 重新生成筛选选项
    const journalFilter = document.getElementById('journal-filter');
    journalFilter.innerHTML = `
      <label style="display: flex; align-items: center; padding: 3px 0;">
        <input type="checkbox" value="all" checked style="
          margin-right: 5px;
          width: 16px;
          height: 16px;
        ">
        <span class="journal-option" style="font-size: 14px;">全部</span>
      </label>
      ${sortedJournals.map(journal => {
        const journalInfo = papers.find(p => p.processedJournal === journal);
        return `
          <label title="${processedJournalNameMap[journal]}" style="display: flex; align-items: center; padding: 3px 0;">
            <input type="checkbox" value="${journal}" style="
              margin-right: 5px;
              width: 16px;
              height: 16px;
            ">
            <span class="journal-option" style="font-size: 14px;">
              ${journalInfo.journal}
              ${buildJournalInfoTags(journal)}
              <span class="journal-count" style="margin-left: 5px; color: #666; font-size: 14px;">(${journalCountMap[journal]})</span>
            </span>
          </label>
        `;
      }).join('')}
    `;

    // 重新添加事件监听器
    addFilterEventListener();
  });

  let isManualJournalSelection = false;

  // 添加筛选事件监听器的函数
  function addFilterEventListener() {
    const journalFilter = document.getElementById('journal-filter');
    journalFilter.addEventListener('change', function(event) {
      if (event.target.type !== 'checkbox') {
        return;
      }

      const checkboxes = journalFilter.querySelectorAll('input[type="checkbox"]');
      const allCheckbox = journalFilter.querySelector('input[value="all"]');
      const journalCheckboxes = Array.from(checkboxes).filter(cb => cb !== allCheckbox);

      if (event.target.value === 'all') {
        const shouldCheckAll = event.target.checked;
        allCheckbox.checked = shouldCheckAll;
        journalCheckboxes.forEach(cb => {
          cb.checked = shouldCheckAll;
        });
        isManualJournalSelection = !shouldCheckAll;
      } else {
        const checkedJournalCount = journalCheckboxes.filter(cb => cb.checked).length;
        const totalJournalCount = journalCheckboxes.length;

        if (checkedJournalCount === totalJournalCount && totalJournalCount > 0) {
          allCheckbox.checked = true;
          isManualJournalSelection = false;
        } else {
          allCheckbox.checked = false;
          isManualJournalSelection = true;
        }
      }

      filterJournals();
    });
  }

  // 初始化时添加事件监听器
  addFilterEventListener();

  // 应用默认排序方式
  chrome.storage.sync.get({
    defaultSortMethod: 'alphabet-asc'  // 默认排序方式
  }, function(items) {
    // 设置排序下拉框的值
    sortSelect.value = items.defaultSortMethod;
    
    // 手动触发一次变更事件，应用排序
    const changeEvent = new Event('change');
    sortSelect.dispatchEvent(changeEvent);
  });

  // 初始化背景色
  const paperItems = document.querySelectorAll('.paper-item');
  paperItems.forEach((item, index) => {
    item.querySelector('.paper-content').style.backgroundColor = index % 2 === 0 ? '#f9f9f9' : '#e6f7ff';
  });

  // 添加清除筛选按钮件监听器
  const clearFiltersButton = document.getElementById('clear-filters');
  clearFiltersButton.addEventListener('click', clearAllFilters);

  // 添加关闭窗口按钮的事监器
  const closeButton = document.getElementById('close-window');
  closeButton.addEventListener('click', closeResultsWindow);

  // 添加论文提取页面的主题切换功能
  function updateExtractionThemeIcons() {
    const currentTheme = localStorage.getItem('theme') || 'light';
    const moonIcon = document.querySelector('.moon-icon-extraction');
    const sunIcon = document.querySelector('.sun-icon-extraction');
    
    if (moonIcon && sunIcon) {
      if (currentTheme === 'dark') {
        moonIcon.style.display = 'none';
        sunIcon.style.display = 'block';
      } else {
        moonIcon.style.display = 'block';
        sunIcon.style.display = 'none';
      }
    }
  }

  function toggleExtractionTheme() {
    const currentTheme = localStorage.getItem('theme') || 'light';
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    localStorage.setItem('theme', newTheme);
    
    // 更新论文提取页面主题
    const extractedTitles = document.getElementById('extracted-titles');
    if (extractedTitles) {
      extractedTitles.setAttribute('data-theme', newTheme);
      applyThemeToElement(extractedTitles, newTheme);
    }
    
    updateExtractionThemeIcons();
  }

  // 初始化论文提取页面的主题图标
  updateExtractionThemeIcons();
  
  // 应用初始主题到论文提取页面
  const currentTheme = localStorage.getItem('theme') || 'light';
  const extractedTitles = document.getElementById('extracted-titles');
  if (extractedTitles) {
    applyThemeToElement(extractedTitles, currentTheme);
  }

  // 添加主题切换按钮事件监听器
  const themeToggleExtraction = document.getElementById('theme-toggle-extraction');
  if (themeToggleExtraction) {
    themeToggleExtraction.addEventListener('click', toggleExtractionTheme);
  }
  // 修改筛选功能
  function filterJournals() {
    const selectedJournals = Array.from(document.querySelectorAll('#journal-filter input[type="checkbox"]:checked'))
      .map(cb => cb.value);
    const selectedJournalSet = new Set(selectedJournals);
    const hasSpecificJournalSelection = Array.from(selectedJournalSet).some(value => value !== 'all');
    const hasEmptyManualJournalSelection = isManualJournalSelection && !hasSpecificJournalSelection && !selectedJournalSet.has('all');

    const selectedJCR = showJCR
      ? Array.from(document.querySelectorAll('input[name="jcr-filter"]:checked')).map(cb => cb.value)
      : [];
    const selectedCAS = showCAS
      ? Array.from(document.querySelectorAll('input[name="cas-filter"]:checked')).map(cb => cb.value)
      : [];
    const selectedCustomMap = new Map();
    if (hasCustomPartition) {
      enabledCustomPartitions.forEach((partition) => {
        const selector = `input[name="custom-filter-${partition.id}"]:checked`;
        const selectedValues = Array.from(document.querySelectorAll(selector)).map(cb => cb.value);
        selectedCustomMap.set(partition.id, selectedValues);
      });
    }
    const topFilterElement = document.getElementById('top-filter');
    const isTopSelected = showCAS && topFilterElement ? topFilterElement.checked : false;
    const ifMinElement = document.getElementById('if-min');
    const ifMin = showIF && ifMinElement ? parseFloat(ifMinElement.value) : NaN;

    const paperList = document.getElementById('paper-list');
    const paperItems = paperList.getElementsByTagName('li');

    let visibleIndex = 0;
    const matchedJournals = new Set();

    for (let item of paperItems) {
      if (!item.classList.contains('paper-item')) continue; // 跳过全选项

      const journal = item.getAttribute('data-journal');
      const journalInfo = jcrfqMap[journal] || {};
      const casInfo = zkyfqMap[journal] || {};
      const journalIF = parseFloat(journalInfo.IF_2023) || 0;

      const matchesJournalSelection = hasEmptyManualJournalSelection
        ? false
        : (!isManualJournalSelection || selectedJournalSet.has('all') || selectedJournalSet.has(journal));
      const isJCRMatch = !showJCR || selectedJCR.length === 0 || selectedJCR.includes(journalInfo.IF_Quartile);
      const isCASMatch = !showCAS || selectedCAS.length === 0 || selectedCAS.includes(casInfo.大类分区);
      const isCustomMatch = !hasCustomPartition || enabledCustomPartitions.every((partition) => {
        const selectedValues = selectedCustomMap.get(partition.id) || [];
        if (selectedValues.length === 0) {
          return true;
        }
        const attrName = `data-custom-partition-${partition.id}`;
        const customValue = item.getAttribute(attrName) || '';
        return selectedValues.includes(customValue);
      });
      const isTopMatch = !showCAS || !isTopSelected || casInfo.Top === '是';
      const isIFMatch = !showIF || isNaN(ifMin) || journalIF >= ifMin;

      if (matchesJournalSelection &&
          isJCRMatch && isCASMatch && isCustomMatch && isTopMatch && isIFMatch) {
        item.style.display = '';
        item.querySelector('.paper-content').style.backgroundColor = visibleIndex % 2 === 0 ? '#f9f9f9' : '#e6f7ff';
        visibleIndex++;
        matchedJournals.add(journal);
      } else {
        item.style.display = 'none';
      }
    }

    // 更新期刊选择器
    updateJournalFilter(matchedJournals, { preserveManualSelection: isManualJournalSelection });
    // 更新全选框状态
    updateSelectAllState();
  }

  function updateJournalFilter(matchedJournals, options = {}) {
    const { preserveManualSelection = false } = options;
    const journalFilter = document.getElementById('journal-filter');
    const checkboxes = journalFilter.querySelectorAll('input[type="checkbox"]');
    const allCheckbox = journalFilter.querySelector('input[value="all"]');
    const totalJournals = checkboxes.length - 1;

    checkboxes.forEach(cb => {
      if (cb !== allCheckbox) {
        cb.disabled = false; // 确保所有复选框都是可用的
        if (!preserveManualSelection) {
          cb.checked = matchedJournals.has(cb.value);
        }
      }
    });

    allCheckbox.disabled = false; // 确保"全部"选项是可用的

    if (preserveManualSelection) {
      const checkedJournalCount = Array.from(checkboxes).filter(cb => cb !== allCheckbox && cb.checked).length;
      allCheckbox.checked = checkedJournalCount === totalJournals && totalJournals > 0;
      allCheckbox.indeterminate = checkedJournalCount > 0 && checkedJournalCount < totalJournals;
      return;
    }

    const shouldCheckAll = matchedJournals.size === totalJournals && totalJournals > 0;
    allCheckbox.checked = shouldCheckAll;
    allCheckbox.indeterminate = matchedJournals.size > 0 && matchedJournals.size < totalJournals;
  }

  // 添加筛选事件监听器
  function addFilterEventListeners() {
    const jcrFilters = document.querySelectorAll('input[name="jcr-filter"]');
    const casFilters = document.querySelectorAll('input[name="cas-filter"]');
    const customFilters = document.querySelectorAll('input[data-custom-filter]');
    const topFilter = document.getElementById('top-filter');
    const ifMinInput = document.getElementById('if-min');

    const applyAutoFilter = () => {
      isManualJournalSelection = false;
      filterJournals();
    };

    Array.from(jcrFilters).forEach(filter => filter.addEventListener('change', applyAutoFilter));
    Array.from(casFilters).forEach(filter => filter.addEventListener('change', applyAutoFilter));
    Array.from(customFilters).forEach(filter => filter.addEventListener('change', applyAutoFilter));
    if (topFilter) {
      topFilter.addEventListener('change', applyAutoFilter);
    }
    if (ifMinInput) {
      ifMinInput.addEventListener('input', applyAutoFilter);
    }
  }

  // 在显示文信息后调用这个函数
  addFilterEventListeners();

  // 修改批引用按钮的事件监听器
  document.getElementById('cite-selected').addEventListener('click', async function() {
    // 只获取当前可见的选中论文
    const visibleSelectedCheckboxes = document.querySelectorAll('.paper-item:not([style*="display: none"]) .paper-checkbox:checked');
    if (visibleSelectedCheckboxes.length === 0) {
      showToast('请至少选择一篇论文', true);
      return;
    }

    const loadingOverlay = showLoadingOverlay(`正在获取 ${visibleSelectedCheckboxes.length} 篇论文的引用信息...`);
    try {
      const titles = Array.from(visibleSelectedCheckboxes).map(cb => decodeURIComponent(cb.dataset.title));

      const results = await downloadRisForTitles(titles);
      const successCount = results.filter(item => item.status === 'success').length;
      const failureCount = results.length - successCount;

      if (failureCount > 0) {
        showToast(`已导出引用文件，成功 ${successCount} 篇，失败 ${failureCount} 篇`, true);
      } else {
        showToast(`已导出 ${successCount} 篇论文的引用信息`);
      }

    } catch (error) {
      console.error('批量获取引用信息时出错:', error);
      alert(`批量获取引用信息失败: ${error.message}`);
    } finally {
      loadingOverlay.remove();
    }
  });

  // 新增批量获取摘要按钮的事件监听器
  document.getElementById('get-abstracts').addEventListener('click', async function() {
    // 只获取当前可见的选中论文
    const visibleSelectedCheckboxes = document.querySelectorAll('.paper-item:not([style*="display: none"]) .paper-checkbox:checked');
    if (visibleSelectedCheckboxes.length === 0) {
      showToast('请至少选择一篇论文', true);
      return;
    }

    const loadingOverlay = showLoadingOverlay(`正在获取 ${visibleSelectedCheckboxes.length} 篇论文的摘要...`);
    try {
      const titles = Array.from(visibleSelectedCheckboxes).map(cb => decodeURIComponent(cb.dataset.title));
      const abstractResults = await getBatchAbstracts(titles);
      displayAbstracts(abstractResults);
    } catch (error) {
      console.error('批量获取摘要时出错:', error);
      alert(`批量获取摘要失败: ${error.message}`);
    } finally {
      loadingOverlay.remove();
    }
  });

  // 新增打开所选论文按钮的事件监听器
  document.getElementById('open-selected').addEventListener('click', function() {
    // 只获取当前可见的选中论文
    const visibleSelectedCheckboxes = document.querySelectorAll('.paper-item:not([style*="display: none"]) .paper-checkbox:checked');
    if (visibleSelectedCheckboxes.length === 0) {
      showToast('请至少选择一篇论文', true);
      return;
    }

    // 获取所选论文的链接
    const paperLinks = [];
    visibleSelectedCheckboxes.forEach(checkbox => {
      const paperItem = checkbox.closest('.paper-item');
      const linkElement = paperItem.querySelector('.paper-title-link');
      if (linkElement && linkElement.href) {
        paperLinks.push(linkElement.href);
      }
    });

    if (paperLinks.length === 0) {
      showToast('所选论文没有可用的链接', true);
      return;
    }

    // 使用模拟Cmd+点击的方式在后台打开新标签页
    paperLinks.forEach((link, index) => {
      setTimeout(() => {
        // 创建一个临时的链接元素
        const tempLink = document.createElement('a');
        tempLink.href = link;
        tempLink.target = '_blank';
        tempLink.rel = 'noopener noreferrer';
        
        // 模拟Cmd+点击事件（在Mac上）或Ctrl+点击事件（在PC上）
        const clickEvent = new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: window,
          ctrlKey: navigator.platform.indexOf('Mac') === -1, // PC上使用Ctrl
          metaKey: navigator.platform.indexOf('Mac') !== -1, // Mac上使用Cmd
        });
        
        // 将链接添加到DOM中，触发点击事件，然后移除
        document.body.appendChild(tempLink);
        tempLink.dispatchEvent(clickEvent);
        document.body.removeChild(tempLink);
      }, index * 1000); // 每个链接间隔500毫秒，避免浏览器阻止批量打开
    });

    showToast(`已在新标签页中打开 ${paperLinks.length} 篇论文`);
  });

  // 新增获取批量摘要的函数
  async function getBatchAbstracts(titles) {
    const batchSize = 3; // 修改为3篇文章一批，确保即使少量论文也会进行批处理
    const retryAttempts = 5; // 增加最大重试次数
    const retryDelay = 1500; // 增加重试延迟
    const batchDelay = 2500; // 增加批次间延迟

    // 更新加载提示
    const loadingDiv = document.querySelector('.loading-content');
    const updateProgress = (current, total, status) => {
      if (loadingDiv) {
        loadingDiv.innerHTML = `
          <div class="loading-spinner"></div>
          <div>正在获取论文摘要 (${current}/${total})</div>
          <div style="font-size: 0.9em; color: #666;">${status}</div>
        `;
      }
    };

    // 添加延迟函数
    const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

    // 添加增强版重试机制的请求函数
    async function retryFetch(url, attempts = retryAttempts) {
      for (let i = 0; i < attempts; i++) {
        try {
          // 添加随机延迟，避免同时发送过多请求
          const randomDelay = Math.floor(Math.random() * 500) + 200;
          await delay(randomDelay);

          console.log(`尝试第 ${i+1}/${attempts} 次请求: ${url}`);
          const response = await fetch(url);

          if (!response.ok) {
            console.warn(`请求失败，状态码: ${response.status}`);
            throw new Error(`HTTP error! status: ${response.status}`);
          }

          // 成功获取响应
          console.log(`请求成功: ${url}`);
          return response;
        } catch (error) {
          console.error(`请求失败 (尝试 ${i+1}/${attempts}): ${error.message}`);
          if (i === attempts - 1) throw error;

          // 使用指数退避策略，每次重试等待时间增加
          const exponentialDelay = retryDelay * Math.pow(1.5, i);
          console.log(`等待 ${exponentialDelay}ms 后重试...`);
          await delay(exponentialDelay);
        }
      }
    }

    // 修改获取PMID的函数，添加重试机制
    async function getPMIDWithRetry(doi) {
      try {
        const searchUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=${encodeURIComponent(doi)}&format=json`;
        const response = await retryFetch(searchUrl);
        const data = await response.json();
        return data.esearchresult?.idlist?.[0] || null;
      } catch (error) {
        console.error('通过DOI获取PMID时出错:', error);
        return null;
      }
    }

    // 修改获取摘要的函数，添加重试机制，同时获取期刊信息、发表年份和作者信息
    async function getAbstractWithRetry(pmid) {
      try {
        const fetchUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=${pmid}&retmode=xml`;
        const response = await retryFetch(fetchUrl);
        const text = await response.text();
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(text, "text/xml");

        // 创建结果对象
        const result = {
          abstract: null,
          journal: null,
          year: null,
          authors: null
        };

        // 获取所有摘要部分
        const abstractSections = xmlDoc.querySelectorAll("Abstract AbstractText");
        if (abstractSections.length > 0) {
          let abstractParts = [];

          // 处理结构化摘要
          if (abstractSections.length > 1 || abstractSections[0].getAttribute('Label')) {
            abstractSections.forEach(section => {
              const label = section.getAttribute('Label');
              const content = section.textContent.trim();
              if (label) {
                abstractParts.push(`${label}\n${content}`);
              } else {
                abstractParts.push(content);
              }
            });

            // 如果有 "Abstract" 标签，添加到开头
            if (!abstractParts[0].startsWith('Abstract')) {
              abstractParts.unshift('Abstract');
            }

            result.abstract = abstractParts.join('\n\n');
          }
          // 处理非结构化摘要
          else {
            result.abstract = abstractSections[0].textContent.trim();
          }
        }

        // 获取期刊信息
        const journalElement = xmlDoc.querySelector("Journal Title");
        if (journalElement) {
          result.journal = journalElement.textContent.trim().toUpperCase();
        }

        // 获取发表年份
        const yearElement = xmlDoc.querySelector("PubDate Year");
        if (yearElement) {
          result.year = yearElement.textContent.trim();
        }

        // 获取作者信息
        const authorElements = xmlDoc.querySelectorAll("AuthorList Author");
        if (authorElements.length > 0) {
          const authors = [];
          authorElements.forEach(author => {
            const lastName = author.querySelector("LastName")?.textContent.trim() || '';
            const foreName = author.querySelector("ForeName")?.textContent.trim() || '';
            if (lastName || foreName) {
              authors.push(`${lastName}${lastName && foreName ? ', ' : ''}${foreName}`);
            }
          });
          result.authors = authors.join('; ');
        }

        return result;
      } catch (error) {
        console.error('获取摘要和文章信息时出错:', error);
        return null;
      }
    }

    const results = [];
    // 将文章分批处理
    for (let i = 0; i < titles.length; i += batchSize) {
      const batch = titles.slice(i, i + batchSize);
      updateProgress(i, titles.length, '正在获取文章信息...');

      // 在处理批次前添加延迟，即使是第一批
      if (i === 0) {
        console.log('在开始处理前添加初始化延迟...');
        await delay(1000);
      }

      const batchResults = await Promise.all(batch.map(async (title, titleIndex) => {
        // 每个标题处理前添加小延迟，避免同时请求
        await delay(titleIndex * 300);
        try {
          console.log(`开始处理论文: ${title.substring(0, 50)}...`);
          updateProgress(i + titleIndex, titles.length, `正在处理: ${title.substring(0, 50)}...`);

          // 先获取DOI和PMID
          const [crossrefResult, pubmedResult] = await Promise.allSettled([
            getCrossrefData(title),
            getPubMedData(title)
          ]);

          let doi = null;
          let pmid = null;
          let abstract = null;
          let journal = null;
          let year = null;
          let authors = null;

          // 从Crossref获取DOI和基本信息
          if (crossrefResult.status === 'fulfilled' && crossrefResult.value) {
            console.log(`Crossref 返回数据: ${title.substring(0, 30)}...`);
            doi = crossrefResult.value.DOI;
            // 先保存Crossref的其他数据，作为备用
            journal = crossrefResult.value.Journal?.toUpperCase();
            year = crossrefResult.value.Year;
            authors = crossrefResult.value.Authors;
          } else {
            console.log(`Crossref 未返回数据: ${title.substring(0, 30)}...`);
          }

          // 从PubMed获取PMID和摘要
          if (pubmedResult.status === 'fulfilled' && pubmedResult.value) {
            console.log(`PubMed 返回数据: ${title.substring(0, 30)}...`);
            pmid = pubmedResult.value.PMID;
            // 如果PubMed直接返回了摘要，先保存
            if (pubmedResult.value.Abstract) {
              abstract = pubmedResult.value.Abstract;
              journal = pubmedResult.value.Journal || journal;
              year = pubmedResult.value.Year || year;
              authors = pubmedResult.value.Authors || authors;
            }
          } else {
            console.log(`PubMed 未返回数据: ${title.substring(0, 30)}...`);
          }

          // 如果有DOI但没有PMID，尝试通过DOI获取PMID
          if (doi && !pmid) {
            console.log(`尝试通过DOI获取PMID: ${doi}`);
            pmid = await getPMIDWithRetry(doi);
            if (pmid) {
              console.log(`成功通过DOI获取PMID: ${pmid}`);
            }
          }

          // 如果有PMID但没有摘要，使用PubMed API获取详细信息
          if (pmid && !abstract) {
            console.log(`尝试通过PMID获取详细信息: ${pmid}`);
            const articleInfo = await getAbstractWithRetry(pmid);
            if (articleInfo) {
              console.log(`成功获取PMID详细信息: ${pmid}`);
              abstract = articleInfo.abstract;
              // 仅当之前没有获取到时才替换
              journal = journal || articleInfo.journal;
              year = year || articleInfo.year;
              authors = authors || articleInfo.authors;
            }
          }

          return {
            title,
            doi,
            pmid,
            abstract,
            journal,
            year,
            authors,
            status: abstract ? 'success' : 'no_abstract'
          };
        } catch (error) {
          console.error(`获取文章摘要时出错 (${title}):`, error);
          return {
            title,
            error: error.message,
            status: 'error'
          };
        }
      }));

      results.push(...batchResults);

      // 在处理下一批之前等待，无论是否还有下一批
      // 这确保即使只有一批，也会有足够的延迟来完成所有API调用
      const currentProgress = Math.min(i + batchSize, titles.length);
      updateProgress(currentProgress, titles.length, '处理完成当前批次，等待系统响应...');
      console.log(`批次 ${i/batchSize + 1} 处理完成，等待 ${batchDelay}ms...`);
      await delay(batchDelay);

      // 如果还有下一批，显示相应提示
      if (i + batchSize < titles.length) {
        updateProgress(i + batchSize, titles.length, '准备处理下一批...');
      }
    }

    // 统计处理结果
    const successful = results.filter(r => r.status === 'success').length;
    const failed = results.filter(r => r.status === 'error').length;
    const noAbstract = results.filter(r => r.status === 'no_abstract').length;

    updateProgress(titles.length, titles.length,
      `处理完成！成功: ${successful}, 未找到摘要: ${noAbstract}, 失败: ${failed}`
    );

    return results;
  }

  // 修改显示摘要的函数，添加统计信息
  function displayAbstracts(abstractResults) {
    const successful = abstractResults.filter(r => r.status === 'success').length;
    const failed = abstractResults.filter(r => r.status === 'error').length;
    const noAbstract = abstractResults.filter(r => r.status === 'no_abstract').length;

    const abstractsWindow = document.createElement('div');
    abstractsWindow.className = 'abstracts-window';
    abstractsWindow.setAttribute('data-theme', localStorage.getItem('theme') || 'light');
    abstractsWindow.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 80%;
      max-width: 1000px;
      height: 80vh;
      background: white;
      color: black;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
      z-index: 1001;
      overflow-y: auto;
      transition: background-color 0.3s, color 0.3s;
    `;

    const overlay = document.createElement('div');
    overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0,0,0,0.5);
      z-index: 1000;
    `;

    const content = `
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <div>
          <h2 style="margin: 0; color: black;">论文摘要</h2>
          <div style="margin-top: 5px; font-size: 0.9em; color: #666;">
            总计: ${abstractResults.length} |
            成功: ${successful} |
            未找到摘要: ${noAbstract} |
            失败: ${failed}
          </div>
        </div>
        <button id="close-abstracts" style="
          width: 30px;
          height: 30px;
          border: none;
          border-radius: 4px;
          background: #d3baf8;
          color: black;
          cursor: pointer;
          transition: background-color 0.3s;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
        ">×</button>
      </div>
      <div style="margin-bottom: 20px; display: flex; flex-wrap: wrap; gap: 10px;">
        <div>
          <button id="copy-all-abstracts" style="
            padding: 5px 12px;
            border: none;
            border-radius: 4px;
            background: #d3baf8;
            color: black;
            cursor: pointer;
            transition: background-color 0.3s;
            height: 30px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
          ">复制所有摘要</button>
        </div>
        <div>
          <button id="retry-failed" style="
            padding: 5px 12px;
            border: none;
            border-radius: 4px;
            background: ${failed > 0 ? '#d3baf8' : '#cccccc'};
            color: black;
            cursor: ${failed > 0 ? 'pointer' : 'not-allowed'};
            transition: background-color 0.3s;
            height: 30px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
          ">重试失败项 (${failed})</button>
        </div>
        <div style="margin-left: auto; display: flex; gap: 10px;">
          <button id="export-txt" style="
            padding: 5px 12px;
            border: none;
            border-radius: 4px;
            background: #d3baf8;
            color: black;
            cursor: pointer;
            transition: background-color 0.3s;
            height: 30px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
          ">导出为TXT</button>
          <button id="export-json" style="
            padding: 5px 12px;
            border: none;
            border-radius: 4px;
            background: #d3baf8;
            color: black;
            cursor: pointer;
            transition: background-color 0.3s;
            height: 30px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
          ">导出为JSON</button>
          <button id="export-csv" style="
            padding: 5px 12px;
            border: none;
            border-radius: 4px;
            background: #d3baf8;
            color: black;
            cursor: pointer;
            transition: background-color 0.3s;
            height: 30px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
          ">导出为CSV</button>
        </div>
      </div>
      <div>
        ${abstractResults.map((result, index) => `
          <div style="margin-bottom: 20px; padding: 15px; border: 1px solid #eee; border-radius: 8px;">
            <h3 style="margin-top: 0;">${index + 1}. ${result.title}</h3>
            ${result.error ?
              `<p style="color: red;">获取摘要失败: ${result.error}</p>` :
              `<div>
                ${result.journal ? `<p><strong>期刊:</strong> ${result.journal}</p>` : ''}
                ${result.year ? `<p><strong>发表年份:</strong> ${result.year}</p>` : ''}
                ${result.authors ? `<p><strong>作者:</strong> ${result.authors}</p>` : ''}
                ${result.doi ? `<p><strong>DOI:</strong> ${result.doi}</p>` : ''}
                ${result.pmid ? `<p><strong>PMID:</strong> ${result.pmid}</p>` : ''}
                <p><strong>摘要:</strong></p>
                <p>${result.abstract || '未找到摘要'}</p>
              </div>`
            }
          </div>
        `).join('')}
      </div>
    `;

    abstractsWindow.innerHTML = content;
    document.body.appendChild(overlay);
    document.body.appendChild(abstractsWindow);
    
    // 应用主题到摘要窗口
    const currentTheme = localStorage.getItem('theme') || 'light';
    applyThemeToElement(abstractsWindow, currentTheme);

    // 添加按钮悬停效果
    const addHoverEffect = (buttonId) => {
      const btn = document.getElementById(buttonId);
      if (btn) {
        btn.onmouseover = function() {
          this.style.backgroundColor = '#e1ceff';
        };
        btn.onmouseout = function() {
          this.style.backgroundColor = '#d3baf8';
        };
      }
    };

    // 为所有按钮添加悬停效果
    addHoverEffect('close-abstracts');
    addHoverEffect('copy-all-abstracts');
    addHoverEffect('export-txt');
    addHoverEffect('export-json');
    addHoverEffect('export-csv');

    // 为重试按钮添加悬停效果（仅当可用时）
    if (failed > 0) {
      addHoverEffect('retry-failed');
    }

    // 关闭按钮事件
    document.getElementById('close-abstracts').onclick = function() {
      overlay.remove();
      abstractsWindow.remove();
    };

    // 复制所有摘要按钮事件
    document.getElementById('copy-all-abstracts').onclick = function() {
      const abstractsText = abstractResults.map((result, index) => {
        return `${index + 1}. ${result.title}\n` +
               `${result.journal ? `期刊: ${result.journal}\n` : ''}` +
               `${result.year ? `发表年份: ${result.year}\n` : ''}` +
               `${result.authors ? `作者: ${result.authors}\n` : ''}` +
               `${result.doi ? `DOI: ${result.doi}\n` : ''}` +
               `${result.pmid ? `PMID: ${result.pmid}\n` : ''}` +
               `摘要:\n${result.abstract || '未找到摘要'}\n\n`;
      }).join('---\n\n');

      navigator.clipboard.writeText(abstractsText).then(() => {
        alert('所有摘要已复制到剪贴板');
      }).catch(err => {
        console.error('复制失败:', err);
        alert('复制失败，请手动复制');
      });
    };

    // 导出为TXT按钮事件
    document.getElementById('export-txt').onclick = function() {
      const abstractsText = abstractResults.map((result, index) => {
        return `${index + 1}. ${result.title}\n` +
               `${result.journal ? `期刊: ${result.journal}\n` : ''}` +
               `${result.year ? `发表年份: ${result.year}\n` : ''}` +
               `${result.authors ? `作者: ${result.authors}\n` : ''}` +
               `${result.doi ? `DOI: ${result.doi}\n` : ''}` +
               `${result.pmid ? `PMID: ${result.pmid}\n` : ''}` +
               `摘要:\n${result.abstract || '未找到摘要'}\n\n`;
      }).join('---\n\n');

      // 创建TXT文件并下载
      downloadFile(abstractsText, 'paper_abstracts.txt', 'text/plain');
    };

    // 导出为JSON按钮事件
    document.getElementById('export-json').onclick = function() {
      const jsonData = abstractResults.map(result => {
        // 创建干净的JSON对象，去除错误信息和状态信息
        return {
          title: result.title,
          journal: result.journal || null,
          year: result.year || null,
          authors: result.authors || null,
          doi: result.doi || null,
          pmid: result.pmid || null,
          abstract: result.abstract || null
        };
      });

      // 创建JSON文件并下载
      const jsonString = JSON.stringify(jsonData, null, 2); // 美化格式化
      downloadFile(jsonString, 'paper_abstracts.json', 'application/json');
    };

    // 导出为CSV按钮事件
    document.getElementById('export-csv').onclick = function() {
      // CSV头
      let csvContent = '\uFEFF"Title","Journal","Year","Authors","DOI","PMID","Abstract"\n';

      // 添加每一行数据
      abstractResults.forEach(result => {
        // 处理CSV字段，确保引号和逗号正确处理
        const escapeCsvField = (field) => {
          if (field === null || field === undefined) return '';
          // 将字段中的双引号替换为两个双引号，并用双引号包裹整个字段
          return `"${String(field).replace(/"/g, '""')}"`;
        };

        const row = [
          escapeCsvField(result.title),
          escapeCsvField(result.journal),
          escapeCsvField(result.year),
          escapeCsvField(result.authors),
          escapeCsvField(result.doi),
          escapeCsvField(result.pmid),
          escapeCsvField(result.abstract)
        ].join(',');

        csvContent += row + '\n';
      });

      // 创建CSV文件并下载
      downloadFile(csvContent, 'paper_abstracts.csv', 'text/csv;charset=utf-8');
    };

    // 通用的文件下载函数
    function downloadFile(content, fileName, mimeType) {
      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      // 显示下载成功的横幅提示
      showToast(`文件 ${fileName} 已成功下载！`);
    }

    // 重试失败项按钮事件
    if (failed > 0) {
      document.getElementById('retry-failed').onclick = async function() {
        const failedItems = abstractResults.filter(r => r.status === 'error');
        const failedTitles = failedItems.map(item => item.title);

        // 移除当前窗口
        overlay.remove();
        abstractsWindow.remove();

        // 重新获取失败项的摘要
        const loadingOverlay = showLoadingOverlay(`正在重试获取 ${failedTitles.length} 篇失败的论文摘要...`);
        try {
          const newResults = await getBatchAbstracts(failedTitles);

          // 更新原结果中的失败项
          newResults.forEach(newResult => {
            const index = abstractResults.findIndex(r => r.title === newResult.title);
            if (index !== -1) {
              abstractResults[index] = newResult;
            }
          });

          // 重新显示结果
          displayAbstracts(abstractResults);
        } catch (error) {
          console.error('重试获取摘要时出错:', error);
          alert(`重试失败: ${error.message}`);
        } finally {
          loadingOverlay.remove();
        }
      };
    }

    // 点击遮罩层关闭窗口
    overlay.onclick = function() {
      overlay.remove();
      abstractsWindow.remove();
    };
  }

}


// 关闭结果窗口函数
function closeResultsWindow() {
  const resultsDiv = document.getElementById('extracted-titles');
  if (resultsDiv) {
    resultsDiv.remove();
  }
  console.log('结果窗口已关闭');
}

// 开始提取
function startExtraction() {
  if (isExtracting) return;
  isExtracting = true;

  // 添加进度条并初始化
  addProgressBar();
  updateProgressBar(1, maxPages, 0);

  chrome.storage.local.set({currentPage: 1, allPapers: [], isExtracting: true}, () => {
    extractAndNavigate();
  });
}

// 提取并导航到下一页
function extractAndNavigate() {
  chrome.storage.local.get(['currentPage', 'allPapers'], async (data) => {
    let { currentPage, allPapers } = data;

    console.log(`开提取第 ${currentPage} 页`);

    const newPapers = extractTitlesAndJournals();

    // 如果当前页面没有提取到任何论文，停止提取
    if (newPapers.length === 0) {
      console.log('当前页面未提取到任何论文，停止提取。');
      finalizeExtraction(allPapers);
      return;
    }

    // 检查是否有新论文
    const existingElids = new Set(allPapers.map(paper => paper.elid));
    const uniqueNewPapers = newPapers.filter(paper => !existingElids.has(paper.elid));

    if (uniqueNewPapers.length === 0) {
      console.log('当前页面没有新论文，停止提取。');
      finalizeExtraction(allPapers);
      return;
    }

    // 合并新论文
    allPapers = allPapers.concat(uniqueNewPapers);
    console.log(`提取到 ${uniqueNewPapers.length} 篇新论文，总计 ${allPapers.length} 篇论文。`);

    // 更新进度条
    updateProgressBar(currentPage, maxPages, allPapers.length);

    chrome.storage.local.set({ currentPage, allPapers, isExtracting: true }, () => {
      displayTitlesWithJournals(allPapers);

      if (currentPage < maxPages && nextPage()) {
        currentPage++;
        chrome.storage.local.set({ currentPage }, () => {
          console.log(`提取第 ${currentPage - 1} 页完成，准备提取第 ${currentPage} 页。`);
          setTimeout(extractAndNavigate, 1000);
        });
      } else {
        console.log(`达到最大页数限制 (${maxPages} 页) 或没有更多页面可提。`);
        finalizeExtraction(allPapers);
      }
    });
  });
}

// 完成提取
function finalizeExtraction(allPapers) {
  console.log('开始处理提取到论文信息。');
  // 更新进度条显示为处理中
  const progressText = document.getElementById('progress-text');
  if (progressText) {
    progressText.textContent = '正在处理...';
  }

  fetchJournalInfo(allPapers).then(processedPapers => {
    displayTitlesWithJournals(processedPapers);
    isExtracting = false;
    chrome.storage.local.set({ isExtracting: false }, () => {
      console.log('提取完成，设置 isExtracting 为 false');
      // 隐藏进度条
      setTimeout(hideProgressBar, 2000);
    });
  });
}

// 定位并点击"下一页"或"Next"按钮
function nextPage() {
  // 使用包含"下一页"或"Next"文本的链接进行定位
  const nextButton = Array.from(document.querySelectorAll('a')).find(a =>
    a.textContent.trim() === '下一页' ||
    a.textContent.trim().toLowerCase() === 'next'
  );

  if (nextButton && !nextButton.classList.contains('gs_btn_disabled')) {
    console.log('找到"下一页"或"Next"按钮，准备点击。');
    nextButton.click();
    return true;
  } else {
    console.log('未找到"下一页"或"Next"按钮，或按钮已禁用。');
    return false;
  }
}

// 添加提取按钮
function addExtractButton() {
  let button = document.getElementById('extract-button');
  if (!button) {
    button = document.createElement('div');
    button.id = 'extract-button';
    button.style.cssText = `
      background-color: #d3baf8; // 浅紫色
      color: white;
      font-weight: bold;
      border: none;
      padding: 5px 15px;
      border-radius: 4px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 40px;
      position: fixed;
      left: 20px;
      bottom: 33%;
      z-index: 1000;
      box-shadow: 0 2px 5px rgba(0,0,0,0.2);
      transition: opacity 0.3s; // 改为透明度过渡效果
    `;

    // 修改鼠标悬停效果
    button.onmouseover = function() {
      this.style.opacity = '0.8'; // 鼠标悬停时稍微变淡
    };
    button.onmouseout = function() {
      this.style.opacity = '1'; // 鼠标移开时恢复原样
    };

    // 创建图标元素
    const icon = new Image();
    icon.src = chrome.runtime.getURL('icon/icon128.png');
    icon.style.cssText = `
      width: 24px;
      height: 24px;
      margin-right: 8px;
    `;

    // 添加加载错误处理
    icon.onerror = function() {
      console.error('图标加载失败:', this.src);
      this.style.display = 'none';
    };

    // 创建文字元素
    const text = document.createElement('span');
    text.textContent = '提取论文信息';

    // 将图标和文字添加到按钮中
    button.appendChild(icon);
    button.appendChild(text);

    button.addEventListener('click', startExtraction);

    // 将按钮插入到搜索框的左侧靠下位置
    const searchForm = document.querySelector('form[role="search"]');
    if (searchForm) {
      searchForm.style.position = 'relative';
      searchForm.appendChild(button);
    } else {
      // 如果找不到搜索表单，则默认添加到面左下方
      document.body.appendChild(button);
    }
  }
}


// 显示匹配状态
function showMatchingStatus(status, isMatching) {
  let statusDiv = document.getElementById('matching-status');
  if (!statusDiv) {
    const resultsDiv = document.getElementById('extracted-titles');
    if (resultsDiv) {
      statusDiv = document.createElement('div');
      statusDiv.id = 'matching-status';
      statusDiv.style.cssText = 'margin-top: 10px; font-weight: bold;';
      resultsDiv.appendChild(statusDiv);
    }
  }
  statusDiv.textContent = status;
  if (isMatching) {
    statusDiv.style.color = 'blue';
    statusDiv.style.fontWeight = 'bold';
  } else {
    statusDiv.style.color = 'black';
    statusDiv.style.fontWeight = 'bold';
  }
}

// 添加设置按钮
function addSettingsButton() {
  let button = document.createElement('div');
  button.id = 'settings-button';
  button.style.cssText = `
    background-color: #d3baf8;
    color: black;
    font-weight: bold;
    border: none;
    padding: 5px 15px;
    border-radius: 4px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 40px;
    position: fixed;
    left: 20px;
    bottom: 25%;
    z-index: 1000;
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    transition: opacity 0.3s;
  `;

  button.onmouseover = function() {
    this.style.opacity = '0.8';
  };
  button.onmouseout = function() {
    this.style.opacity = '1';
  };

  const icon = document.createElement('span');
  icon.textContent = '⚙️';
  icon.style.marginRight = '8px';

  const text = document.createElement('span');
  text.textContent = '设置';

  button.appendChild(icon);
  button.appendChild(text);

  button.addEventListener('click', showSettingsDialog);
  document.body.appendChild(button);
}

// 创建设置对话框
function showSettingsDialog() {
  // 检查是否已存在设置对话框
  if (document.getElementById('settings-dialog')) {
    return;
  }

  const dialog = document.createElement('div');
  dialog.id = 'settings-dialog';
  dialog.setAttribute('data-theme', localStorage.getItem('theme') || 'light');
  dialog.style.cssText = `
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    color: black;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    z-index: 1001;
    min-width: 300px;
    transition: background-color 0.3s, color 0.3s;
  `;

  const overlay = document.createElement('div');
  overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.5);
    z-index: 1000;
  `;

  // 获取当前设置
  chrome.storage.sync.get({
    maxPages: 10, // 默认值
    defaultSortMethod: 'alphabet-asc', // 默认排序方式
    displayPartitions: DEFAULT_DISPLAY_PARTITIONS
  }, function(items) {
    const partitions = {
      ...DEFAULT_DISPLAY_PARTITIONS,
      ...(items.displayPartitions || {})
    };

    if (getAllCustomPartitions().length === 0) {
      partitions.showCustom = false;
    }

    const getCustomPartitionStatusText = () => {
      const allPartitions = getAllCustomPartitions();
      if (allPartitions.length === 0) {
        return '当前未上传自定义分区。请准备包含“分区”和“期刊”两列的.xlsx文件。';
      }
      const partitionSummaries = allPartitions.map(partition => {
        const journalCount = Object.keys(partition.map).length;
        const valueText = partition.values.join('、') || '无';
        return `${partition.name}（期刊 ${journalCount} 个，分区选项：${valueText}）`;
      });
      const enabledNames = getEnabledCustomPartitions().map(partition => partition.name);
      return `已上传 ${allPartitions.length} 个分区：${partitionSummaries.join('；')}。已启用：${enabledNames.join('、') || '无'}`;
    };

    let customPartitionStatusText = getCustomPartitionStatusText();

    function getPartitionSummaryText(state) {
      const selected = [];
      if (state.showIF) selected.push('影响因子');
      if (state.showJCR) selected.push('JCR分区');
      if (state.showCAS) selected.push('新锐分区');
      if (state.showCustom) {
        const enabledNames = getEnabledCustomPartitions().map(partition => partition.name);
        selected.push(enabledNames.length > 0 ? `自定义分区（${enabledNames.join('、')}）` : '自定义分区');
      }
      if (selected.length === 0) {
        return '当前未启用任何分区信息';
      }
      return `已启用：${selected.join('、')}`;
    }
    dialog.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2 style="margin: 0; color: #333;">设置</h2>
        <button id="theme-toggle-settings" style="
          background: none;
          border: none;
          cursor: pointer;
          padding: 8px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: background-color 0.3s;
        " title="切换主题">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" style="width: 20px; height: 20px; fill: #333;" class="moon-icon-settings">
            <path d="M12 3c.132 0 .263 0 .393 0a7.5 7.5 0 0 0 7.92 12.446a9 9 0 1 1 -8.313 -12.454z"/>
          </svg>
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" style="width: 20px; height: 20px; fill: #333; display: none;" class="sun-icon-settings">
            <path d="M12 18a6 6 0 1 1 0-12 6 6 0 0 1 0 12zm0-2a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM11 1h2v3h-2V1zm0 19h2v3h-2v-3zM3.515 4.929l1.414-1.414L7.05 5.636 5.636 7.05 3.515 4.93zM16.95 18.364l1.414-1.414 2.121 2.121-1.414 1.414-2.121-2.121zm2.121-14.85l1.414 1.415-2.121 2.121-1.414-1.414 2.121-2.121zM5.636 16.95l1.414 1.414-2.121 2.121-1.414-1.414 2.121-2.121zM23 11v2h-3v-2h3zM4 11v2H1v-2h3z"/>
          </svg>
        </button>
      </div>
      <div style="margin: 20px 0;">
        <label style="display: block; margin-bottom: 5px; color: #333;">
          提取论文页数:
          <input type="number" id="max-pages-input" value="${items.maxPages}"
                 min="1" max="50" style="width: 60px; margin-left: 10px; background: white; color: #333; border: 1px solid #ccc; border-radius: 4px; padding: 4px;">
        </label>
        <small style="color: #666;">建议值: 1-50 页</small>
      </div>
      <div style="margin: 20px 0;">
        <label style="display: block; margin-bottom: 5px; color: #333;">
          默认排序方式:
          <select id="default-sort-method" style="margin-left: 10px; padding: 3px; width: 150px; background: white; color: #333; border: 1px solid #ccc; border-radius: 4px;">
            <option value="alphabet-asc" ${items.defaultSortMethod === 'alphabet-asc' ? 'selected' : ''}>A-Z</option>
            <option value="alphabet-desc" ${items.defaultSortMethod === 'alphabet-desc' ? 'selected' : ''}>Z-A</option>
            <option value="count-desc" ${items.defaultSortMethod === 'count-desc' ? 'selected' : ''}>数量降序</option>
            <option value="count-asc" ${items.defaultSortMethod === 'count-asc' ? 'selected' : ''}>数量升序</option>
            <option value="if-desc" ${items.defaultSortMethod === 'if-desc' ? 'selected' : ''}>IF降序</option>
            <option value="if-asc" ${items.defaultSortMethod === 'if-asc' ? 'selected' : ''}>IF升序</option>
          </select>
        </label>
        <small style="color: #666;">提取结果中期刊的默认排列顺序</small>
      </div>
      <div style="margin: 20px 0;">
        <div style="display: flex; align-items: center; justify-content: space-between; gap: 10px;">
          <label style="display: block; margin: 0; color: #333;">显示分区选项:</label>
          <button id="open-partition-settings" style="
            padding: 4px 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            background: #f5f5f5;
            color: #333;
            cursor: pointer;
            font-size: 13px;
            transition: background-color 0.2s;
          ">配置</button>
        </div>
        <div id="partition-selection-summary" style="margin-top: 8px; color: #555; font-size: 13px;">
          ${getPartitionSummaryText(partitions)}
        </div>
        <div style="display: none;">
          <input type="checkbox" id="display-if" ${partitions.showIF ? 'checked' : ''}>
          <input type="checkbox" id="display-jcr" ${partitions.showJCR ? 'checked' : ''}>
          <input type="checkbox" id="display-cas" ${partitions.showCAS ? 'checked' : ''}>
          <input type="checkbox" id="display-custom" ${partitions.showCustom ? 'checked' : ''}>
        </div>
        <small style="color: #666; display: block; margin-top: 6px;">影响提取结果中相应信息和筛选项的显示</small>
      </div>
      <div style="margin: 20px 0;">
        <label style="display: block; margin-bottom: 8px; color: #333;">自定义分区上传：</label>
        <input type="text" id="custom-partition-name" value=""
               placeholder="请输入分区名称，例如 ABC分区"
               style="width: 100%; margin-bottom: 8px; background: white; color: #333; border: 1px solid #ccc; border-radius: 4px; padding: 6px;">
        <input type="file" id="custom-partition-upload" accept=".xlsx" style="margin-bottom: 8px;">
        <small style="color: #666; display: block;">请先填写分区名称，再上传包含“分区”和“期刊”两列的.xlsx文件。</small>
        <small style="color: #666; display: block;">示例：分区=1，期刊=Nature；分区=2，期刊=Science；分区=3，期刊=Cell。</small>
        <div id="custom-partition-status" style="margin-top: 6px; color: #555; font-size: 12px;">${customPartitionStatusText}</div>
        <div id="custom-partition-list" style="margin-top: 10px; display: flex; flex-direction: column; gap: 8px;"></div>
      </div>
      <div style="text-align: right; margin-top: 20px;">
        <button id="cancel-settings" style="
          margin-right: 10px;
          padding: 5px 12px;
          border: 1px solid #ccc;
          border-radius: 4px;
          background: white;
          color: #333;
          cursor: pointer;
          transition: background-color 0.3s;
          height: 30px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          font-size: 14px;
        ">取消</button>
        <button id="save-settings" style="
          padding: 5px 12px;
          border: none;
          border-radius: 4px;
          background: #d3baf8;
          color: black;
          cursor: pointer;
          transition: background-color 0.3s;
          height: 30px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          font-size: 14px;
        ">保存</button>
      </div>
    `;

    document.body.appendChild(overlay);
    document.body.appendChild(dialog);

    const partitionConfigButton = dialog.querySelector('#open-partition-settings');
    const partitionSummaryElement = dialog.querySelector('#partition-selection-summary');
    const partitionHiddenInputs = {
      if: dialog.querySelector('#display-if'),
      jcr: dialog.querySelector('#display-jcr'),
      cas: dialog.querySelector('#display-cas'),
      custom: dialog.querySelector('#display-custom')
    };
    const customPartitionNameInput = dialog.querySelector('#custom-partition-name');
    const customPartitionUploadInput = dialog.querySelector('#custom-partition-upload');
    const customPartitionStatusElement = dialog.querySelector('#custom-partition-status');
    const customPartitionListElement = dialog.querySelector('#custom-partition-list');

    const renderCustomPartitionStatus = (message) => {
      if (!customPartitionStatusElement) return;
      const baseText = getCustomPartitionStatusText();
      customPartitionStatusElement.textContent = message || baseText;
    };

    const renderCustomPartitionList = () => {
      if (!customPartitionListElement) return;

      const partitionsData = getAllCustomPartitions();
      if (partitionsData.length === 0) {
        customPartitionListElement.innerHTML = '<div style="font-size: 13px; color: #777;">尚未上传自定义分区</div>';
        if (partitionHiddenInputs.custom) {
          partitionHiddenInputs.custom.checked = false;
          partitionHiddenInputs.custom.disabled = true;
        }
        return;
      }

      if (partitionHiddenInputs.custom) {
        partitionHiddenInputs.custom.disabled = false;
      }

      customPartitionListElement.innerHTML = partitionsData.map(partition => {
        const enabled = enabledCustomPartitionIds.has(partition.id);
        const journalCount = Object.keys(partition.map).length;
        const valuesText = partition.values.join('、') || '无';
        return `
        <div class="custom-partition-item" data-partition-id="${partition.id}" style="display: flex; justify-content: space-between; align-items: flex-start; gap: 10px; padding: 8px; border: 1px solid #e0e0e0; border-radius: 6px; background: #f8f9fa;">
          <div style="flex: 1;">
            <div style="font-weight: 600; color: #333;">${partition.name}</div>
            <div style="font-size: 12px; color: #666; margin-top: 4px;">期刊 ${journalCount} 个 | 分区选项：${valuesText}</div>
          </div>
          <div style="display: flex; flex-direction: column; gap: 6px; align-items: flex-end;">
            <label style="font-size: 12px; color: #333; display: flex; align-items: center; gap: 4px;">
              <input type="checkbox" class="custom-partition-visible" data-partition-id="${partition.id}" ${enabled ? 'checked' : ''}>
              显示
            </label>
            <button type="button" class="custom-partition-remove" data-partition-id="${partition.id}" style="border: 1px solid #e0e0e0; background: white; color: #d32f2f; border-radius: 4px; padding: 2px 8px; font-size: 12px; cursor: pointer;">删除</button>
          </div>
        </div>`;
      }).join('');

      customPartitionListElement.querySelectorAll('.custom-partition-visible').forEach((input) => {
        input.addEventListener('change', async (event) => {
          const { partitionId } = event.target.dataset;
          const isChecked = event.target.checked;
          try {
            await setCustomPartitionEnabled(partitionId, isChecked);
            if (partitionHiddenInputs.custom && getEnabledCustomPartitions().length === 0) {
              partitionHiddenInputs.custom.checked = false;
            }
            renderCustomPartitionStatus();
            updatePartitionSummary();
          } catch (error) {
            console.error('更新自定义分区显示状态失败:', error);
            showToast(error.message || '更新自定义分区显示状态失败', true);
            event.target.checked = !isChecked;
          }
        });
      });

      customPartitionListElement.querySelectorAll('.custom-partition-remove').forEach((button) => {
        button.addEventListener('click', async (event) => {
          const { partitionId } = event.currentTarget.dataset;
          const partition = customPartitionIndex.get(partitionId);
          const confirmDelete = confirm(`确定要删除 ${partition ? partition.name : '该分区'} 吗？此操作不可撤销。`);
          if (!confirmDelete) {
            return;
          }
          try {
            await removeCustomPartition(partitionId);
            if (partitionHiddenInputs.custom && getAllCustomPartitions().length === 0) {
              partitionHiddenInputs.custom.checked = false;
              partitionHiddenInputs.custom.disabled = true;
            }
            renderCustomPartitionStatus();
            renderCustomPartitionList();
            updatePartitionSummary();
            showToast('已删除自定义分区');
          } catch (error) {
            console.error('删除自定义分区失败:', error);
            showToast(error.message || '删除自定义分区失败', true);
          }
        });
      });
    };

    renderCustomPartitionStatus();
    renderCustomPartitionList();

    if (customPartitionUploadInput) {
      customPartitionUploadInput.addEventListener('change', async (event) => {
        const file = event.target.files?.[0];
        if (!file) {
          return;
        }

        const partitionName = customPartitionNameInput?.value.trim();
        if (!partitionName) {
          showToast('请先填写分区名称', true);
          event.target.value = '';
          return;
        }

        try {
          renderCustomPartitionStatus('正在解析上传文件，请稍候...');
          const parsed = await parseCustomPartitionXlsx(file);
          await addOrUpdateCustomPartition(partitionName, parsed);

          if (customPartitionNameInput) {
            customPartitionNameInput.value = '';
          }

          if (partitionHiddenInputs.custom) {
            partitionHiddenInputs.custom.disabled = false;
            partitionHiddenInputs.custom.checked = true;
          }

          renderCustomPartitionStatus();
          renderCustomPartitionList();
          updatePartitionSummary();
          showToast(`已加载自定义分区：${partitionName}`);
        } catch (error) {
          console.error('解析自定义分区失败:', error);
          showToast(error.message || '解析自定义分区失败', true);
          renderCustomPartitionStatus();
        } finally {
          event.target.value = '';
        }
      });
    }

    const closePartitionModals = () => {
      const overlays = document.querySelectorAll('.partition-settings-overlay, .partition-settings-modal');
      overlays.forEach(element => element.remove());
    };

    const buildPartitionStateFromInputs = () => ({
      showIF: partitionHiddenInputs.if?.checked || false,
      showJCR: partitionHiddenInputs.jcr?.checked || false,
      showCAS: partitionHiddenInputs.cas?.checked || false,
      showCustom: partitionHiddenInputs.custom?.checked || false
    });

    const updatePartitionSummary = () => {
      if (partitionSummaryElement) {
        partitionSummaryElement.textContent = getPartitionSummaryText(buildPartitionStateFromInputs());
      }
    };

    const openPartitionSettingsModal = () => {
      closePartitionModals();

      const overlay = document.createElement('div');
      overlay.classList.add('partition-settings-overlay');
      overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.4);
        z-index: 1102;
      `;

      const modal = document.createElement('div');
      modal.classList.add('partition-settings-modal');
      modal.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: white;
        color: #333;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        width: 320px;
        max-width: 90vw;
        z-index: 1103;
      `;

      const currentState = buildPartitionStateFromInputs();
      const allCustomPartitionsInModal = getAllCustomPartitions();
      const customPartitionAvailable = allCustomPartitionsInModal.length > 0;
      const enabledCustomCount = getEnabledCustomPartitions().length;
      const customPartitionLabel = customPartitionAvailable
        ? `自定义分区（已启用 ${enabledCustomCount} 个）`
        : '自定义分区（请先上传文件）';

      modal.innerHTML = `
        <h3 style="margin-top: 0; margin-bottom: 12px; font-size: 16px;">选择显示的分区信息</h3>
        <div style="display: flex; flex-direction: column; gap: 10px; margin-bottom: 16px;">
          <label style="display: flex; align-items: center; gap: 8px;">
            <input type="checkbox" id="partition-modal-if" ${currentState.showIF ? 'checked' : ''}>
            <span>影响因子</span>
          </label>
          <label style="display: flex; align-items: center; gap: 8px;">
            <input type="checkbox" id="partition-modal-jcr" ${currentState.showJCR ? 'checked' : ''}>
            <span>JCR分区</span>
          </label>
          <label style="display: flex; align-items: center; gap: 8px;">
            <input type="checkbox" id="partition-modal-cas" ${currentState.showCAS ? 'checked' : ''}>
            <span>新锐分区（含TOP）</span>
          </label>
          <label style="display: flex; align-items: center; gap: 8px; ${customPartitionAvailable ? '' : 'opacity: 0.6;'}">
            <input type="checkbox" id="partition-modal-custom" ${currentState.showCustom && customPartitionAvailable ? 'checked' : ''} ${customPartitionAvailable ? '' : 'disabled'}>
            <span>${customPartitionLabel}</span>
          </label>
          ${customPartitionAvailable ? '' : '<small style="margin-left: 26px; color: #999;">上传有效的.xlsx文件后即可启用自定义分区显示</small>'}
        </div>
        <small style="display: block; margin-bottom: 16px; color: #666;">保存后将在主界面显示/隐藏对应信息，并影响筛选条件。</small>
        <div style="text-align: right;">
          <button id="partition-modal-cancel" style="
            margin-right: 10px;
            padding: 4px 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            background: #f5f5f5;
            color: #333;
            cursor: pointer;
          ">取消</button>
          <button id="partition-modal-save" style="
            padding: 4px 12px;
            border: none;
            border-radius: 4px;
            background: #d3baf8;
            color: black;
            cursor: pointer;
          ">保存</button>
        </div>
      `;

      const closeModal = () => {
        closePartitionModals();
      };

      overlay.addEventListener('click', closeModal);
      modal.addEventListener('click', (event) => event.stopPropagation());

      document.body.appendChild(overlay);
      document.body.appendChild(modal);

      const currentTheme = localStorage.getItem('theme') || 'light';
      applyThemeToElement(modal, currentTheme);

      const modalIf = modal.querySelector('#partition-modal-if');
      const modalJcr = modal.querySelector('#partition-modal-jcr');
      const modalCas = modal.querySelector('#partition-modal-cas');
      const modalCustom = modal.querySelector('#partition-modal-custom');

      modal.querySelector('#partition-modal-cancel').addEventListener('click', closeModal);
      modal.querySelector('#partition-modal-save').addEventListener('click', () => {
        if (partitionHiddenInputs.if) partitionHiddenInputs.if.checked = modalIf.checked;
        if (partitionHiddenInputs.jcr) partitionHiddenInputs.jcr.checked = modalJcr.checked;
        if (partitionHiddenInputs.cas) partitionHiddenInputs.cas.checked = modalCas.checked;
        if (partitionHiddenInputs.custom) partitionHiddenInputs.custom.checked = modalCustom && !modalCustom.disabled ? modalCustom.checked : false;
        updatePartitionSummary();
        closeModal();
      });
    };

    if (partitionConfigButton) {
      partitionConfigButton.addEventListener('click', openPartitionSettingsModal);
    }

    updatePartitionSummary();

    // 更新主题图标显示
    function updateSettingsThemeIcons() {
      const currentTheme = localStorage.getItem('theme') || 'light';
      const moonIcon = dialog.querySelector('.moon-icon-settings');
      const sunIcon = dialog.querySelector('.sun-icon-settings');
      
      if (currentTheme === 'dark') {
        moonIcon.style.display = 'none';
        sunIcon.style.display = 'block';
      } else {
        moonIcon.style.display = 'block';
        sunIcon.style.display = 'none';
      }
    }

    // 主题切换函数
    function toggleSettingsTheme() {
      const currentTheme = localStorage.getItem('theme') || 'light';
      const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
      localStorage.setItem('theme', newTheme);
      
      // 更新对话框主题
      dialog.setAttribute('data-theme', newTheme);
      updateSettingsThemeIcons();
      
      // 应用主题样式到对话框
      applyThemeToElement(dialog, newTheme);
      
      // 如果存在论文提取结果窗口，也更新其主题
      const extractedTitles = document.getElementById('extracted-titles');
      if (extractedTitles) {
        extractedTitles.setAttribute('data-theme', newTheme);
        applyThemeToElement(extractedTitles, newTheme);
      }
    }

    // 初始化主题图标
    updateSettingsThemeIcons();
    
    // 应用初始主题
    const currentTheme = localStorage.getItem('theme') || 'light';
    applyThemeToElement(dialog, currentTheme);

    // 主题切换按钮事件
    document.getElementById('theme-toggle-settings').addEventListener('click', toggleSettingsTheme);

    // 添加按钮悬停效果
    const saveButton = document.getElementById('save-settings');
    saveButton.onmouseover = function() {
      this.style.backgroundColor = '#e1ceff';
    };
    saveButton.onmouseout = function() {
      this.style.backgroundColor = '#d3baf8';
    };

    const cancelButton = document.getElementById('cancel-settings');
    cancelButton.onmouseover = function() {
      this.style.backgroundColor = '#f0f0f0';
    };
    cancelButton.onmouseout = function() {
      this.style.backgroundColor = 'white';
    };

    // 添加事件监听器
    document.getElementById('cancel-settings').onclick = function() {
      closePartitionModals();
      overlay.remove();
      dialog.remove();
    };

    document.getElementById('save-settings').onclick = function() {
      const newMaxPages = parseInt(document.getElementById('max-pages-input').value);
      const newDefaultSortMethod = document.getElementById('default-sort-method').value;
      const newDisplayPartitions = {
        showIF: document.getElementById('display-if').checked,
        showJCR: document.getElementById('display-jcr').checked,
        showCAS: document.getElementById('display-cas').checked,
        showCustom: getAllCustomPartitions().length > 0 ? document.getElementById('display-custom').checked : false
      };
      if (newMaxPages >= 1 && newMaxPages <= 50) {
        chrome.storage.sync.set({
          maxPages: newMaxPages,
          defaultSortMethod: newDefaultSortMethod,
          displayPartitions: newDisplayPartitions
        }, function() {
          maxPages = newMaxPages; // 更新当前页面的变量
          displayPartitions = { ...DEFAULT_DISPLAY_PARTITIONS, ...newDisplayPartitions };
          closePartitionModals();
          overlay.remove();
          dialog.remove();
          // 显示保存成功提示
          showToast('设置已保存');
        });
      } else {
        alert('请输入1-50之间的页数');
      }
    };

    // 点击遮罩层关闭对话框
    overlay.onclick = function() {
      closePartitionModals();
      overlay.remove();
      dialog.remove();
    };
  });
}

// 添加提示消息功能
function showToast(message, isWarning = false) {
  const toast = document.createElement('div');
  toast.style.cssText = `
    position: fixed;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    background: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 10px 20px;
    border-radius: 4px;
    z-index: 1002;
    display: flex;
    align-items: center;
    gap: 10px;
  `;

  const icon = document.createElement('span');
  icon.style.fontSize = '20px';
  icon.textContent = isWarning ? '⚠️' : '✅';

  const messageText = document.createElement('span');
  messageText.textContent = message;

  toast.appendChild(icon);
  toast.appendChild(messageText);
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.remove();
  }, 2000);
}

// 主题色彩定义
const themes = {
  light: {
    bgColor: '#fff',
    textColor: '#202124',
    textSecondary: '#5f6368',
    borderColor: '#dadce0',
    hoverBg: '#f8f9fa',
    lightGray: '#f1f3f4',
    primaryColor: '#4285f4',
    neutralColor: '#5f6368',
    paperBgEven: '#f9f9f9',
    paperBgOdd: '#e6f7ff',
    highlightColor: 'darkred',
    journalCountColor: '#666'
  },
  dark: {
    bgColor: '#202124',
    textColor: '#e8eaed',
    textSecondary: '#9aa0a6',
    borderColor: '#5f6368',
    hoverBg: '#303134',
    lightGray: '#3c4043',
    primaryColor: '#8ab4f8',
    neutralColor: '#9aa0a6',
    paperBgEven: '#2d3842',
    paperBgOdd: '#232629',
    highlightColor: '#ff69b4',
    journalCountColor: '#9aa0a6'
  }
};

// 应用主题到元素
function applyThemeToElement(element, theme) {
  const colors = themes[theme];
  if (!colors) return;

  // 更新元素背景和文字色
  element.style.backgroundColor = colors.bgColor;
  element.style.color = colors.textColor;

  // 更新所有子元素
  const inputs = element.querySelectorAll('input, select, textarea');
  inputs.forEach(input => {
    input.style.backgroundColor = colors.bgColor;
    input.style.color = colors.textColor;
    input.style.borderColor = colors.borderColor;
  });

  const labels = element.querySelectorAll('label, h2, h3');
  labels.forEach(label => {
    label.style.color = colors.textColor;
  });

  const smalls = element.querySelectorAll('small');
  smalls.forEach(small => {
    small.style.color = colors.textSecondary;
  });

  const filterContainers = element.querySelectorAll('.filter-sort-container > div:last-child > div:last-child, #journal-filter');
  filterContainers.forEach(container => {
    container.style.backgroundColor = colors.hoverBg;
    container.style.borderColor = colors.borderColor;
  });

  const partitionSummaryElements = element.querySelectorAll('#partition-selection-summary');
  partitionSummaryElements.forEach(summary => {
    summary.style.color = colors.textSecondary;
  });

  const partitionConfigButtons = element.querySelectorAll('#open-partition-settings');
  partitionConfigButtons.forEach(button => {
    button.style.backgroundColor = colors.hoverBg;
    button.style.color = colors.textColor;
    button.style.borderColor = colors.borderColor;
  });

  const paperItems = element.querySelectorAll('.paper-item');
  paperItems.forEach((item, index) => {
    item.style.borderColor = colors.borderColor;
    // 应用交替背景色
    const paperContent = item.querySelector('.paper-content');
    if (paperContent) {
      paperContent.style.backgroundColor = index % 2 === 0 ? colors.paperBgEven : colors.paperBgOdd;
      paperContent.style.color = colors.textColor;
    }
  });

  const paperLinks = element.querySelectorAll('.paper-title-link');
  paperLinks.forEach(link => {
    link.style.color = colors.textColor;
  });

  // 更新清除筛选按钮
  const clearButton = element.querySelector('#clear-filters');
  if (clearButton) {
    clearButton.style.backgroundColor = colors.lightGray;
    clearButton.style.color = colors.textColor;
    clearButton.style.borderColor = colors.borderColor;
  }
  
  // 更新主题切换按钮的图标颜色
  const themeIcons = element.querySelectorAll('.moon-icon-settings, .sun-icon-settings, .moon-icon-extraction, .sun-icon-extraction');
  themeIcons.forEach(icon => {
    icon.style.fill = colors.textColor;
  });
  
  // 更新全选容器的背景色
  const selectAllContainer = element.querySelector('.select-all-container');
  if (selectAllContainer) {
    selectAllContainer.style.backgroundColor = colors.hoverBg;
  }
  
  // 更新摘要中高亮关键词的颜色
  const highlightElements = element.querySelectorAll('.snippet-content b, .snippet-content strong');
  highlightElements.forEach(highlight => {
    highlight.style.color = colors.highlightColor;
  });
  
  // 更新TOP期刊标签的颜色
  const topFilterLabels = element.querySelectorAll('.top-filter-label');
  topFilterLabels.forEach(label => {
    label.style.color = colors.textColor;
  });
  
  // 更新期刊数量的颜色
  const journalCounts = element.querySelectorAll('.journal-count');
  journalCounts.forEach(count => {
    count.style.color = colors.journalCountColor;
  });
}

// 修改初始化函数，添加设置的加载
async function initialize() {
  // 初始化主题
  const savedTheme = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-theme', savedTheme);
  
  await loadCustomPartitionFromStorage();

  // 加载设置
  chrome.storage.sync.get({
    maxPages: 10, // 默认值
    defaultSortMethod: 'alphabet-asc', // 默认排序方式
    displayPartitions: DEFAULT_DISPLAY_PARTITIONS
  }, function(items) {
    maxPages = items.maxPages;
    displayPartitions = {
      ...DEFAULT_DISPLAY_PARTITIONS,
      ...(items.displayPartitions || {})
    };
    if (!hasCustomPartitionData()) {
      displayPartitions.showCustom = false;
    }
  });

  await loadCSVData();
  chrome.storage.local.get(['isExtracting', 'currentPage', 'allPapers'], (data) => {
    isExtracting = data.isExtracting || false;
    addExtractButton();
    addSettingsButton(); // 添加设置按钮
    addProgressBar(); // 添加进度条
    gsaAddAuthorRoleButton(); // 个人主页作者标注入口
    gsaScheduleMIndexMetric(); // 个人主页 m-index 指标

    // 添加按钮悬停效果
    const addHoverEffect = (id) => {
      const button = document.getElementById(id);
      if (button) {
        button.onmouseover = function() {
          this.style.backgroundColor = '#e1ceff';
        };
        button.onmouseout = function() {
          this.style.backgroundColor = '#d3baf8';
        };
      }
    };

    // 对所有按钮添加相同的悬停效果
    setTimeout(() => {
      addHoverEffect('get-abstracts');
      addHoverEffect('cite-selected');
      addHoverEffect('open-selected');
      addHoverEffect('clear-filters');
      addHoverEffect('close-window');
    }, 1000);

    if (isExtracting) {
      console.log('检测到正在进行的提取，继续提取。');
      // 如果正在提取，显示进度条
      if (data.currentPage && data.allPapers) {
        updateProgressBar(data.currentPage, maxPages, data.allPapers.length);
      }
      setTimeout(extractAndNavigate, 2000);
    } else {
      // 如果没有正在提取，隐藏进度条
      hideProgressBar();
    }
  });
}

initialize();


// 监听页面变化
let lastUrl = location.href;
new MutationObserver(() => {
  const url = location.href;
  if (url !== lastUrl) {
    console.log('检测到页面URL变化，可能导航到新页面。');
    lastUrl = url;
    setTimeout(() => {
      gsaAddAuthorRoleButton();
      gsaScheduleMIndexMetric();
    }, 500);
    chrome.storage.local.get(['isExtracting'], (data) => {
      if (data.isExtracting) {
        console.log('提取正在进行中，继续提取。');
        setTimeout(extractAndNavigate, 2000);
      }
    });
  }
}).observe(document, {subtree: true, childList: true});

// 清除所有筛选器的函数
function clearAllFilters() {
  isManualJournalSelection = false;
  // 重置期刊筛选
  const journalFilter = document.getElementById('journal-filter');
  const journalCheckboxes = journalFilter.querySelectorAll('input[type="checkbox"]');
  journalCheckboxes.forEach(cb => {
    cb.checked = true;
  });

  // 重置JCR分区筛选
  const jcrFilters = document.querySelectorAll('input[name="jcr-filter"]');
  jcrFilters.forEach(filter => filter.checked = false);

  // 重置新锐分区筛选
  const casFilters = document.querySelectorAll('input[name="cas-filter"]');
  casFilters.forEach(filter => filter.checked = false);

  // 重置自定义分区筛选
  const customFilters = document.querySelectorAll('input[data-custom-filter]');
  customFilters.forEach(filter => filter.checked = false);

  // 重置TOP期刊筛选
  const topFilter = document.getElementById('top-filter');
  if (topFilter) {
    topFilter.checked = false;
  }

  // 重置IF范围
  const ifMinInput = document.getElementById('if-min');
  if (ifMinInput) {
    ifMinInput.value = '';
  }

  // 重新应用选
  filterJournals();
}

// 添加新函数来创建引用按钮
function addCitationButton(paperElement, title) {
  const citationButton = document.createElement('button');
  citationButton.textContent = '引用';
  citationButton.style.cssText = `
    background-color: #d3baf8;
    color: black;
    border: none;
    padding: 5px 12px;
    border-radius: 4px;
    cursor: pointer;
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    transition: background-color 0.3s;
    height: 30px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
  `;

  citationButton.onmouseover = function() {
    this.style.backgroundColor = '#e1ceff';
  };
  citationButton.onmouseout = function() {
    this.style.backgroundColor = '#d3baf8';
  };

  citationButton.onclick = function() {
    handleCitation(title);
  };

  paperElement.style.position = 'relative';
  paperElement.appendChild(citationButton);
}

// 修改 getPubMedData 函数
async function getPubMedData(title) {
  try {
    console.log('开始 PubMed 搜索，原始标题:', title);

    // 1. 使用更简短的标题进行搜索
    const shortTitle = title
      .split(/[\(\):]/)[0]  // 取第一个括号或冒号前的内容
      .split('and')[0]      // 取第一个 and 前的内容
      .trim()
      .substring(0, 100);   // 限制长度

    console.log('简化后的标题:', shortTitle);

    // 2. 搜索文章
    const searchUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=${encodeURIComponent(shortTitle)}&retmode=json`;
    console.log('PubMed 搜索 URL:', searchUrl);

    const searchResponse = await fetch(searchUrl);
    if (!searchResponse.ok) {
      throw new Error(`PubMed 搜索请求失败: ${searchResponse.status}`);
    }
    const searchData = await searchResponse.json();
    console.log('PubMed 搜索结果:', searchData);

    if (!searchData.esearchresult.idlist || searchData.esearchresult.idlist.length === 0) {
      console.log('PubMed 未找到匹配文章');
      return null;
    }

    // 3. 获取详细信息
    const pmid = searchData.esearchresult.idlist[0];
    console.log('找到 PMID:', pmid);

    const detailUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&id=${pmid}&retmode=json`;
    console.log('PubMed 详情 URL:', detailUrl);

    const detailResponse = await fetch(detailUrl);
    if (!detailResponse.ok) {
      throw new Error(`PubMed 详情请求失败: ${detailResponse.status}`);
    }
    const detailData = await detailResponse.json();
    console.log('PubMed 详细数据:', detailData);

    const article = detailData.result[pmid];
    if (!article) {
      console.log('未找到文章详细信息');
      return null;
    }

    // 4. 提取所需数据
    const extractedData = {
      Title: article.title || '',
      Authors: article.authors ? article.authors.map(a => a.name).join('; ') : '',
      Year: article.pubdate ? article.pubdate.substring(0, 4) : '',
      Journal: (article.fulljournalname || article.source || '').toUpperCase(),
      Volume: article.volume || '',
      Issue: article.issue || '',
      Pages: article.pages || '',
      DOI: article.elocationid ? article.elocationid.replace('doi: ', '') : '',
      PMID: pmid,
      Abstract: article.abstracttext || ''
    };

    console.log('从 PubMed 提取的数据:', extractedData);

    // 5. 验证数据完整性
    const requiredFields = ['Title', 'Authors', 'Journal'];
    const missingFields = requiredFields.filter(field => !extractedData[field]);

    if (missingFields.length > 0) {
      console.log('缺少必要字段:', missingFields);
      return null;
    }

    return extractedData;

  } catch (error) {
    console.error('从 PubMed 获取数据时出错:', error);
    console.error('错误堆栈:', error.stack);
    return null;
  }
}

// 修改 getCitationInfo 函数
async function handleCitation(title) {
  const loadingOverlay = showLoadingOverlay('正在获取引用信息...');
  try {
    const results = await downloadRisForTitles([title]);
    const outcome = results[0];
    if (!outcome || outcome.status !== 'success') {
      throw new Error('无法找到文献引用信息');
    }

    showToast('引用信息已导出');

  } catch (error) {
    console.error('获取引用信息时出错:', error);
    alert(`获取引用信息失败: ${error.message}`);
  } finally {
    loadingOverlay.remove();
  }
}

async function getCrossrefData(title) {
  try {
    const encodedTitle = encodeURIComponent(title.trim());
    const url = `https://api.crossref.org/works?query.title=${encodedTitle}&filter=type:journal-article&rows=1`;

    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Crossref API 响应失败: ${response.status}`);
    }

    const data = await response.json();
    const items = data.message?.items;

    if (!items || items.length === 0) {
      return null;
    }

    const article = items[0];
    const authors = article.author?.map(a => {
      const family = a.family || '';
      const given = a.given || '';
      return `${family}${family && given ? ', ' : ''}${given}`;
    }).join('; ') || '';

    return {
      Title: article.title?.[0] || '',
      Authors: authors,
      Year: article['published-print']?.['date-parts']?.[0]?.[0] ||
            article['published-online']?.['date-parts']?.[0]?.[0] || '',
      Journal: (article['container-title']?.[0]?.replace(/&amp;/g, '&') || '').toUpperCase(),
      Volume: article.volume || '',
      Issue: article.issue || '',
      Pages: article.page || '',
      DOI: article.DOI || ''
    };
  } catch (error) {
    console.error('从 Crossref 获取数据时出错:', error);
    return null;
  }
}

// 新增加载提示函数
function showLoadingOverlay(message) {
  const overlay = document.createElement('div');
  overlay.className = 'loading-overlay';
  overlay.innerHTML = `
    <div class="loading-content">
      <div class="loading-spinner"></div>
      <div>${message}</div>
    </div>
  `;
  document.body.appendChild(overlay);
  return overlay;
}

// 添加全选功能的事件监听器
document.getElementById('select-all-papers').addEventListener('change', function() {
  const isChecked = this.checked;
  const visiblePapers = document.querySelectorAll('.paper-item:not([style*="display: none"]) .paper-checkbox');
  visiblePapers.forEach(checkbox => {
    checkbox.checked = isChecked;
  });
});

// 监听筛选变化，更新全选框状态
const updateSelectAllState = () => {
  const selectAllCheckbox = document.getElementById('select-all-papers');
  const visiblePapers = document.querySelectorAll('.paper-item:not([style*="display: none"]) .paper-checkbox');
  const checkedPapers = document.querySelectorAll('.paper-item:not([style*="display: none"]) .paper-checkbox:checked');

  if (visiblePapers.length === 0) {
    selectAllCheckbox.checked = false;
    selectAllCheckbox.indeterminate = false;
  } else if (checkedPapers.length === 0) {
    selectAllCheckbox.checked = false;
    selectAllCheckbox.indeterminate = false;
  } else if (checkedPapers.length === visiblePapers.length) {
    selectAllCheckbox.checked = true;
    selectAllCheckbox.indeterminate = false;
  } else {
    selectAllCheckbox.checked = false;
    selectAllCheckbox.indeterminate = true;
  }
};

// 监听单个论文的选择变化
document.addEventListener('change', function(e) {
  if (e.target.classList.contains('paper-checkbox')) {
    updateSelectAllState();
  }
});

// 在筛选后更新全选状态
const originalFilterJournals = filterJournals;
filterJournals = function() {
  originalFilterJournals.apply(this, arguments);
  updateSelectAllState();
};

function addProgressBar() {
  let progressContainer = document.getElementById('extraction-progress-container');
  if (!progressContainer) {
    progressContainer = document.createElement('div');
    progressContainer.id = 'extraction-progress-container';
    progressContainer.style.cssText = `
      position: fixed;
      left: 20px;
      bottom: 17%;
      width: 180px;
      background-color: white;
      border-radius: 8px;
      padding: 10px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.2);
      z-index: 999;
      display: none;
    `;

    progressContainer.innerHTML = `
      <div style="margin-bottom: 5px; font-size: 12px; display: flex; justify-content: space-between;">
        <span id="progress-text">提取中...</span>
        <span id="progress-percentage">0%</span>
      </div>
      <div style="width: 100%; background-color: #f0f0f0; border-radius: 4px; overflow: hidden;">
        <div id="progress-bar" style="height: 8px; width: 0%; background-color: #d3baf8; transition: width 0.3s;"></div>
      </div>
      <div style="margin-top: 5px; font-size: 12px; text-align: center;">
        <span id="progress-details">第 0/0 页，共 0 篇论文</span>
      </div>
    `;

    document.body.appendChild(progressContainer);
  }
  return progressContainer;
}

function updateProgressBar(currentPage, maxPages, paperCount) {
  const progressContainer = document.getElementById('extraction-progress-container');
  if (!progressContainer) return;

  const progressBar = document.getElementById('progress-bar');
  const progressPercentage = document.getElementById('progress-percentage');
  const progressDetails = document.getElementById('progress-details');

  // 计算进度百分比
  const percentage = Math.min(Math.round((currentPage / maxPages) * 100), 100);

  // 更新进度条
  progressBar.style.width = `${percentage}%`;
  progressPercentage.textContent = `${percentage}%`;
  progressDetails.textContent = `第 ${currentPage}/${maxPages} 页，共 ${paperCount} 篇论文`;

  // 显示进度条容器
  progressContainer.style.display = 'block';
}

function hideProgressBar() {
  const progressContainer = document.getElementById('extraction-progress-container');
  if (progressContainer) {
    progressContainer.style.display = 'none';
  }
}

// 添加按钮悬停效果的样式
const buttonStyle = document.createElement('style');
buttonStyle.textContent = `
  #get-abstracts:hover,
  #cite-selected:hover,
  #open-selected:hover,
  #clear-filters:hover,
  #close-window:hover {
    background-color: #e1ceff;
  }
`;
document.head.appendChild(buttonStyle);

// 添加主题样式
const themeStyleElement = document.createElement('style');
themeStyleElement.textContent = `
  /* Light theme variables */
  :root, [data-theme="light"] {
    --primary-color: #4285f4;
    --primary-dark: #3367d6;
    --success-color: #34a853;
    --success-dark: #2d904d;
    --danger-color: #ea4335;
    --danger-dark: #c5221f;
    --neutral-color: #5f6368;
    --neutral-dark: #3c4043;
    --light-gray: #f1f3f4;
    --border-color: #dadce0;
    --box-shadow: 0 1px 3px rgba(60, 64, 67, 0.3);
    --bg-color: #fff;
    --text-color: #202124;
    --text-secondary: #5f6368;
    --hover-bg: #f8f9fa;
    --modal-bg: rgba(0, 0, 0, 0.5);
  }

  /* Dark theme variables */
  [data-theme="dark"] {
    --primary-color: #8ab4f8;
    --primary-dark: #669df6;
    --success-color: #81c995;
    --success-dark: #5bb974;
    --danger-color: #f28b82;
    --danger-dark: #ee675c;
    --neutral-color: #9aa0a6;
    --neutral-dark: #bdc1c6;
    --light-gray: #3c4043;
    --border-color: #5f6368;
    --box-shadow: 0 1px 3px rgba(0, 0, 0, 0.5);
    --bg-color: #202124;
    --text-color: #e8eaed;
    --text-secondary: #9aa0a6;
    --hover-bg: #303134;
    --modal-bg: rgba(0, 0, 0, 0.7);
  }

  /* 主题切换按钮悬停效果 */
  #theme-toggle-settings:hover, #theme-toggle-extraction:hover {
    background-color: var(--hover-bg) !important;
  }

  /* 更新按钮样式以支持主题 */
  .action-button {
    opacity: 1;
    transition: all 0.3s ease;
    background-color: #d3baf8 !important;
    color: black !important;
  }
  .action-button:hover {
    background-color: #e1ceff !important;
    opacity: 0.8;
  }

  /* 设置对话框主题样式 */
  #settings-dialog {
    background: var(--bg-color) !important;
    color: var(--text-color) !important;
    border: 1px solid var(--border-color);
  }

  #settings-dialog input, #settings-dialog select {
    background: var(--bg-color) !important;
    color: var(--text-color) !important;
    border: 1px solid var(--border-color) !important;
  }

  #settings-dialog input:focus, #settings-dialog select:focus {
    border-color: var(--primary-color) !important;
    outline: none;
    box-shadow: 0 0 0 2px rgba(138, 180, 248, 0.2);
  }

  /* 论文提取结果页面主题样式 */
  #extracted-titles {
    background: var(--bg-color) !important;
    color: var(--text-color) !important;
    border: 1px solid var(--border-color);
  }

  #extracted-titles h3 {
    color: var(--text-color) !important;
  }

  #extracted-titles .filter-sort-container {
    background: var(--bg-color) !important;
  }

  #extracted-titles input, #extracted-titles select {
    background: var(--bg-color) !important;
    color: var(--text-color) !important;
    border: 1px solid var(--border-color) !important;
  }

  #extracted-titles input:focus, #extracted-titles select:focus {
    border-color: var(--primary-color) !important;
    outline: none;
    box-shadow: 0 0 0 2px rgba(138, 180, 248, 0.2);
  }

  /* 论文项目的主题样式 */
  .paper-item {
    border: 1px solid var(--border-color) !important;
    background: var(--bg-color) !important;
  }

  .paper-content {
    color: var(--text-color) !important;
  }

  .paper-title-link {
    color: var(--text-color) !important;
  }

  .paper-title-link:hover {
    color: var(--primary-color) !important;
  }

  /* 期刊筛选区域样式 */
  #journal-filter {
    background: var(--hover-bg) !important;
    border: 1px solid var(--border-color) !important;
  }

  #journal-filter label {
    color: var(--text-color) !important;
  }

  #journal-filter label:hover {
    background-color: var(--light-gray) !important;
  }

  /* 筛选选项区域样式 */
  .filter-sort-container > div:last-child > div:last-child {
    background: var(--hover-bg) !important;
    border: 1px solid var(--border-color) !important;
  }

  /* 清除筛选按钮样式 */
  #clear-filters {
    background-color: var(--light-gray) !important;
    color: var(--text-color) !important;
    border: 1px solid var(--border-color) !important;
  }

  #clear-filters:hover {
    background-color: var(--neutral-color) !important;
    color: white !important;
  }

  /* 小标签样式 */
  small {
    color: var(--text-secondary) !important;
  }

  /* 加载覆盖层样式 */
  .loading-overlay {
    background: var(--modal-bg) !important;
  }

  .loading-content {
    background: var(--bg-color) !important;
    color: var(--text-color) !important;
    border: 1px solid var(--border-color);
  }

  /* 自定义弹窗样式 */
  .custom-alert .alert-content,
  .custom-confirm .confirm-content {
    background: var(--bg-color) !important;
    color: var(--text-color) !important;
    border: 1px solid var(--border-color);
  }

  /* 摘要窗口样式 */
  .abstracts-window {
    background: var(--bg-color) !important;
    color: var(--text-color) !important;
    border: 1px solid var(--border-color);
  }
`;
document.head.appendChild(themeStyleElement);

// 为所有按钮添加事件监听器
document.querySelectorAll('.action-button').forEach(button => {
  button.onmouseover = function() {
    this.style.backgroundColor = '#e1ceff';
  };
  button.onmouseout = function() {
    this.style.backgroundColor = '#d3baf8';
  };
});

// 监听来自background的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[CONTENT] 收到消息:', {
    action: message.action,
    timestamp: new Date().toISOString(),
    sender: sender.id,
    hasResults: message.results ? message.results.length : 'N/A'
  });
  
  try {
    switch (message.action) {
      case "ping":
        console.log('[CONTENT] 响应ping消息');
        sendResponse({ 
          pong: true, 
          timestamp: Date.now(),
          ready: true,
          url: window.location.href
        });
        break;
        
      case "showToast":
        console.log('[CONTENT] 显示Toast:', message.message);
        try {
          showToast(message.message, message.isWarning);
          sendResponse({ success: true });
        } catch (error) {
          console.error('[CONTENT] Toast显示失败:', error);
          sendResponse({ success: false, error: error.message });
        }
        break;
        
      case "showAnalysisResults":
        console.log('[CONTENT] 准备显示分析结果，数量:', message.results?.length);
        
        if (!message.results) {
          console.error('[CONTENT] 没有分析结果数据');
          sendResponse({ success: false, error: '没有分析结果数据' });
          break;
        }
        
        try {
          displayLinkAnalysisResults(message.results);
          console.log('[CONTENT] 分析结果显示成功');
          sendResponse({ success: true, displayed: message.results.length });
        } catch (error) {
          console.error('[CONTENT] 显示分析结果失败:', error);
          sendResponse({ success: false, error: error.message });
          
          // 降级显示：至少显示一个简单的提示
          try {
            showToast(`分析完成，但结果显示出错: ${error.message}`, true);
          } catch (fallbackError) {
            console.error('[CONTENT] 降级提示也失败:', fallbackError);
          }
        }
        break;
        
      default:
        console.warn('[CONTENT] 未知消息类型:', message.action);
        sendResponse({ success: false, error: 'Unknown action: ' + message.action });
    }
  } catch (error) {
    console.error('[CONTENT] 消息处理异常:', error);
    sendResponse({ success: false, error: '消息处理异常: ' + error.message });
  }
  
  return true; // 保持消息通道开放
});

// 显示链接分析结果
function displayLinkAnalysisResults(results) {
  const analysisWindow = document.createElement('div');
  analysisWindow.className = 'link-analysis-window';
  analysisWindow.setAttribute('data-theme', localStorage.getItem('theme') || 'light');
  analysisWindow.style.cssText = `
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 85%;
    max-width: 1200px;
    height: 85vh;
    background: white;
    color: black;
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
    z-index: 1001;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    transition: background-color 0.3s, color 0.3s;
  `;

  const overlay = document.createElement('div');
  overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.5);
    z-index: 1000;
  `;

  const successful = results.filter(r => r.status === 'success').length;
  const failed = results.filter(r => r.status === 'failed').length;

  const content = `
    <div style="
      padding: 20px;
      border-bottom: 1px solid #e0e0e0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #f8f9fa;
      border-radius: 12px 12px 0 0;
    ">
      <div>
        <h2 style="margin: 0; color: #333;">链接AI分析结果</h2>
        <div style="margin-top: 8px; font-size: 0.9em; color: #666;">
          总计: ${results.length} | 成功: ${successful} | 失败: ${failed}
        </div>
      </div>
      <div style="display: flex; gap: 10px;">
        <button id="export-analysis-results" style="
          padding: 8px 16px;
          border: none;
          border-radius: 6px;
          background: #d3baf8;
          color: black;
          cursor: pointer;
          transition: background-color 0.3s;
          font-size: 14px;
        ">导出结果</button>
        <button id="close-analysis" style="
          width: 32px;
          height: 32px;
          border: none;
          border-radius: 6px;
          background: #d3baf8;
          color: black;
          cursor: pointer;
          transition: background-color 0.3s;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
        ">×</button>
      </div>
    </div>
    <div style="
      flex: 1;
      overflow-y: auto;
      padding: 20px;
    ">
      ${results.map((result, index) => `
        <div style="
          margin-bottom: 24px;
          padding: 20px;
          border: 1px solid #e0e0e0;
          border-radius: 12px;
          background: ${result.status === 'success' ? '#f8fff8' : '#fff8f8'};
        ">
          <div style="margin-bottom: 12px;">
            <h3 style="
              margin: 0 0 8px 0;
              color: #333;
              font-size: 1.1em;
              display: flex;
              align-items: center;
              gap: 10px;
            ">
              <span style="
                padding: 4px 8px;
                border-radius: 4px;
                font-size: 0.8em;
                font-weight: normal;
                background: ${result.status === 'success' ? '#d4edda' : '#f8d7da'};
                color: ${result.status === 'success' ? '#155724' : '#721c24'};
              ">${result.status === 'success' ? '✓ 成功' : '✗ 失败'}</span>
              ${index + 1}. ${result.title}
            </h3>
            <a href="${result.url}" target="_blank" style="
              color: #1a73e8;
              text-decoration: none;
              font-size: 0.9em;
              word-break: break-all;
            ">${result.url}</a>
          </div>
          
          ${result.status === 'failed' ? `
            <div style="
              padding: 12px;
              background: #f8d7da;
              border: 1px solid #f5c6cb;
              border-radius: 6px;
              color: #721c24;
            ">
              <strong>分析失败:</strong> ${result.error}
            </div>
          ` : `
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
              <div>
                <h4 style="margin: 0 0 8px 0; color: #333; font-size: 1em;">内容信息</h4>
                <div style="font-size: 0.9em; line-height: 1.5;">
                  <p><strong>标题:</strong> ${result.analysis.content.title}</p>
                  <p><strong>字数:</strong> ${result.analysis.content.wordCount}</p>
                  <p><strong>描述:</strong> ${result.analysis.content.description || '无'}</p>
                  <p><strong>内容摘要:</strong></p>
                  <div style="
                    background: #f8f9fa;
                    padding: 10px;
                    border-radius: 6px;
                    border-left: 4px solid #d3baf8;
                    font-style: italic;
                    max-height: 100px;
                    overflow-y: auto;
                  ">${result.analysis.content.content.substring(0, 300)}${result.analysis.content.content.length > 300 ? '...' : ''}</div>
                </div>
              </div>
              
              <div>
                <h4 style="margin: 0 0 8px 0; color: #333; font-size: 1em;">AI分析</h4>
                <div style="font-size: 0.9em; line-height: 1.5;">
                  <p><strong>摘要:</strong></p>
                  <div style="
                    background: #e8f4fd;
                    padding: 10px;
                    border-radius: 6px;
                    border-left: 4px solid #1a73e8;
                    margin-bottom: 12px;
                  ">${result.analysis.aiInsights.summary}</div>
                  
                  <p><strong>学术价值:</strong> 
                    <span style="
                      padding: 2px 8px;
                      border-radius: 12px;
                      font-size: 0.8em;
                      background: ${(result.analysis.aiInsights.academicValue || result.analysis.aiInsights.academicRelevance) === 'high' ? '#d4edda' : 
                                    (result.analysis.aiInsights.academicValue || result.analysis.aiInsights.academicRelevance) === 'medium' ? '#fff3cd' : '#f8d7da'};
                      color: ${(result.analysis.aiInsights.academicValue || result.analysis.aiInsights.academicRelevance) === 'high' ? '#155724' : 
                                (result.analysis.aiInsights.academicValue || result.analysis.aiInsights.academicRelevance) === 'medium' ? '#856404' : '#721c24'};
                    ">${(result.analysis.aiInsights.academicValue || result.analysis.aiInsights.academicRelevance) === 'high' ? '高' : 
                          (result.analysis.aiInsights.academicValue || result.analysis.aiInsights.academicRelevance) === 'medium' ? '中' : '低'}</span>
                  </p>
                  
                  <p><strong>情感倾向:</strong> 
                    <span style="
                      padding: 2px 8px;
                      border-radius: 12px;
                      font-size: 0.8em;
                      background: ${result.analysis.aiInsights.sentiment === 'positive' ? '#d4edda' : 
                                    result.analysis.aiInsights.sentiment === 'negative' ? '#f8d7da' : '#e2e3e5'};
                      color: ${result.analysis.aiInsights.sentiment === 'positive' ? '#155724' : 
                                result.analysis.aiInsights.sentiment === 'negative' ? '#721c24' : '#383d41'};
                    ">${result.analysis.aiInsights.sentiment === 'positive' ? '积极' : 
                          result.analysis.aiInsights.sentiment === 'negative' ? '消极' : '中性'}</span>
                  </p>
                  
                  ${result.analysis.aiInsights.topics.length > 0 ? `
                    <p><strong>主要主题:</strong></p>
                    <div style="display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px;">
                      ${result.analysis.aiInsights.topics.slice(0, 3).map(topic => `
                        <span style="
                          padding: 4px 8px;
                          background: #e8f4fd;
                          color: #1a73e8;
                          border-radius: 12px;
                          font-size: 0.8em;
                        ">${topic.topic}</span>
                      `).join('')}
                    </div>
                  ` : ''}
                  
                  ${(result.analysis.aiInsights.keyInsights && result.analysis.aiInsights.keyInsights.length > 0) ? `
                    <p><strong>关键洞察:</strong></p>
                    <ul style="margin: 8px 0; padding-left: 20px;">
                      ${result.analysis.aiInsights.keyInsights.map(insight => `<li>${insight}</li>`).join('')}
                    </ul>
                  ` : ''}
                  
                  ${result.analysis.aiInsights.recommendations && result.analysis.aiInsights.recommendations.length > 0 ? `
                    <p><strong>建议:</strong></p>
                    <ul style="margin: 8px 0; padding-left: 20px;">
                      ${result.analysis.aiInsights.recommendations.map(rec => `<li>${rec}</li>`).join('')}
                    </ul>
                  ` : ''}
                  
                  ${result.analysis.aiInsights.researchDirection ? `
                    <p><strong>研究方向:</strong> ${result.analysis.aiInsights.researchDirection}</p>
                  ` : ''}
                  
                  ${result.analysis.aiInsights.methodology ? `
                    <p><strong>研究方法:</strong> ${result.analysis.aiInsights.methodology}</p>
                  ` : ''}
                  
                  ${result.analysis.aiInsights.aiSource ? `
                    <div style="
                      margin-top: 12px;
                      padding: 6px 10px;
                      background: #e8f4fd;
                      border-radius: 4px;
                      font-size: 0.8em;
                      color: #1a73e8;
                    ">
                      ✨ AI分析来源: ${result.analysis.aiInsights.aiSource === 'openai_api' ? 'GPT-4.1 API' : 
                                     result.analysis.aiInsights.aiSource === 'openai_text' ? 'GPT-4.1 (文本模式)' : '本地分析'}
                    </div>
                  ` : ''}
                </div>
              </div>
            </div>
            
            ${result.analysis.aiInsights.keywords.length > 0 ? `
              <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #e0e0e0;">
                <h4 style="margin: 0 0 8px 0; color: #333; font-size: 1em;">关键词</h4>
                <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                  ${result.analysis.aiInsights.keywords.slice(0, 8).map(kw => `
                    <span style="
                      padding: 4px 10px;
                      background: #f1f3f4;
                      color: #5f6368;
                      border-radius: 16px;
                      font-size: 0.85em;
                      display: flex;
                      align-items: center;
                      gap: 4px;
                    ">
                      ${kw.word}
                      <span style="
                        background: #d3baf8;
                        color: black;
                        padding: 2px 6px;
                        border-radius: 10px;
                        font-size: 0.8em;
                      ">${kw.count}</span>
                    </span>
                  `).join('')}
                </div>
              </div>
            ` : ''}
          `}
        </div>
      `).join('')}
    </div>
  `;

  analysisWindow.innerHTML = content;
  document.body.appendChild(overlay);
  document.body.appendChild(analysisWindow);

  // 应用主题
  const currentTheme = localStorage.getItem('theme') || 'light';
  applyThemeToElement(analysisWindow, currentTheme);

  // 添加按钮事件
  document.getElementById('close-analysis').onclick = function() {
    overlay.remove();
    analysisWindow.remove();
  };

  document.getElementById('export-analysis-results').onclick = function() {
    exportAnalysisResults(results);
  };

  // 点击遮罩层关闭
  overlay.onclick = function() {
    overlay.remove();
    analysisWindow.remove();
  };

  // 按钮悬停效果
  const buttons = analysisWindow.querySelectorAll('button');
  buttons.forEach(button => {
    button.onmouseover = function() {
      this.style.backgroundColor = '#e1ceff';
    };
    button.onmouseout = function() {
      this.style.backgroundColor = '#d3baf8';
    };
  });
}

// 导出分析结果
function exportAnalysisResults(results) {
  const exportData = results.map((result, index) => {
    const base = {
      序号: index + 1,
      标题: result.title,
      链接: result.url,
      状态: result.status === 'success' ? '成功' : '失败',
      时间戳: new Date(result.timestamp).toLocaleString()
    };

    if (result.status === 'success') {
      return {
        ...base,
        内容字数: result.analysis.content.wordCount,
        描述: result.analysis.content.description,
        AI摘要: result.analysis.aiInsights.summary,
        学术价值: result.analysis.aiInsights.academicValue || result.analysis.aiInsights.academicRelevance,
        情感倾向: result.analysis.aiInsights.sentiment,
        主要主题: result.analysis.aiInsights.topics.map(t => typeof t === 'object' ? t.topic : t).join(', '),
        关键洞察: result.analysis.aiInsights.keyInsights ? result.analysis.aiInsights.keyInsights.join('; ') : '',
        建议: result.analysis.aiInsights.recommendations ? result.analysis.aiInsights.recommendations.join('; ') : '',
        研究方向: result.analysis.aiInsights.researchDirection || '',
        研究方法: result.analysis.aiInsights.methodology || '',
        关键词: result.analysis.aiInsights.keywords ? result.analysis.aiInsights.keywords.slice(0, 5).map(k => typeof k === 'object' ? k.word : k).join(', ') : '',
        AI来源: result.analysis.aiInsights.aiSource || 'unknown'
      };
    } else {
      return {
        ...base,
        错误信息: result.error
      };
    }
  });

  // 转换为CSV格式
  const csvContent = convertToCSV(exportData);
  downloadFile(csvContent, `link_analysis_${new Date().getTime()}.csv`, 'text/csv;charset=utf-8');
  
  showToast('分析结果已导出');
}

// 转换为CSV格式
function convertToCSV(data) {
  if (!data || data.length === 0) return '';
  
  const headers = Object.keys(data[0]);
  const csvRows = [];
  
  // 添加BOM以支持中文
  csvRows.push('\uFEFF');
  
  // 添加标题行
  csvRows.push(headers.map(header => `"${header}"`).join(','));
  
  // 添加数据行
  data.forEach(row => {
    const values = headers.map(header => {
      const value = row[header] || '';
      return `"${String(value).replace(/"/g, '""')}"`;
    });
    csvRows.push(values.join(','));
  });
  
  return csvRows.join('\n');
}

// 通用文件下载函数
function downloadFile(content, fileName, mimeType) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
