// popup.js

const casState = {
  majors: new Map(),
  minors: new Map(),
  selections: [],
  excludedJournals: new Set(), // 新增：排除的期刊列表
  loaded: false,
};

document.addEventListener('DOMContentLoaded', () => {
  // 初始化自定义弹窗
  initCustomAlert();
  initCustomConfirm();
  initCustomPrompt();

  const dropdown = document.getElementById('journal-dropdown');
  const dropdownButton = dropdown.querySelector('.dropdown-button');
  const casDropdown = document.getElementById('cas-dropdown');
  const casDropdownButton = casDropdown.querySelector('.dropdown-button');
  const addCategoryButton = document.getElementById('add-category-button');
  const exportCategoryButton = document.getElementById('export-category-button'); // 新增
  const importCategoryButton = document.getElementById('import-category-button'); // 新增
  const modal = document.getElementById('add-category-modal');
  const closeModal = document.getElementById('close-modal');
  const saveNewCategoryButton = document.getElementById('save-new-category');
  const importFileInput = document.getElementById('import-file-input'); // 新增
  const journalSelectionCompleteButton = document.getElementById('journal-selection-complete'); // 新增
  const casSelectionCompleteButton = document.getElementById('cas-selection-complete'); // 新增
  const casAddMajorButton = document.getElementById('cas-add-major');
  const casAddMinorButton = document.getElementById('cas-add-minor');
  const casSelectedList = document.getElementById('cas-selected-list');
  const casSaveToCategoryButton = document.getElementById('cas-save-to-category');

  const journalInit = initializeJournalSources().then(() => {
    renderCategories();
  });

  const casInit = initializeCasFilters();

  Promise.all([journalInit, casInit]).then(() => {
    loadPreferences();
  });

  // 打开/关闭自定义下拉框，并切换按钮文本
  dropdownButton.addEventListener('click', (event) => {
    event.stopPropagation();
    const isActive = dropdown.classList.toggle('active');
    if (isActive) {
      dropdownButton.textContent = '请选择自定义分类（点击收回）';
    } else {
      dropdownButton.textContent = '请选择自定义分类（点击展开）';
    }
  });

  // 打开/关闭新锐分区下拉框，并切换按钮文本
  casDropdownButton.addEventListener('click', (event) => {
    event.stopPropagation();
    const isActive = casDropdown.classList.toggle('active');
    if (isActive) {
      casDropdownButton.textContent = '请选择新锐分区（点击收回）';
    } else {
      casDropdownButton.textContent = '请选择新锐分区（点击展开）';
    }
  });

  // 点击下拉框外部时关闭
  document.addEventListener('click', (event) => {
    if (!dropdown.contains(event.target)) {
      dropdown.classList.remove('active');
      dropdownButton.textContent = '请选择自定义分类（点击展开）';
    }
    if (!casDropdown.contains(event.target)) {
      casDropdown.classList.remove('active');
      casDropdownButton.textContent = '请选择新锐分区（点击展开）';
    }
  });

  // 打开添加类别的模态框
  addCategoryButton.addEventListener('click', () => {
    modal.style.display = 'block';
  });

  // 打开导出功能
  exportCategoryButton.addEventListener('click', () => {
    exportAllJournalRanges();
  });

  // 选择完毕按钮事件
  journalSelectionCompleteButton.addEventListener('click', () => {
    dropdown.classList.remove('active');
    dropdownButton.textContent = '请选择自定义分类（点击展开）';
  });

  // 新锐分区选择完毕按钮事件
  casSelectionCompleteButton.addEventListener('click', () => {
    casDropdown.classList.remove('active');
    casDropdownButton.textContent = '请选择新锐分区（点击展开）';
  });

  // 新增：打开导入功能
  importCategoryButton.addEventListener('click', () => {
    importFileInput.click();
  });

  // 处理文件导入
  importFileInput.addEventListener('change', (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = function(e) {
        try {
          const importedData = JSON.parse(e.target.result);
          if (validateImportedData(importedData)) {
            importJournalRanges(importedData);
          } else {
            showCustomAlert('导入的JSON格式不正确。请确保文件符合标准格式。');
          }
        } catch (error) {
          console.error('JSON解析错误:', error);
          showCustomAlert('无法解析JSON文件。请检查文件格式。');
        }
      };
      reader.readAsText(file);
    }
    // 重置文件输入
    event.target.value = '';
  });


  // 关闭模态框
  closeModal.addEventListener('click', () => {
    modal.style.display = 'none';
  });

  // 在点击模态框外部时关闭
  window.addEventListener('click', (event) => {
    if (event.target == modal) {
      modal.style.display = 'none';
    }
  });

  // 保存新类别
  saveNewCategoryButton.addEventListener('click', () => {
    const categoryName = document.getElementById('new-category-name').value.trim();
    const journalsText = document.getElementById('new-category-journals').value.trim();

    if (!categoryName) {
      showCustomAlert('类别名称不能为空。');
      return;
    }

    if (!journalsText) {
      showCustomAlert('期刊名称不能为空。');
      return;
    }

    const journals = journalsText.split('\n').map(j => j.trim()).filter(j => j);

    if (journals.length === 0) {
      showCustomAlert('请至少输入一个期刊名称。');
      return;
    }

    addNewCategory(categoryName, journals).then(() => {
      modal.style.display = 'none';
      renderCategories();
      clearModalInputs();
    }).catch(err => {
      console.error('添加新类别时出错:', err);
      showCustomAlert('添加新类别失败，请重试。');
    });
  });

  const generateBtn = document.getElementById('generate-btn');
  const searchBtn = document.getElementById('search-btn');

  generateBtn.addEventListener('click', () => {
    generateAndCopyLink();
    savePreferences();
  });

  searchBtn.addEventListener('click', () => {
    directSearch();
    savePreferences();
  });

  // 使用事件委托来处理删除按钮的点击
  document.getElementById('dropdown-content').addEventListener('click', (e) => {
    if (e.target.classList.contains('delete-button')) {
      const category = e.target.getAttribute('data-category');
      deleteCategory(category);
    }
  });

  if (casAddMajorButton) {
    casAddMajorButton.addEventListener('click', handleAddCasMajorSelection);
  }
  if (casAddMinorButton) {
    casAddMinorButton.addEventListener('click', handleAddCasMinorSelection);
  }
  if (casSelectedList) {
    casSelectedList.addEventListener('click', handleCasSelectionListClick);
  }
  if (casSaveToCategoryButton) {
    casSaveToCategoryButton.addEventListener('click', handleSaveCasSelectionToCategory);
  }

  // Theme toggle functionality
  initTheme();
  document.getElementById('theme-toggle').addEventListener('click', toggleTheme);

  // 操作符按钮与下拉处理
  const addTermButton = document.getElementById('add-term-button');
  const dropdownIcon = document.getElementById('operator-dropdown-icon');
  const operatorDropdown = document.getElementById('operator-dropdown');
  const operatorOptions = document.querySelectorAll('.operator-option');
  
  // 当前选中的操作符
  let currentOperator = 'AND';
  
  // 点击下拉图标切换显示/隐藏
  dropdownIcon.addEventListener('click', (e) => {
    e.stopPropagation();
    operatorDropdown.classList.toggle('visible');
  });
  
  // 点击任意其他位置隐藏下拉
  document.addEventListener('click', () => {
    operatorDropdown.classList.remove('visible');
  });
  
  // 抽取添加搜索项的通用函数
  function addSearchTerm() {
    const operator = currentOperator;
    const field = document.getElementById('field-select').value;
    const value = document.getElementById('field-value').value.trim();
    
    if (!value) {
      showCustomAlert('请输入检索词');
      return;
    }
    
    // 构造基本查询片段（包装括号和引号）
    let clause = '';
    switch (field) {
      case 'author':
        clause = `(author:"${value}")`;
        break;
      case 'intitle':
        clause = `(intitle:"${value}")`;
        break;
      case 'source':
        clause = `(source:"${value}")`;
        break;
      default:
        clause = `("${value}")`;
    }
    
    // 根据操作符拼接
    const qBox = document.getElementById('query-box');
    const current = qBox.value.trim();
    let newQuery = '';
    if (!current) {
      newQuery = (operator === 'NOT') ? `-${clause}` : clause;
    } else {
      if (operator === 'AND') newQuery = `${current} ${clause}`;
      else if (operator === 'OR') newQuery = `${current} OR ${clause}`;
      else if (operator === 'NOT') newQuery = `${current} -${clause}`;
      else newQuery = `${current} ${clause}`;
    }
    
    qBox.value = newQuery;
    // 清空输入框
    document.getElementById('field-value').value = '';
  }
  
  // 选择操作符
  operatorOptions.forEach(option => {
    option.addEventListener('click', (e) => {
      e.stopPropagation();
      currentOperator = option.getAttribute('data-value');
      addTermButton.textContent = currentOperator;
      operatorDropdown.classList.remove('visible');
      
      // 选择后立即执行一次添加操作
      addSearchTerm();
    });
  });
  
  // 点击添加按钮
  addTermButton.addEventListener('click', () => {
    addSearchTerm();
  });

  // 添加清除搜索内容按钮事件
  const clearQueryBtn = document.getElementById('clear-query');
  clearQueryBtn.addEventListener('click', () => {
    document.getElementById('query-box').value = '';
  });

  // 添加字段选择器变化事件，动态更新输入框占位符
  const fieldSelect = document.getElementById('field-select');
  const fieldValue = document.getElementById('field-value');

  fieldSelect.addEventListener('change', () => {
    const selectedField = fieldSelect.value;
    switch (selectedField) {
      case 'author':
        fieldValue.placeholder = '请输入作者姓名';
        break;
      case 'intitle':
        fieldValue.placeholder = '请输入标题关键词';
        break;
      case 'source':
        fieldValue.placeholder = '请输入期刊名称';
        break;
      default:
        fieldValue.placeholder = '请输入检索词';
    }
  });
});


// 初始化journalSources，如果不存在则设置默认值
async function initializeJournalSources() {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(['journalSources', 'categoryOrder'], (data) => {
      if (!data.journalSources) {
        const defaultJournalSources = {
          '环境': [
            "Environmental Health Perspectives",
            "Environment International",
            "Journal of Hazardous Materials",
            "Environmental Science & Technology",
            "Nature Sustainability",
            "WATER RESEARCH",
            "Environmental Science and Ecotechnology"
          ],
          '综合': [
            "Nature Communications",
            "Science Advances",
            "Cell Reports",
            "Proceedings of the National Academy of Sciences"
          ],
          '医学': [
            "LANCET",
            "JAMA",
            "NEW ENGLAND JOURNAL OF MEDICINE",
            "NATURE MEDICINE"
          ]
          // 可根据需要添加更多类别和期刊源
        };
        const defaultCategoryOrder = ['环境', '综合', '医学'];
        chrome.storage.local.set({journalSources: defaultJournalSources, categoryOrder: defaultCategoryOrder}, () => {
          resolve();
        });
      } else if (!data.categoryOrder) {
        // 如果已经有journalSources但没有categoryOrder，则初始化
        const categories = Object.keys(data.journalSources);
        chrome.storage.local.set({categoryOrder: categories}, () => {
          resolve();
        });
      } else {
        resolve();
      }
    });
  });
}


// 渲染所有期刊类别
function renderCategories() {
  chrome.storage.local.get(['journalSources', 'categoryOrder'], (data) => {
    const journalSources = data.journalSources || {};
    const categoryOrder = data.categoryOrder || Object.keys(journalSources);
    const dropdownContent = document.getElementById('dropdown-content');

    // 清所有类别，保留"添加类别"、"导入类别"和"导出类别"按钮
    const existingCategories = dropdownContent.querySelectorAll('.category:not(#add-category):not(#import-category):not(#export-category)');
    existingCategories.forEach(cat => cat.remove());

    // 遍历所有类别并按照categoryOrder排序
    categoryOrder.forEach(category => {
      if (journalSources.hasOwnProperty(category)) {
        const journals = journalSources[category];

        const categoryDiv = document.createElement('div');
        categoryDiv.className = 'category';
        categoryDiv.setAttribute('data-category', category);
        categoryDiv.setAttribute('draggable', 'true'); // 使其可拖动

        const categoryHeader = document.createElement('div');
        categoryHeader.className = 'category-header';
        categoryHeader.style.width = '100%';

        const categoryLeft = document.createElement('div');
        categoryLeft.className = 'category-left';

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.className = 'category-checkbox';
        checkbox.id = `${category}-checkbox`;
        checkbox.setAttribute('data-category', category);

        const label = document.createElement('label');
        label.htmlFor = `${category}-checkbox`;
        label.textContent = category;

        categoryLeft.appendChild(checkbox);
        categoryLeft.appendChild(label);

        const categoryRight = document.createElement('div');
        categoryRight.className = 'category-right';

        const infoSpan = document.createElement('span');
        infoSpan.className = 'category-info';
        infoSpan.setAttribute('data-category', category);
        infoSpan.textContent = '信息';

        const copyButton = document.createElement('button');
        copyButton.className = 'copy-button';
        copyButton.setAttribute('data-category', category);
        copyButton.textContent = '复制';

        const deleteButton = document.createElement('button');
        deleteButton.className = 'delete-button';
        deleteButton.setAttribute('data-category', category);
        deleteButton.textContent = '删除';

        // 添加拖动手柄
        const dragHandle = document.createElement('span');
        dragHandle.className = 'drag-handle';
        dragHandle.innerHTML = '&#9776;'; // 使用汉堡菜单图标表示拖动

        categoryRight.appendChild(infoSpan);
        categoryRight.appendChild(copyButton);
        categoryRight.appendChild(deleteButton);
        categoryRight.appendChild(dragHandle); // 添加到右侧

        categoryHeader.appendChild(categoryLeft);
        categoryHeader.appendChild(categoryRight);

        categoryDiv.appendChild(categoryHeader);

        const journalsDiv = document.createElement('div');
        journalsDiv.className = 'journals';
        journalsDiv.id = `journals-${category}`;

        journals.forEach(journal => {
          const journalDiv = document.createElement('div');
          journalDiv.className = 'journal-item'; // 修改类名以便样式区分

          // 创建可编辑的文本输入框
          const journalInput = document.createElement('input');
          journalInput.type = 'text';
          journalInput.className = 'journal-input';
          journalInput.value = journal;
          journalInput.setAttribute('data-original', journal);

          // 创建删除按钮
          const deleteJournalBtn = document.createElement('button');
          deleteJournalBtn.className = 'delete-journal-btn';
          deleteJournalBtn.innerHTML = '×';
          deleteJournalBtn.title = '删除期刊';

          // 添加保存事件
          journalInput.addEventListener('change', (e) => {
            const newValue = e.target.value.trim();
            const originalValue = e.target.getAttribute('data-original');
            if (newValue !== originalValue) {
              updateJournalName(category, originalValue, newValue);
            }
          });

          // 添加删除事件
          deleteJournalBtn.addEventListener('click', () => {
            showCustomConfirm('确定要删除这个期刊吗？', (result) => {
              if (result) {
                removeJournal(category, journal);
                journalDiv.remove();
              }
            });
          });

          journalDiv.appendChild(journalInput);
          journalDiv.appendChild(deleteJournalBtn);
          journalsDiv.appendChild(journalDiv);
        });

        // 添加新期刊的输入框
        const addJournalDiv = document.createElement('div');
        addJournalDiv.className = 'add-journal-container';

        const newJournalInput = document.createElement('input');
        newJournalInput.type = 'text';
        newJournalInput.className = 'new-journal-input';
        newJournalInput.placeholder = '添加新期刊...';

        const addJournalBtn = document.createElement('button');
        addJournalBtn.className = 'add-journal-btn';
        addJournalBtn.textContent = '+';
        addJournalBtn.title = '添加期刊';

        addJournalBtn.addEventListener('click', () => {
          const newJournal = newJournalInput.value.trim();
          if (newJournal) {
            addJournalToCategory(category, newJournal);
            newJournalInput.value = '';
          }
        });

        addJournalDiv.appendChild(newJournalInput);
        addJournalDiv.appendChild(addJournalBtn);
        journalsDiv.appendChild(addJournalDiv);

        categoryDiv.appendChild(journalsDiv);

        // 添加拖动事件
        addDragAndDropHandlers(categoryDiv);

        // 在添加期刊类别按钮之前插入类别
        const addCategoryElement = document.getElementById('add-category');
        dropdownContent.insertBefore(categoryDiv, addCategoryElement);
      }
    });

    // 渲染完成后重新绑定事件
    bindCategoryEvents();
  });
}


// 绑定类别相关的事件
function bindCategoryEvents() {
  const categoryInfos = document.querySelectorAll('.category-info');
  const copyButtons = document.querySelectorAll('.copy-button');

  // 处理"信息"点击事件
  categoryInfos.forEach(info => {
    info.addEventListener('click', (e) => {
      const category = e.target.getAttribute('data-category');
      const journalsDiv = document.getElementById(`journals-${category}`);
      if (journalsDiv) {
        journalsDiv.classList.toggle('visible');
      }
    });
  });

  // 处理复制按钮事件
  copyButtons.forEach(button => {
    button.addEventListener('click', (e) => {
      e.stopPropagation(); // 防止触发其他事件
      const category = button.getAttribute('data-category');
      copyJournalsByCategory(category);
    });
  });

  // 注意：我们不再在这里绑定删除按钮的事件，因为我们使用了事件委托
}


// 复制指定类别的期刊源名称
function copyJournalsByCategory(category) {
  chrome.storage.local.get(['journalSources'], (data) => {
    const journalSources = data.journalSources || {};
    if (journalSources.hasOwnProperty(category)) {
      const journals = journalSources[category];
      const journalList = journals.join('\n'); // 使用换行符分隔
      navigator.clipboard.writeText(journalList).then(() => {
        showCustomAlert(`已复制【${category}】类别的期刊源！`);
      }).catch(err => {
        console.error('复制失败:', err);
        showCustomAlert(`复制【${category}】类别的期刊源失败，请手动复制。`);
      });
    } else {
      showCustomAlert('未找到指定的期刊类别。');
    }
  });
}

// 删除指定类别
function deleteCategory(category) {
  chrome.storage.local.get(['journalSources', 'categoryOrder'], (data) => {
    let journalSources = data.journalSources || {};
    let categoryOrder = data.categoryOrder || [];

    if (journalSources.hasOwnProperty(category)) {
      delete journalSources[category];
      categoryOrder = categoryOrder.filter(cat => cat !== category);

      chrome.storage.local.set({journalSources: journalSources, categoryOrder: categoryOrder}, () => {
        renderCategories();
      });
    } else {
      console.error('未找到指定的期刊类别:', category);
    }
  });
}

// 生成并复制链接（高级搜索）
function generateAndCopyLink() {
  chrome.storage.local.get(['journalSources'], (data) => {
    const journalSources = data.journalSources || {};
    let query = document.getElementById('query-box').value.trim();
    const categoryCheckboxes = document.querySelectorAll('.category-checkbox:checked');
    const selectedCategories = Array.from(categoryCheckboxes).map(cb => cb.getAttribute('data-category'));
    const startYear = document.getElementById('start-year').value;
    const endYear = document.getElementById('end-year').value;
    const articleType = document.getElementById('article-type').value;
    const resultsPerPage = document.getElementById('results-per-page').value;

    if (!query && selectedCategories.length === 0 && casState.selections.length === 0) {
      showCustomAlert('请填写至少一个搜索条件或选择期刊范围。');
      return;
    }
    if (startYear && endYear && parseInt(startYear) > parseInt(endYear)) {
      showCustomAlert('起始年份不能晚于结束年份。');
      return;
    }
    const journalFilterExpr = buildJournalFilterExpression(selectedCategories, journalSources);
    if (journalFilterExpr) {
      query = query ? `${query} (${journalFilterExpr})` : `(${journalFilterExpr})`;
    }
    let url = 'https://scholar.google.com/scholar?';
    url += `q=${encodeURIComponent(query)}&`;
    if (startYear) url += `as_ylo=${startYear}&`;
    if (endYear) url += `as_yhi=${endYear}&`;
    url += `as_rr=${articleType}&`;
    if (resultsPerPage !== '10') url += `num=${resultsPerPage}`;
    else url = url.endsWith('&') ? url.slice(0, -1) : url;

    navigator.clipboard.writeText(url).then(() => {
      showCustomAlert('链接已生成并复制到剪贴板！');
    }).catch(err => {
      console.error('复制失败:', err);
      showCustomAlert('复制链接失败，请手动复制。');
    });
  });
}

// 直接搜索（高级搜索）
function directSearch() {
  chrome.storage.local.get(['journalSources'], (data) => {
    const journalSources = data.journalSources || {};
    let query = document.getElementById('query-box').value.trim();
    const categoryCheckboxes = document.querySelectorAll('.category-checkbox:checked');
    const selectedCategories = Array.from(categoryCheckboxes).map(cb => cb.getAttribute('data-category'));
    const startYear = document.getElementById('start-year').value;
    const endYear = document.getElementById('end-year').value;
    const articleType = document.getElementById('article-type').value;
    const resultsPerPage = document.getElementById('results-per-page').value;

    if (!query && selectedCategories.length === 0 && casState.selections.length === 0) {
      showCustomAlert('请填写至少一个搜索条件或选择期刊范围。');
      return;
    }
    if (startYear && endYear && parseInt(startYear) > parseInt(endYear)) {
      showCustomAlert('起始年份不能晚于结束年份。');
      return;
    }
    const journalFilterExpr = buildJournalFilterExpression(selectedCategories, journalSources);
    if (journalFilterExpr) {
      query = query ? `${query} (${journalFilterExpr})` : `(${journalFilterExpr})`;
    }
    let url = 'https://scholar.google.com/scholar?';
    url += `q=${encodeURIComponent(query)}&`;
    if (startYear) url += `as_ylo=${startYear}&`;
    if (endYear) url += `as_yhi=${endYear}&`;
    url += `as_rr=${articleType}&`;
    if (resultsPerPage !== '10') url += `num=${resultsPerPage}`;
    else url = url.endsWith('&') ? url.slice(0, -1) : url;
    chrome.tabs.create({ url: url });
  });
}


function buildJournalFilterExpression(selectedCategories, journalSources) {
  const groupExpressions = [];

  selectedCategories.forEach((category) => {
    const journals = Array.isArray(journalSources[category])
      ? journalSources[category].map((j) => j.trim()).filter(Boolean)
      : [];

    if (journals.length === 0) {
      return;
    }

    const expression = journals.map((journal) => `source:"${journal}"`).join(' OR ');
    groupExpressions.push(journals.length > 1 ? `(${expression})` : expression);
  });

  const casJournals = Array.from(getCasSelectedJournals());
  if (casJournals.length > 0) {
    const expression = casJournals.map((journal) => `source:"${journal}"`).join(' OR ');
    groupExpressions.push(casJournals.length > 1 ? `(${expression})` : expression);
  }

  if (groupExpressions.length === 0) {
    return '';
  }

  if (groupExpressions.length === 1) {
    return groupExpressions[0];
  }

  return groupExpressions
    .map((expr) => (expr.startsWith('(') && expr.endsWith(')') ? expr : `(${expr})`))
    .join(' OR ');
}


function getCasSelectedJournals(options = {}) {
  const { ignoreExclusions = false } = options;
  const result = new Set();

  casState.selections.forEach((selection) => {
    const collection = selection.type === 'major'
      ? casState.majors.get(selection.name)
      : casState.minors.get(selection.name);

    if (!collection) {
      return;
    }

    selection.quartiles.forEach((quartile) => {
      const journals = collection[quartile];
      if (journals && journals.size > 0) {
        journals.forEach((journal) => {
          // 只添加未被排除的期刊
          if (ignoreExclusions || !casState.excludedJournals.has(journal)) {
            result.add(journal);
          }
        });
      }
    });
  });

  return result;
}


function pruneExcludedCasJournals() {
  const availableJournals = getCasSelectedJournals({ ignoreExclusions: true });
  casState.excludedJournals = new Set(
    Array.from(casState.excludedJournals).filter((journal) => availableJournals.has(journal))
  );
}


function handleAddCasMajorSelection() {
  const majorSelect = document.getElementById('cas-major-select');
  const selectedMajor = majorSelect.value.trim();
  const quartiles = getCheckedQuartiles('.cas-major-quartile');

  if (!selectedMajor) {
    showCustomAlert('请选择需要筛选的大类。');
    return;
  }

  if (quartiles.length === 0) {
    showCustomAlert('请至少选择一个大类分区。');
    return;
  }

  if (!casState.majors.has(selectedMajor)) {
    showCustomAlert('未找到对应的大类数据，请重新选择。');
    return;
  }

  upsertCasSelection('major', selectedMajor, quartiles);
  clearCasInputsAfterAdd('major');
}


function handleAddCasMinorSelection() {
  const minorInput = document.getElementById('cas-minor-input');
  const selectedMinor = minorInput.value.trim();
  const quartiles = getCheckedQuartiles('.cas-minor-quartile');

  if (!selectedMinor) {
    showCustomAlert('请输入或选择小类名称。');
    return;
  }

  if (!casState.minors.has(selectedMinor)) {
    showCustomAlert('未找到对应的小类，请确保名称与数据一致。');
    return;
  }

  if (quartiles.length === 0) {
    showCustomAlert('请至少选择一个小类分区。');
    return;
  }

  upsertCasSelection('minor', selectedMinor, quartiles);
  clearCasInputsAfterAdd('minor');
}


function upsertCasSelection(type, name, quartiles) {
  const normalizedQuartiles = Array.from(new Set(quartiles.map(Number))).filter((q) => q >= 1 && q <= 4).sort();

  if (normalizedQuartiles.length === 0) {
    return;
  }

  const existing = casState.selections.find((item) => item.type === type && item.name === name);
  if (existing) {
    const merged = new Set([...(existing.quartiles || []), ...normalizedQuartiles]);
    existing.quartiles = Array.from(merged).sort();
  } else {
    casState.selections.push({ type, name, quartiles: normalizedQuartiles });
  }

  renderCasSelections();
  persistCasSelections();
}


function handleCasSelectionListClick(event) {
  const target = event.target;
  if (!target.classList.contains('cas-remove-btn')) {
    return;
  }

  // 阻止事件冒泡，防止触发文档级的点击事件导致下拉框关闭
  event.stopPropagation();

  const index = parseInt(target.getAttribute('data-index'), 10);
  if (Number.isNaN(index)) {
    return;
  }

  removeCasSelection(index);
}


function removeCasSelection(index) {
  if (index < 0 || index >= casState.selections.length) {
    return;
  }

  casState.selections.splice(index, 1);
  pruneExcludedCasJournals();
  renderCasSelections();
  persistCasSelections();
}


function renderCasSelections() {
  const container = document.getElementById('cas-selected-list');
  if (!container) {
    return;
  }

  container.innerHTML = '';

  if (casState.selections.length === 0) {
    const placeholder = document.createElement('div');
    placeholder.className = 'cas-selected-empty';
    placeholder.textContent = '未选择分区条件';
    container.appendChild(placeholder);
    return;
  }

  casState.selections.forEach((selection, index) => {
    const item = document.createElement('div');
    item.className = 'cas-selected-item';
    item.setAttribute('data-type', selection.type);

    const label = document.createElement('span');
    const typeLabel = selection.type === 'major' ? '大类' : '小类';
    label.textContent = `${typeLabel} · ${selection.name} · ${selection.quartiles.map((q) => `${q}区`).join('、')}`;

    const removeBtn = document.createElement('button');
    removeBtn.className = 'cas-remove-btn';
    removeBtn.setAttribute('data-index', String(index));
    removeBtn.setAttribute('aria-label', '移除该分区条件');
    removeBtn.textContent = '×';

    item.appendChild(label);
    item.appendChild(removeBtn);
    container.appendChild(item);
  });

  // 更新期刊筛选列表
  updateCasJournalFilter();
}

// 新增：更新期刊筛选列表
function updateCasJournalFilter() {
  const filterContent = document.getElementById('cas-filter-content');
  const filterCount = document.getElementById('cas-filter-count');

  if (!filterContent || !filterCount) {
    return;
  }

  // 获取所有选中的期刊
  const selectedJournals = Array.from(getCasSelectedJournals());

  // 更新计数
  filterCount.textContent = selectedJournals.length;

  // 清空内容
  filterContent.innerHTML = '';

  if (selectedJournals.length === 0) {
    const emptyDiv = document.createElement('div');
    emptyDiv.className = 'cas-filter-empty';
    emptyDiv.textContent = '未选择期刊';
    filterContent.appendChild(emptyDiv);
    return;
  }

  // 按字母排序期刊
  selectedJournals.sort();

  // 创建期刊列表
  selectedJournals.forEach((journal) => {
    const item = document.createElement('div');
    item.className = 'cas-journal-item';

    const nameSpan = document.createElement('span');
    nameSpan.className = 'cas-journal-name';
    nameSpan.textContent = journal;
    nameSpan.title = journal; // 完整名称的tooltip

    const removeBtn = document.createElement('button');
    removeBtn.className = 'cas-journal-remove';
    removeBtn.textContent = '×';
    removeBtn.title = '移除此期刊';
    removeBtn.addEventListener('click', (event) => {
      event.stopPropagation(); // 阻止事件冒泡
      removeCasJournal(journal);
    });

    item.appendChild(nameSpan);
    item.appendChild(removeBtn);
    filterContent.appendChild(item);
  });
}

// 修改：排除特定期刊
function removeCasJournal(journalName) {
  // 将期刊添加到排除列表
  casState.excludedJournals.add(journalName);

  // 重新渲染筛选列表
  updateCasJournalFilter();

  // 持久化排除列表
  persistCasSelections();
}


function clearCasInputsAfterAdd(type) {
  if (type === 'major') {
    const checkboxes = document.querySelectorAll('.cas-major-quartile');
    checkboxes.forEach((checkbox) => {
      checkbox.checked = false;
    });
  } else if (type === 'minor') {
    const checkboxes = document.querySelectorAll('.cas-minor-quartile');
    checkboxes.forEach((checkbox) => {
      checkbox.checked = false;
    });
    const minorInput = document.getElementById('cas-minor-input');
    if (minorInput) {
      minorInput.value = '';
    }
  }
}


function getCheckedQuartiles(selector) {
  return Array.from(document.querySelectorAll(selector))
    .filter((checkbox) => checkbox.checked)
    .map((checkbox) => Number(checkbox.value))
    .filter((value) => value >= 1 && value <= 4);
}


async function initializeCasFilters() {
  if (casState.loaded) {
    renderCasSelections();
    return;
  }

  try {
    await loadCasCsvData();
    populateCasControls();
    renderCasSelections();
  } catch (error) {
    console.error('初始化新锐分区失败:', error);
    renderCasSelections();
  }
}


async function loadCasCsvData() {
  const csvUrl = chrome.runtime.getURL('/data/XR2026-UTF8.csv');
  const response = await fetch(csvUrl);

  if (!response.ok) {
    throw new Error(`加载新锐分区数据失败: ${response.status}`);
  }

  const csvText = await response.text();
  parseCasCsv(csvText);
  casState.loaded = true;
}


function parseCasCsv(csvText) {
  const lines = csvText.split(/\r?\n/);
  if (lines.length <= 1) {
    return;
  }

  const headers = parseCasCsvLine(lines[0]);

  for (let i = 1; i < lines.length; i += 1) {
    const line = lines[i];
    if (!line || !line.trim()) {
      continue;
    }

    const values = parseCasCsvLine(line);
    const record = {};
    headers.forEach((header, index) => {
      record[header] = values[index] || '';
    });

    const journalName = (record['Journal'] || '').trim();
    if (!journalName) {
      continue;
    }

    const majorName = (record['大类中文名'] || record['大类英文名'] || '').trim();
    const majorQuartiles = normalizeQuartileValues(record['大类新锐分区']);
    if (majorName && majorQuartiles.length > 0) {
      ensureCasEntry(casState.majors, majorName);
      majorQuartiles.forEach((quartile) => {
        casState.majors.get(majorName)[quartile].add(journalName);
      });
    }

    for (let idx = 1; idx <= 6; idx += 1) {
      const minorName = (record[`小类${idx}中文名`] || record[`小类${idx}英文名`] || '').trim();
      if (!minorName) {
        continue;
      }

      const minorQuartiles = normalizeQuartileValues(record[`小类${idx}新锐分区`]);
      if (minorQuartiles.length === 0) {
        continue;
      }

      ensureCasEntry(casState.minors, minorName);
      minorQuartiles.forEach((quartile) => {
        casState.minors.get(minorName)[quartile].add(journalName);
      });
    }
  }
}


function parseCasCsvLine(line) {
  const result = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];

    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i += 1;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }

  result.push(current.trim());

  return result.map((value) => value.replace(/^"|"$/g, '').trim());
}


function ensureCasEntry(collection, name) {
  if (!collection.has(name)) {
    collection.set(name, {
      1: new Set(),
      2: new Set(),
      3: new Set(),
      4: new Set(),
    });
  }
}


function normalizeQuartileValues(rawValue) {
  if (rawValue === undefined || rawValue === null) {
    return [];
  }

  const matches = String(rawValue).match(/[1-4]/g);
  if (!matches) {
    return [];
  }

  return Array.from(new Set(matches.map((item) => Number(item))));
}


function populateCasControls() {
  const majorSelect = document.getElementById('cas-major-select');
  const minorOptions = document.getElementById('cas-minor-options');

  if (!majorSelect || !minorOptions) {
    return;
  }

  const collator = new Intl.Collator('zh-Hans', { sensitivity: 'base' });

  const majors = Array.from(casState.majors.keys()).sort((a, b) => collator.compare(a, b));
  majorSelect.innerHTML = '<option value="">选择大类</option>';
  majors.forEach((major) => {
    const option = document.createElement('option');
    option.value = major;
    option.textContent = major;
    majorSelect.appendChild(option);
  });

  minorOptions.innerHTML = '';
  const minors = Array.from(casState.minors.keys()).sort((a, b) => collator.compare(a, b));
  minors.forEach((minor) => {
    const option = document.createElement('option');
    option.value = minor;
    minorOptions.appendChild(option);
  });
}


function persistCasSelections() {
  chrome.storage.local.set({
    casSelections: casState.selections.map((selection) => ({
      type: selection.type,
      name: selection.name,
      quartiles: Array.from(new Set(selection.quartiles || [])).sort(),
    })),
  });
}


function restoreCasSelectionsFromStorage(selections) {
  if (!Array.isArray(selections)) {
    casState.selections = [];
    renderCasSelections();
    return;
  }

  // 加载时重置排除期刊，仅在当前会话内生效
  casState.excludedJournals = new Set();

  casState.selections = selections
    .map((selection) => ({
      type: selection.type === 'minor' ? 'minor' : 'major',
      name: typeof selection.name === 'string' ? selection.name.trim() : '',
      quartiles: Array.isArray(selection.quartiles)
        ? Array.from(new Set(selection.quartiles.map((q) => Number(q)).filter((q) => q >= 1 && q <= 4))).sort()
        : [],
    }))
    .filter((selection) => {
      if (!selection.name || selection.quartiles.length === 0) {
        return false;
      }
      return selection.type === 'major'
        ? casState.majors.has(selection.name)
        : casState.minors.has(selection.name);
    });

  renderCasSelections();
}


// 添加新类别到journalSources
function addNewCategory(categoryName, journals) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(['journalSources', 'categoryOrder'], (data) => {
      let journalSources = data.journalSources || {};
      let categoryOrder = data.categoryOrder || [];

      if (journalSources.hasOwnProperty(categoryName)) {
        showCustomAlert('该类别名称已存在，请选择其他名称。');
        reject('类别名称已存在');
        return;
      }

      journalSources[categoryName] = journals;
      categoryOrder.push(categoryName); // 将新类别添加到顺序末尾

      chrome.storage.local.set({journalSources: journalSources, categoryOrder: categoryOrder}, () => {
        resolve();
      });
    });
  });
}

// 清除模态框输入
function clearModalInputs() {
  document.getElementById('new-category-name').value = '';
  document.getElementById('new-category-journals').value = '';
}

// 保存用户选择到chrome.storage
function savePreferences() {
  chrome.storage.local.get(['journalSources', 'categoryOrder'], (data) => {
    const journalSources = data.journalSources || {};
    const categoryOrder = data.categoryOrder || [];
    const query = document.getElementById('query-box').value.trim();
    const categoryCheckboxes = document.querySelectorAll('.category-checkbox:checked');
    const selectedCategories = Array.from(categoryCheckboxes).map(cb => cb.getAttribute('data-category'));
    const startYear = document.getElementById('start-year').value;
    const endYear = document.getElementById('end-year').value;
    const articleType = document.getElementById('article-type').value; // 获取文章类型
    const resultsPerPage = document.getElementById('results-per-page').value; // 获取每页结果数

    chrome.storage.local.set({
      searchQuery: query,
      selectedCategories: selectedCategories,
      startYear: startYear,
      endYear: endYear,
      articleType: articleType, // 保存文章类型
      resultsPerPage: resultsPerPage, // 保存每页结果数
      casSelections: casState.selections.map((selection) => ({
        type: selection.type,
        name: selection.name,
        quartiles: Array.from(new Set(selection.quartiles || [])).sort(),
      })),
    });
  });
}

// 加载用户选择从chrome.storage
function loadPreferences() {
  chrome.storage.local.get(['searchQuery', 'selectedCategories', 'startYear', 'endYear', 'articleType', 'resultsPerPage', 'casSelections'], (data) => {
    if (data.casSelections) {
      restoreCasSelectionsFromStorage(data.casSelections);
    } else {
      restoreCasSelectionsFromStorage([]);
    }
    if (data.searchQuery) {
      document.getElementById('query-box').value = data.searchQuery;
    }
    if (data.selectedCategories) {
      data.selectedCategories.forEach(category => {
        const checkbox = document.querySelector(`.category-checkbox[data-category="${category}"]`);
        if (checkbox) {
          checkbox.checked = true;
        }
      });
    }
    if (data.startYear) {
      document.getElementById('start-year').value = data.startYear;
    }
    if (data.endYear) {
      document.getElementById('end-year').value = data.endYear;
    }
    if (data.articleType) {
      document.getElementById('article-type').value = data.articleType; // 加载文章类型
    }
    if (data.resultsPerPage) {
      document.getElementById('results-per-page').value = data.resultsPerPage; // 加载每页结果数
    }
  });
}

// 添加拖动事件处理程序
function addDragAndDropHandlers(categoryDiv) {
  categoryDiv.addEventListener('dragstart', handleDragStart);
  categoryDiv.addEventListener('dragover', handleDragOver);
  categoryDiv.addEventListener('drop', handleDrop);
  categoryDiv.addEventListener('dragend', handleDragEnd);
}


let draggedElement = null;

function handleDragStart(e) {
  draggedElement = this;
  this.classList.add('dragging');
  e.dataTransfer.effectAllowed = 'move';
}

function handleDragOver(e) {
  e.preventDefault();
  e.dataTransfer.dropEffect = 'move';
  const target = e.currentTarget;
  if (target && target !== draggedElement && target.classList.contains('category')) {
    const bounding = target.getBoundingClientRect();
    const offset = bounding.y + (bounding.height / 2);
    if (e.clientY - bounding.y < bounding.height / 2) {
      target.parentNode.insertBefore(draggedElement, target);
    } else {
      target.parentNode.insertBefore(draggedElement, target.nextSibling);
    }
  }
}

function handleDrop(e) {
  e.stopPropagation();
  return false;
}

function handleDragEnd(e) {
  this.classList.remove('dragging');
  updateCategoryOrder();
}


// 更新类别顺序到storage
function updateCategoryOrder() {
  const categories = document.querySelectorAll('.dropdown-content .category:not(#add-category):not(#import-category):not(#export-category)');
  const newOrder = Array.from(categories).map(cat => cat.getAttribute('data-category'));

  chrome.storage.local.get(['categoryOrder'], (data) => {
    chrome.storage.local.set({categoryOrder: newOrder}, () => {
      console.log('类别顺序已更新。');
    });
  });
}

// 新增：导入期刊范围的函数
function importJournalRanges(importedData) {
  chrome.storage.local.get(['journalSources', 'categoryOrder'], (data) => {
    let journalSources = data.journalSources || {};
    let categoryOrder = data.categoryOrder || [];

    // 合并导入的数据
    for (const [category, journals] of Object.entries(importedData)) {
      if (journalSources.hasOwnProperty(category)) {
        // 如果类别已存在，合并期刊并去重
        const existingJournals = new Set(journalSources[category]);
        journals.forEach(journal => existingJournals.add(journal));
        journalSources[category] = Array.from(existingJournals);
      } else {
        // 如果类别不存在，添加新类别
        journalSources[category] = journals;
        categoryOrder.push(category);
      }
    }

    chrome.storage.local.set({journalSources: journalSources, categoryOrder: categoryOrder}, () => {
      showCustomAlert('期刊范围已成功导入，并与现有类别合并。');
      renderCategories();
    });
  });
}


// 验证导入的数据格式
function validateImportedData(data) {
  if (typeof data !== 'object' || Array.isArray(data) || data === null) {
    return false;
  }
  for (const [category, journals] of Object.entries(data)) {
    if (typeof category !== 'string') {
      return false;
    }
    if (!Array.isArray(journals)) {
      return false;
    }
    for (const journal of journals) {
      if (typeof journal !== 'string') {
        return false;
      }
    }
  }
  return true;
}

// 新增：导出全部期刊范围的函数
function exportAllJournalRanges() {
  chrome.storage.local.get(['journalSources', 'categoryOrder'], (data) => {
    const journalSources = data.journalSources || {};
    const categoryOrder = data.categoryOrder || Object.keys(journalSources);
    const exportData = {};
    categoryOrder.forEach(category => {
      exportData[category] = journalSources[category];
    });
    const jsonStr = JSON.stringify(exportData, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = 'journal_ranges_backup.json';
    a.click();
    URL.revokeObjectURL(url);
  });
}

// 假设您有一个函数或变量存储期刊范围选项
const journalScopes = ['范围1', '范围2', '范围3']; // 根据实际情况修改

// 在 popup.js 中，将期刊范围选项发送到 content.js
function sendJournalScopes() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, { action: 'updateScopes', scopes: journalScopes });
  });
}

// 调用发送函数，例如在初始化时
sendJournalScopes();

// 添加新的辅助函数来处理期刊的更新、删除和添加
function updateJournalName(category, oldName, newName) {
  chrome.storage.local.get(['journalSources'], (data) => {
    const journalSources = data.journalSources;
    const index = journalSources[category].indexOf(oldName);
    if (index !== -1) {
      journalSources[category][index] = newName;
      chrome.storage.local.set({journalSources}, () => {
        console.log('期刊名称已更新');
      });
    }
  });
}

function removeJournal(category, journalName) {
  chrome.storage.local.get(['journalSources'], (data) => {
    const journalSources = data.journalSources;
    journalSources[category] = journalSources[category].filter(j => j !== journalName);
    chrome.storage.local.set({journalSources}, () => {
      console.log('期刊已删除');
    });
  });
}

function addJournalToCategory(category, newJournal) {
  chrome.storage.local.get(['journalSources'], (data) => {
    const journalSources = data.journalSources;
    if (!journalSources[category].includes(newJournal)) {
      journalSources[category].push(newJournal);
      chrome.storage.local.set({journalSources}, () => {
        renderCategories(); // 重新渲染以显示新添加的期刊
      });
    } else {
      showCustomAlert('该期刊已存在于此类别中');
    }
  });
}

// 初始化自定义提示弹窗
function initCustomAlert() {
  const customAlert = document.getElementById('custom-alert');
  const confirmBtn = document.getElementById('alert-confirm');
  
  confirmBtn.addEventListener('click', () => {
    customAlert.style.display = 'none';
  });
  
  // 点击弹窗外部区域关闭
  window.addEventListener('click', (event) => {
    if (event.target === customAlert) {
      customAlert.style.display = 'none';
    }
  });
}

// 自定义提示弹窗函数，替代原生alert
function showCustomAlert(message) {
  const customAlert = document.getElementById('custom-alert');
  const alertMessage = document.getElementById('alert-message');
  
  alertMessage.textContent = message;
  customAlert.style.display = 'block';
}

// 初始化自定义确认对话框
function initCustomConfirm() {
  const customConfirm = document.getElementById('custom-confirm');
  const confirmYesBtn = document.getElementById('confirm-yes-btn');
  const confirmNoBtn = document.getElementById('confirm-no-btn');
  
  // 点击弹窗外部区域关闭
  window.addEventListener('click', (event) => {
    if (event.target === customConfirm) {
      customConfirm.style.display = 'none';
      window.confirmCallback = null;
    }
  });
  
  // 点击"取消"按钮
  confirmNoBtn.addEventListener('click', () => {
    customConfirm.style.display = 'none';
    if (window.confirmCallback) {
      window.confirmCallback(false);
      window.confirmCallback = null;
    }
  });
  
  // 点击"确定"按钮
  confirmYesBtn.addEventListener('click', () => {
    customConfirm.style.display = 'none';
    if (window.confirmCallback) {
      window.confirmCallback(true);
      window.confirmCallback = null;
    }
  });
}

// 自定义确认对话框函数，替代原生confirm
function showCustomConfirm(message, callback) {
  const customConfirm = document.getElementById('custom-confirm');
  const confirmMessage = document.getElementById('confirm-message');
  
  confirmMessage.textContent = message;
  customConfirm.style.display = 'block';
  
  // 保存回调函数
  window.confirmCallback = callback;
}

// Theme toggle functionality
function initTheme() {
  const theme = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-theme', theme);
}

function toggleTheme() {
  const currentTheme = document.documentElement.getAttribute('data-theme');
  const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', newTheme);
  localStorage.setItem('theme', newTheme);
}

function handleSaveCasSelectionToCategory() {
  const journals = Array.from(getCasSelectedJournals());

  if (journals.length === 0) {
    showCustomAlert('当前没有可保存的期刊。');
    return;
  }

  showCustomPrompt('请输入要保存的自定义分类名称：', '', (inputValue) => {
    if (inputValue === null) {
      return;
    }

    const categoryName = String(inputValue).trim();
    if (!categoryName) {
      showCustomAlert('分类名称不能为空。');
      return;
    }

    saveCasSelectionToCustomCategory(categoryName, journals);
  });
}

function saveCasSelectionToCustomCategory(categoryName, journals) {
  if (!categoryName || journals.length === 0) {
    return;
  }

  chrome.storage.local.get(['journalSources', 'categoryOrder'], (data) => {
    const journalSources = data.journalSources || {};
    const categoryOrder = Array.isArray(data.categoryOrder) ? [...data.categoryOrder] : [];

    const uniqueJournals = Array.from(new Set(journals));
    uniqueJournals.sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }));

    const persistCategory = () => {
      journalSources[categoryName] = uniqueJournals;
      if (!categoryOrder.includes(categoryName)) {
        categoryOrder.push(categoryName);
      }

      chrome.storage.local.set({ journalSources, categoryOrder }, () => {
        renderCategories();
        showCustomAlert(`已将期刊保存到“${categoryName}”分类。`);
      });
    };

    if (Object.prototype.hasOwnProperty.call(journalSources, categoryName)) {
      showCustomConfirm(`分类“${categoryName}”已存在，是否覆盖原有期刊？`, (confirmed) => {
        if (confirmed) {
          persistCategory();
        }
      });
    } else {
      persistCategory();
    }
  });
}

function initCustomPrompt() {
  const customPrompt = document.getElementById('custom-prompt');
  const promptInput = document.getElementById('prompt-input');
  const promptOkBtn = document.getElementById('prompt-ok-btn');
  const promptCancelBtn = document.getElementById('prompt-cancel-btn');

  if (!customPrompt || !promptInput || !promptOkBtn || !promptCancelBtn) {
    return;
  }

  window.promptCallback = null;

  const closePrompt = (result) => {
    customPrompt.style.display = 'none';
    promptInput.value = '';

    if (typeof window.promptCallback === 'function') {
      const callback = window.promptCallback;
      window.promptCallback = null;
      callback(result);
    }
  };

  promptOkBtn.addEventListener('click', () => {
    closePrompt(promptInput.value);
  });

  promptCancelBtn.addEventListener('click', () => {
    closePrompt(null);
  });

  customPrompt.addEventListener('click', (event) => {
    if (event.target === customPrompt) {
      closePrompt(null);
    }
  });

  promptInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      closePrompt(promptInput.value);
    } else if (event.key === 'Escape') {
      event.preventDefault();
      closePrompt(null);
    }
  });
}

function showCustomPrompt(message, defaultValue = '', callback = null) {
  const customPrompt = document.getElementById('custom-prompt');
  const promptMessage = document.getElementById('prompt-message');
  const promptInput = document.getElementById('prompt-input');

  if (!customPrompt || !promptMessage || !promptInput) {
    if (typeof callback === 'function') {
      callback(null);
    }
    return;
  }

  promptMessage.textContent = message;
  promptInput.value = defaultValue || '';
  customPrompt.style.display = 'block';
  window.promptCallback = typeof callback === 'function' ? callback : null;

  setTimeout(() => {
    promptInput.focus();
    promptInput.select();
  }, 0);
}
