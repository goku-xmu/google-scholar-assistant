import React, { useState, useEffect, useRef } from 'react';
import { Menu, X, ChevronRight, Mail, MapPin, FileText, Users, GraduationCap, Microscope, ArrowRight, Globe, Award, Dna, Activity, FileCheck } from 'lucide-react';

// ----------------------------------------------------------------------
// 🛠️ 数据配置区 (已根据张洁副教授的资料更新)
// ----------------------------------------------------------------------

const SITE_DATA = {
  labName: "系统流行病学与毒理学课题组",
  labNameEn: "System Epidemiology & Toxicology Laboratory",
  piName: "张洁",
  piTitle: "副教授 / 实验教学中心副主任 / 硕导 / 博导",
  school: "厦门大学公共卫生学院",
  
  // 简介 (基于研究领域总结)
  intro: "本课题组聚焦于系统流行病学与毒理学，将暴露组与多组学相结合，深入探索环境因素与疾病的分子机制。我们致力于发现临床诊断标志物，构建早期预测模型，并推动公共卫生应急平台的关键技术建设。",
  
  // PI 详细介绍 (基于教育背景、工作经历、社会任职)
  piBio: [
    "中国科学院大连化学物理研究所硕博连读，加拿大卫生部化学品安全局访问学者，曾任中科院城市环境研究所副研究员。",
    "现任厦门大学公共卫生学院副教授、实验教学中心副主任（主持工作）。入选福建省高层次人才、厦门市双百人才。",
    "担任中国毒理学会呼吸毒理分会青年委员、厦门市预防医学会慢性病预防与控制专业委员会常委等职。主持国家自然科学基金多项、科技部国家重点研发计划骨干、厦门市及福建省多项重点科研项目。"
  ],

  // 研究方向
  researchAreas: [
    {
      title: "系统流行病学和毒理学",
      desc: "基于转录组、宏基因组、代谢组等多组学技术，研究大气污染、环境内分泌干扰物等暴露因素与疾病（如生殖健康、慢性肾病）的关联及分子毒性机制。",
      icon: <Dna size={32} />
    },
    {
      title: "临床诊断标志物发现",
      desc: "通过多组学筛选生物标志物，建立疾病早期预测和高危个体筛选模型，开发体外诊断方法，为个性化医疗和转化医学提供科学支持。",
      icon: <Activity size={32} />
    },
    {
      title: "公共卫生应急平台建设",
      desc: "针对食品、生物及环境复杂样品，研发有害物质的高通量分析技术，提升公共卫生应急响应与检测能力。",
      icon: <Microscope size={32} />
    }
  ],

  // 科研项目列表
  fundings: [
    { type: "National", title: "砷致肝脏糖脂代谢紊乱促发/加重妊娠期糖尿病的机理及干预研究", source: "国家自然科学基金面上项目 (22076157)", role: "主持", fund: "63万元" },
    { type: "National", title: "青春期砷暴露干扰雄性大鼠HPT轴内分泌/代谢通路的生殖毒性研究", source: "国家自然科学基金面上项目 (21677141)", role: "主持", fund: "65万元" },
    { type: "National", title: "大气污染对呼吸和心血管系统健康影响的早期识别技术", source: "科技部国家重点研发计划 (2017YFC0211602)", role: "骨干成员", fund: "2967万元" },
    { type: "National", title: "饮水型砷暴露对幼鼠海马和皮质DNA甲基化/去甲基化过程的影响及干扰机制研究", source: "国家自然科学基金青年项目 (21407143)", role: "主持", fund: "26万元" },
    { type: "Provincial", title: "基于老年纵向队列研究PM2.5组分与慢性肾病的关联及分子机理", source: "福建省自然科学基金面上项目 (2024J01046)", role: "主持", fund: "10万元" },
    { type: "Provincial", title: "乳及乳制品中有机污染物的高通量筛查检测技术研究", source: "厦门市科技计划项目 (3502Z20112017)", role: "主持", fund: "100万元" },
    { type: "Provincial", title: "基于“暴露组-代谢组-精子质量”全关联分析的男性生殖健康研究", source: "厦门大学校长基金项目 (20720190074)", role: "主持", fund: "75万元" },
    { type: "Provincial", title: "基于联合组学的全氟辛烷类污染物的人类肝脏细胞毒性研究", source: "中国科学院知识创新工程重要方向项目", role: "主持", fund: "120万元" },
    { type: "Other", title: "中国科学院青年创新促进会人才项目", source: "人才项目", role: "主持", fund: "60万元" },
    { type: "Other", title: "基于下丘脑-垂体-睾丸性腺轴的内分泌(激素)和代谢干扰效应及其机制研究", source: "中科院城市环境研究所青年人才领域前沿项目", role: "主持", fund: "40万元" },
    { type: "Other", title: "生物样本代谢组学检测", source: "校合项目 (20223160A0787)", role: "主持", fund: "30万元" },
    { type: "Other", title: "基于灌口镇老年队列的慢性肾病的整合组学疾病标志物筛选及诊疗模型构建", source: "校合项目 (20223160A0027)", role: "主持", fund: "28.7万元" }
  ],

  // 招生/团队信息
  team: [
    { name: "硕士/博士研究生", role: "热招中", desc: "欢迎预防医学、卫生检验与检疫、统计学、健康大数据等相关专业优秀本科生、研究生报考。" },
    { name: "博士后", role: "诚聘英才", desc: "诚挚欢迎对系统流行病学、毒理学感兴趣的博士毕业生加入，共同开展高水平科研工作。" },
    { name: "科研技能要求", role: "Skillset", desc: "希望你热爱科研、责任心强；掌握 R 或 Python 等编程语言；具有良好的统计学基础及英文写作能力。" },
    { name: "本科生实习", role: "科研训练", desc: "欢迎有志于科研的优秀本科生加入课题组进行科研训练和毕业设计。" },
  ],

  // 代表性论文
  publications: [
    "1. Xu S, Li Y, ... Zhang J*. Association of combined exposure to air pollutants ... and IVF/ICSI outcomes. Journal of Hazardous Materials. 2025; 499: 140067.",
    "2. Lu Z, Liu C, ... Zhang J*. Gestational joint exposure to air pollutants and intrauterine skeletal development... Journal of Hazardous Materials. 2025; 499: 140025.",
    "3. Tan J, Huang L, ... Zhang J*. Associations between PM2.5 components, temperature, and semen quality... Environmental Research. 2025; 286: 122947.",
    "4. Lu Z, Liu C, ... Zhang J*. Gestational Exposure to PM2.5 ... and Neonatal Neurobehavioral Development. Environmental Science & Technology. 2024; 58: 9980–9990.",
    "5. Liang S, ... Zhang J*. Multi-Omics Analysis Reveals Molecular Insights into the Effects of Acute Ozone Exposure... Environment International. 2024; 183:108436.",
    "6. Lu W, ... Zhang J*. Altered metabolome and microbiome associated with compromised intestinal barrier... Environment International. 2024; 185:108559.",
    "7. Zhang Y, ... Zhang J*. Long-term ozone exposure was negatively associated with estimated glomerular filtration rate... Chemosphere. 2023; 341: 140040."
  ],

  // 联系方式
  contact: {
    email: "jie.zhang@xmu.edu.cn",
    address: "厦门大学翔安校区公共卫生学院",
    office: "曾宪梓楼 (实验教学中心)"
  }
};

// ----------------------------------------------------------------------
// 🎨 粒子特效组件 (Particle Background)
// ----------------------------------------------------------------------

const ParticleBackground = () => {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let particlesArray;
    let animationFrameId;

    // 调整画布大小
    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);
    handleResize(); // 初始化大小

    // 鼠标交互状态
    const mouse = {
      x: null,
      y: null,
      radius: 150 // 交互半径
    };

    const handleMouseMove = (event) => {
      // 考虑到 Canvas 在页面顶部，需要计算相对位置
      // 这里 Hero 是全屏或接近全屏，直接用 clientX/Y 即可
      mouse.x = event.x;
      mouse.y = event.y;
    };
    window.addEventListener('mousemove', handleMouseMove);

    // 粒子类定义
    class Particle {
      constructor(x, y, directionX, directionY, size, color) {
        this.x = x;
        this.y = y;
        this.directionX = directionX;
        this.directionY = directionY;
        this.size = size;
        this.color = color;
        this.baseX = x; // 记录初始位置(如果需要回弹效果)
        this.baseY = y;
      }

      // 绘制粒子
      draw() {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2, false);
        ctx.fillStyle = this.color;
        ctx.fill();
      }

      // 更新粒子位置
      update() {
        // 边界检测
        if (this.x > canvas.width || this.x < 0) {
          this.directionX = -this.directionX;
        }
        if (this.y > canvas.height || this.y < 0) {
          this.directionY = -this.directionY;
        }

        // 鼠标交互 - 抗重力排斥效果
        let dx = mouse.x - this.x;
        let dy = mouse.y - this.y;
        let distance = Math.sqrt(dx * dx + dy * dy);

        if (distance < mouse.radius) {
          if (mouse.x < this.x && this.x < canvas.width - this.size * 10) {
            this.x += 3; // 被推向右侧
          }
          if (mouse.x > this.x && this.x > this.size * 10) {
            this.x -= 3; // 被推向左侧
          }
          if (mouse.y < this.y && this.y < canvas.height - this.size * 10) {
            this.y += 3; // 被推向下侧
          }
          if (mouse.y > this.y && this.y > this.size * 10) {
            this.y -= 3; // 被推向上侧
          }
        }

        // 自然移动
        this.x += this.directionX;
        this.y += this.directionY;

        this.draw();
      }
    }

    // 初始化粒子群
    function init() {
      particlesArray = [];
      let numberOfParticles = (canvas.height * canvas.width) / 9000; // 密度控制
      for (let i = 0; i < numberOfParticles; i++) {
        let size = (Math.random() * 3) + 1;
        let x = (Math.random() * ((innerWidth - size * 2) - (size * 2)) + size * 2);
        let y = (Math.random() * ((innerHeight - size * 2) - (size * 2)) + size * 2);
        let directionX = (Math.random() * 1) - 0.5; // 速度
        let directionY = (Math.random() * 1) - 0.5;
        let color = 'rgba(147, 197, 253, 0.6)'; // tailwind blue-300 带有透明度

        particlesArray.push(new Particle(x, y, directionX, directionY, size, color));
      }
    }

    // 连线效果 (模拟分子键/网络)
    function connect() {
      let opacityValue = 1;
      for (let a = 0; a < particlesArray.length; a++) {
        for (let b = a; b < particlesArray.length; b++) {
          let distance = ((particlesArray[a].x - particlesArray[b].x) * (particlesArray[a].x - particlesArray[b].x))
            + ((particlesArray[a].y - particlesArray[b].y) * (particlesArray[a].y - particlesArray[b].y));
          if (distance < (canvas.width / 7) * (canvas.height / 7)) {
            opacityValue = 1 - (distance / 20000);
            ctx.strokeStyle = 'rgba(147, 197, 253,' + opacityValue * 0.2 + ')'; // 非常淡的连线
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(particlesArray[a].x, particlesArray[a].y);
            ctx.lineTo(particlesArray[b].x, particlesArray[b].y);
            ctx.stroke();
          }
        }
      }
    }

    // 动画循环
    function animate() {
      animationFrameId = requestAnimationFrame(animate);
      ctx.clearRect(0, 0, innerWidth, innerHeight);
      
      for (let i = 0; i < particlesArray.length; i++) {
        particlesArray[i].update();
      }
      connect();
    }

    init();
    animate();

    // 清理函数
    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas 
      ref={canvasRef} 
      className="absolute inset-0 z-0 w-full h-full pointer-events-none"
      style={{ mixBlendMode: 'screen' }} // 混合模式让光效更好
    />
  );
};

// ----------------------------------------------------------------------
// 🚀 页面组件代码
// ----------------------------------------------------------------------

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: '首页', href: '#home' },
    { name: 'PI介绍', href: '#about' },
    { name: '研究方向', href: '#research' },
    { name: '科研项目', href: '#fundings' }, 
    { name: '招生招聘', href: '#team' },
    { name: '科研成果', href: '#publications' },
    { name: '联系我们', href: '#contact' },
  ];

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${scrolled ? 'bg-white shadow-md py-2' : 'bg-slate-900/80 backdrop-blur-md py-4'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-700 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-lg">
              X
            </div>
            <div className={`font-bold text-lg tracking-wide ${scrolled ? 'text-blue-900' : 'text-white'}`}>
              {SITE_DATA.school}
            </div>
          </div>
          
          <div className="hidden md:flex space-x-8">
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href} 
                className={`text-sm font-medium hover:text-blue-500 transition-colors ${scrolled ? 'text-slate-700' : 'text-slate-200'}`}
              >
                {link.name}
              </a>
            ))}
          </div>

          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className={`${scrolled ? 'text-slate-800' : 'text-white'}`}>
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden bg-white border-t shadow-lg absolute w-full">
          <div className="px-4 pt-2 pb-6 space-y-2">
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href} 
                onClick={() => setIsOpen(false)}
                className="block px-3 py-3 text-base font-medium text-slate-700 hover:bg-blue-50 hover:text-blue-700 rounded-md"
              >
                {link.name}
              </a>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

const Hero = () => (
  <section id="home" className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 bg-slate-900 overflow-hidden min-h-screen flex items-center">
    {/* 🌟 集成粒子背景特效 */}
    <div className="absolute inset-0 bg-gradient-to-b from-slate-900 to-slate-800 z-0"></div>
    <ParticleBackground />
    
    {/* 装饰性背景光晕 - 保留以增加层次感 */}
    <div className="absolute inset-0 opacity-20 pointer-events-none z-0">
      <div className="absolute top-[-10%] right-[-10%] w-96 h-96 bg-blue-600 rounded-full blur-[128px]"></div>
      <div className="absolute bottom-[-10%] left-[-10%] w-72 h-72 bg-cyan-600 rounded-full blur-[128px]"></div>
    </div>
    
    <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center lg:text-left flex flex-col lg:flex-row items-center z-10">
      <div className="lg:w-2/3">
        <div className="inline-block px-4 py-1.5 mb-6 text-xs font-semibold tracking-wider text-blue-300 uppercase bg-blue-900/50 rounded-full border border-blue-700/50 backdrop-blur-sm">
          Public Health & Toxicology
        </div>
        <h1 className="text-4xl md:text-6xl font-extrabold text-white tracking-tight leading-tight mb-6 drop-shadow-lg">
          {SITE_DATA.labName}
        </h1>
        <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto lg:mx-0 font-light leading-relaxed">
          {SITE_DATA.labNameEn}
        </p>
        <p className="text-lg text-slate-400 mb-10 max-w-3xl mx-auto lg:mx-0">
          {SITE_DATA.intro}
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
          <a href="#research" className="px-8 py-4 text-base font-bold text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-all shadow-lg hover:shadow-blue-500/30 flex items-center justify-center z-20">
            探索研究方向 <ChevronRight className="ml-2" size={20} />
          </a>
          <a href="#team" className="px-8 py-4 text-base font-bold text-white border border-slate-600 rounded-lg hover:bg-slate-800 transition-all flex items-center justify-center backdrop-blur-sm z-20">
            加入我们
          </a>
        </div>
      </div>
      
      <div className="lg:w-1/3 mt-12 lg:mt-0 flex justify-center relative">
        {/* 将静态光晕改为稍微动态一点的呈现 */}
        <div className="w-64 h-64 md:w-80 md:h-80 bg-gradient-to-br from-blue-500/30 to-cyan-400/30 rounded-full blur-2xl absolute animate-pulse"></div>
        <div className="relative z-10 bg-slate-800/80 backdrop-blur-md p-6 rounded-2xl border border-slate-700 shadow-2xl transform rotate-3 hover:rotate-0 transition-transform duration-500 hover:border-blue-500/50">
           <div className="flex items-center space-x-4 mb-4">
             <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center text-white shadow-lg">
               <GraduationCap size={24}/>
             </div>
             <div>
               <h3 className="text-white font-bold">{SITE_DATA.piName}</h3>
               <p className="text-blue-300 text-sm">课题组负责人</p>
             </div>
           </div>
           <div className="space-y-2 mb-4">
             <div className="text-slate-400 text-sm font-mono">Focus Areas:</div>
             <div className="flex flex-wrap gap-2">
               <span className="px-2 py-1 bg-slate-700 text-blue-200 text-xs rounded border border-slate-600">Exposome</span>
               <span className="px-2 py-1 bg-slate-700 text-blue-200 text-xs rounded border border-slate-600">Metabolomics</span>
               <span className="px-2 py-1 bg-slate-700 text-blue-200 text-xs rounded border border-slate-600">Biomarkers</span>
             </div>
           </div>
           <div className="mt-4 pt-4 border-t border-slate-700 flex justify-between items-center">
             <span className="text-slate-400 text-xs">Recent Publications</span>
             <span className="text-2xl font-bold text-white">2025</span>
           </div>
        </div>
      </div>
    </div>
  </section>
);

const About = () => (
  <section id="about" className="py-24 bg-white">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex flex-col md:flex-row items-start gap-12">
        <div className="w-full md:w-1/3">
          <div className="aspect-[3/4] bg-slate-100 rounded-2xl shadow-inner flex flex-col items-center justify-center text-slate-400 relative overflow-hidden group border border-slate-200">
             <div className="w-32 h-32 bg-blue-100 rounded-full flex items-center justify-center text-blue-500 mb-4">
                <Users size={64} />
             </div>
             <p className="text-sm text-slate-500 px-8 text-center">（此处建议放置张洁教授个人工作照）</p>
             <div className="absolute bottom-0 left-0 right-0 p-4 bg-white/90 backdrop-blur-sm border-t">
                <p className="font-bold text-center text-slate-900">{SITE_DATA.piName}</p>
             </div>
          </div>
          <div className="mt-6 text-center md:text-left">
            <h3 className="text-2xl font-bold text-slate-900">{SITE_DATA.piName}</h3>
            <p className="text-blue-600 font-medium">{SITE_DATA.piTitle}</p>
            <p className="text-slate-500 mt-1">{SITE_DATA.school}</p>
          </div>
        </div>
        
        <div className="w-full md:w-2/3">
          <div className="flex items-center space-x-2 mb-6">
            <div className="w-1 h-8 bg-blue-600 rounded-full"></div>
            <h2 className="text-3xl font-bold text-slate-900">PI 简介</h2>
          </div>
          <div className="space-y-4 text-lg text-slate-600 leading-relaxed">
            {SITE_DATA.piBio.map((para, index) => (
              <p key={index} className="flex items-start">
                 <span className="mr-2 mt-2 w-1.5 h-1.5 bg-blue-400 rounded-full flex-shrink-0"></span>
                 {para}
              </p>
            ))}
          </div>
          
          <div className="mt-10">
            <h4 className="font-bold text-slate-800 mb-4 flex items-center">
              <Award className="mr-2 text-blue-600" size={20}/>
              曾获荣誉与项目
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm text-slate-600">
              <div className="bg-slate-50 p-3 rounded border border-slate-100">✦ 福建省高层次人才</div>
              <div className="bg-slate-50 p-3 rounded border border-slate-100">✦ 厦门市双百人才</div>
              <div className="bg-slate-50 p-3 rounded border border-slate-100">✦ 国家自然科学基金面上项目 (主持)</div>
              <div className="bg-slate-50 p-3 rounded border border-slate-100">✦ 科技部国家重点研发计划 (骨干)</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const Research = () => (
  <section id="research" className="py-24 bg-slate-50">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-16">
        <h2 className="text-3xl md:text-4xl font-bold text-slate-900">主要研究领域</h2>
        <div className="w-20 h-1.5 bg-blue-600 mx-auto mt-4 rounded-full"></div>
        <p className="mt-4 text-slate-500 text-lg max-w-2xl mx-auto">
          Research Interests
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {SITE_DATA.researchAreas.map((area, idx) => (
          <div key={idx} className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border border-slate-100 group relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-slate-50 rounded-bl-[100px] -mr-4 -mt-4 z-0 transition-colors group-hover:bg-blue-50"></div>
            <div className="relative z-10">
              <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-blue-600 group-hover:text-white transition-colors duration-300 shadow-sm">
                {area.icon}
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">{area.title}</h3>
              <p className="text-slate-600 leading-relaxed text-sm">
                {area.desc}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  </section>
);

// 🆕 新增：Fundings 组件
const Fundings = () => (
  <section id="fundings" className="py-24 bg-white">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex flex-col md:flex-row justify-between items-end mb-12">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">科研项目</h2>
          <div className="w-20 h-1.5 bg-blue-600 mt-4 rounded-full"></div>
          <p className="mt-2 text-slate-500">Funded Projects</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {SITE_DATA.fundings.map((item, idx) => (
          <div key={idx} className="flex flex-col p-6 rounded-xl bg-white border border-slate-100 shadow-sm hover:shadow-md hover:border-blue-200 transition-all">
            <div className="flex justify-between items-start mb-3">
               <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                 item.type === 'National' ? 'bg-red-50 text-red-600' : 
                 item.type === 'Provincial' ? 'bg-blue-50 text-blue-600' : 
                 'bg-slate-100 text-slate-600'
               }`}>
                 {item.type === 'National' ? '国家级' : item.type === 'Provincial' ? '省部级/市级' : '横向/校级'}
               </span>
               <span className="text-sm text-slate-500 font-mono">{item.fund}</span>
            </div>
            <h3 className="text-lg font-bold text-slate-800 mb-2 leading-snug">{item.title}</h3>
            <div className="mt-auto pt-4 border-t border-slate-50 flex items-center justify-between text-sm">
              <div className="flex items-center text-slate-600">
                <FileCheck size={16} className="mr-2 text-blue-500"/>
                {item.source}
              </div>
              <span className="font-medium text-blue-700 bg-blue-50 px-2 py-0.5 rounded">{item.role}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  </section>
);

const Team = () => (
  <section id="team" className="py-24 bg-slate-50">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex flex-col md:flex-row justify-between items-end mb-12">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">人才招聘</h2>
          <p className="mt-2 text-slate-500">Join Us / Recruitment</p>
        </div>
        <div className="mt-4 md:mt-0">
          <a href={`mailto:${SITE_DATA.contact.email}`} className="inline-flex items-center text-blue-600 font-medium hover:text-blue-800 transition-colors bg-blue-50 px-4 py-2 rounded-lg">
            <Mail size={18} className="mr-2"/> 发送简历
          </a>
        </div>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {SITE_DATA.team.map((item, idx) => (
          <div key={idx} className="bg-white rounded-xl p-6 border border-slate-200 hover:border-blue-300 hover:shadow-md transition-all group">
            <div className="flex justify-between items-start mb-4">
              <div className="p-2 bg-slate-50 rounded-lg shadow-sm text-blue-600 group-hover:text-blue-700">
                {idx === 0 ? <GraduationCap/> : idx === 1 ? <Users/> : <FileText/>}
              </div>
              <span className="text-xs font-bold px-2 py-1 bg-blue-100 text-blue-700 rounded-full">
                {item.role}
              </span>
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">{item.name}</h3>
            <p className="text-slate-600 text-sm leading-relaxed">{item.desc}</p>
          </div>
        ))}
      </div>

      <div className="mt-12 p-8 bg-slate-900 rounded-2xl text-white flex flex-col md:flex-row items-center justify-between">
        <div>
          <h3 className="text-xl font-bold mb-2">讲授课程</h3>
          <p className="text-slate-400 text-sm">
            《环境卫生学》、《环境卫生学实验与实践》、《流行病学》、《卫生化学》、《生活中的毒理学》
          </p>
        </div>
        <div className="mt-6 md:mt-0 flex-shrink-0">
          <span className="px-6 py-3 border border-slate-600 rounded-lg text-sm font-medium">
             Teaching & Education
          </span>
        </div>
      </div>
    </div>
  </section>
);

const Publications = () => (
  <section id="publications" className="py-24 bg-white">
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-16">
        <h2 className="text-3xl font-bold text-slate-900">近期代表性成果</h2>
        <p className="mt-2 text-slate-500">Selected Publications (2023-2025)</p>
      </div>
      
      <div className="space-y-4">
        {SITE_DATA.publications.map((pub, idx) => (
          <div key={idx} className="bg-slate-50 p-6 rounded-xl border border-slate-200 hover:border-blue-400 hover:shadow-md transition-all group relative pl-12">
            <span className="absolute left-4 top-6 text-2xl font-bold text-slate-300 group-hover:text-blue-200 transition-colors">
              {idx + 1}
            </span>
            <p className="text-slate-700 font-medium leading-relaxed text-sm md:text-base font-serif">
              {pub}
            </p>
          </div>
        ))}
      </div>
      
      <div className="mt-12 text-center">
        <p className="text-slate-500 text-sm mb-4">更多成果请查阅 PubMed 或 Google Scholar</p>
      </div>
    </div>
  </section>
);

const Footer = () => (
  <footer id="contact" className="bg-slate-950 text-slate-400 py-12 border-t border-slate-900">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
        <div>
          <h3 className="text-white text-lg font-bold mb-4">{SITE_DATA.labName}</h3>
          <p className="text-sm mb-6">{SITE_DATA.labNameEn}</p>
          <div className="flex space-x-4">
            <a href={`mailto:${SITE_DATA.contact.email}`} className="w-8 h-8 bg-slate-800 rounded flex items-center justify-center hover:bg-blue-600 hover:text-white transition-colors cursor-pointer">
              <Mail size={16}/>
            </a>
            <div className="w-8 h-8 bg-slate-800 rounded flex items-center justify-center hover:bg-blue-600 hover:text-white transition-colors cursor-pointer">
              <MapPin size={16}/>
            </div>
          </div>
        </div>
        
        <div>
          <h3 className="text-white text-lg font-bold mb-4">联系方式</h3>
          <ul className="space-y-3 text-sm">
            <li className="flex items-start">
              <Mail className="mr-3 mt-1 text-blue-500" size={16}/>
              <span>{SITE_DATA.contact.email}</span>
            </li>
            <li className="flex items-start">
              <MapPin className="mr-3 mt-1 text-blue-500" size={16}/>
              <span>{SITE_DATA.contact.address}</span>
            </li>
            <li className="flex items-start">
              <Users className="mr-3 mt-1 text-blue-500" size={16}/>
              <span>{SITE_DATA.contact.office}</span>
            </li>
          </ul>
        </div>
        
        <div>
          <h3 className="text-white text-lg font-bold mb-4">相关链接</h3>
          <ul className="space-y-2 text-sm">
            <li><a href="https://sph.xmu.edu.cn/" target="_blank" rel="noreferrer" className="hover:text-blue-400 transition-colors">厦门大学公共卫生学院</a></li>
            <li><a href="https://www.xmu.edu.cn/" target="_blank" rel="noreferrer" className="hover:text-blue-400 transition-colors">厦门大学</a></li>
            <li><a href="#" className="hover:text-blue-400 transition-colors">中国毒理学会</a></li>
          </ul>
        </div>
      </div>
      
      <div className="border-t border-slate-900 mt-12 pt-8 text-center text-xs">
        <p>&copy; {new Date().getFullYear()} {SITE_DATA.labName}. All rights reserved.</p>
      </div>
    </div>
  </footer>
);

export default function App() {
  return (
    <div className="bg-white min-h-screen font-sans text-slate-900 selection:bg-blue-200 selection:text-blue-900">
      <Navigation />
      <Hero />
      <About />
      <Research />
      <Fundings />
      <Team />
      <Publications />
      <Footer />
    </div>
  );
}